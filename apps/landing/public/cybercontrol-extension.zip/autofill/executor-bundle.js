/**
 * AUTO-GENERATED — do not edit.
 * Source: @cc/executor
 * Rebuild: pnpm --filter cybercontrol-extension build
 */

/* ==== parse-date-value.ts ==== */
(function(root2) {
  "use strict";
  function parseDateValue(value) {
    var empty = { dateObj: null, isoDate: "", isoMonth: "", isoDatetime: "" };
    if (value == null || value === "") return empty;
    var str = String(value).trim();
    if (!str) return empty;
    var dateObj = null;
    var ddmmyyyy = str.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})$/);
    if (ddmmyyyy) {
      dateObj = new Date(+ddmmyyyy[3], +ddmmyyyy[2] - 1, +ddmmyyyy[1]);
    }
    var yyyymmdd = str.match(/^(\d{4})[\/\-.](\d{1,2})[\/\-.](\d{1,2})$/);
    if (!dateObj && yyyymmdd) {
      dateObj = new Date(+yyyymmdd[1], +yyyymmdd[2] - 1, +yyyymmdd[3]);
    }
    if (!dateObj) {
      var d = new Date(str);
      if (!isNaN(d.getTime())) dateObj = d;
    }
    if (!dateObj || isNaN(dateObj.getTime())) return empty;
    var year = dateObj.getFullYear();
    var month = String(dateObj.getMonth() + 1).padStart(2, "0");
    var day = String(dateObj.getDate()).padStart(2, "0");
    var isoDate = year + "-" + month + "-" + day;
    var isoMonth = year + "-" + month;
    var isoDatetime = isoDate + "T00:00";
    return { dateObj, isoDate, isoMonth, isoDatetime };
  }
  root2.CcParseDateValue = {
    parseDateValue
  };
})(typeof globalThis !== "undefined" ? globalThis : this);
if (typeof module !== "undefined") module.exports = root.CcParseDateValue;

/* ==== jquery-ui-adapter.ts ==== */
(function(root) {
  "use strict";
  function normalize(value) {
    return String(value == null ? "" : value).replace(/\\s+/g, " ").trim().toLowerCase();
  }
  function text(node) {
    return String(node && node.textContent || "").replace(/\\s+/g, " ").trim();
  }
  function isSelectmenuButton(el) {
    return !!(el && el.classList && el.classList.contains("ui-selectmenu-button"));
  }
  function findSelectForButton(button) {
    if (!button) return null;
    var id = String(button.id || "");
    if (id.endsWith("-button")) {
      var selectId = id.slice(0, -7);
      var byId = button.ownerDocument.getElementById(selectId);
      if (byId && String(byId.tagName).toLowerCase() === "select") return byId;
    }
    var labelledBy = button.getAttribute && button.getAttribute("aria-labelledby");
    if (labelledBy) {
      var label = button.ownerDocument.getElementById(labelledBy);
      if (label && label.htmlFor) {
        var linked = button.ownerDocument.getElementById(label.htmlFor);
        if (linked && String(linked.tagName).toLowerCase() === "select") return linked;
      }
    }
    return null;
  }
  function findButton(el) {
    if (isSelectmenuButton(el)) return el;
    if (el && el.matches && el.matches('[id$="-button"].ui-selectmenu-button')) return el;
    if (el && el.querySelector) {
      var nested = el.querySelector(".ui-selectmenu-button");
      if (nested) return nested;
    }
    return null;
  }
  function findVisibleMenu(doc, button) {
    var menus = Array.from(doc.querySelectorAll(".ui-selectmenu-menu.ui-selectmenu-open, .ui-selectmenu-menu"));
    var visible = menus.filter(function(menu) {
      var style = doc.defaultView && doc.defaultView.getComputedStyle ? doc.defaultView.getComputedStyle(menu) : null;
      return menu.getClientRects().length > 0 && (!style || style.display !== "none" && style.visibility !== "hidden");
    });
    if (!visible.length) return null;
    var buttonId = String(button && button.id || "");
    var expectedId = buttonId.endsWith("-button") ? buttonId.slice(0, -7) + "-menu" : "";
    if (expectedId) {
      var owned = visible.find(function(menu) {
        return menu.id === expectedId;
      });
      if (owned) return owned;
    }
    return visible.find(function(menu) {
      return menu.classList.contains("ui-selectmenu-open");
    }) || null;
  }
  function selectmenu(el, requestedValue) {
    var button = findButton(el);
    if (!button) return null;
    var select = findSelectForButton(button);
    if (!select) return Promise.resolve({ success: false, verified: false, settled: true, reason: "jquery-ui-source-select-not-found" });
    var before = String(select.value || "");
    button.click();
    return new Promise(function(resolve) {
      var started = Date.now();
      var poll = setInterval(function() {
        var menu = findVisibleMenu(select.ownerDocument, button);
        var items = menu ? Array.from(menu.querySelectorAll(".ui-menu-item-wrapper")) : [];
        if (!menu || !items.length) {
          if (Date.now() - started >= 3e3) {
            clearInterval(poll);
            resolve({ success: false, verified: false, settled: true, reason: "jquery-ui-menu-not-open", previousValue: before });
          }
          return;
        }
        var options = Array.from(select.options || []);
        var wanted = normalize(requestedValue);
        var option = options.find(function(candidate) {
          return normalize(candidate.value) === wanted || normalize(candidate.text) === wanted;
        });
        if (!option) {
          option = options.find(function(candidate) {
            var label = normalize(candidate.text);
            return label === wanted || label && wanted && (label.includes(wanted) || wanted.includes(label));
          });
        }
        if (!option) {
          clearInterval(poll);
          resolve({ success: false, verified: false, settled: true, reason: "jquery-ui-option-not-found", optionCount: options.length });
          return;
        }
        var target = items.find(function(item) {
          return normalize(text(item)) === normalize(option.text);
        });
        if (!target) {
          clearInterval(poll);
          resolve({ success: false, verified: false, settled: true, reason: "jquery-ui-menu-option-not-found" });
          return;
        }
        clearInterval(poll);
        target.click();
        setTimeout(function() {
          var selected = String(select.value || "");
          var rendered = button.querySelector(".ui-selectmenu-text");
          var renderedText = text(rendered);
          var expectedText = String(option.text || "").trim();
          var verified = selected === String(option.value) && normalize(renderedText) === normalize(expectedText);
          resolve({
            success: verified,
            verified,
            settled: true,
            reason: verified ? "" : "jquery-ui-selection-not-confirmed",
            previousValue: before,
            selectedValue: selected,
            selectedText: renderedText,
            waitMs: Date.now() - started
          });
        }, 100);
      }, 50);
    });
  }
  function isDatepickerInput(el) {
    return !!(el && el.classList && el.classList.contains("hasDatepicker"));
  }
  function fillDatepicker(el, value, parseDateValue) {
    if (!isDatepickerInput(el)) return null;
    var rawValue = String(value == null ? "" : value).trim();
    if (!rawValue) return 0;
    var jq = root.jQuery || root.$;
    if (jq && jq.fn && typeof jq.fn.datepicker === "function") {
      try {
        jq(el).datepicker("setDate", rawValue);
        return String(el.value || "").trim() === rawValue ? 1 : 0;
      } catch (e) {
        return 0;
      }
    }
    var doc = el.ownerDocument;
    var view = doc && doc.defaultView;
    var descriptor = view && view.HTMLInputElement ? Object.getOwnPropertyDescriptor(view.HTMLInputElement.prototype, "value") : null;
    if (typeof el.focus === "function") el.focus();
    if (descriptor && descriptor.set) descriptor.set.call(el, rawValue);
    else el.value = rawValue;
    var EventCtor = view && view.Event ? view.Event : Event;
    ["input", "change", "keyup"].forEach(function(eventName) {
      el.dispatchEvent(new EventCtor(eventName, { bubbles: true }));
    });
    if (typeof el.blur === "function") el.blur();
    return String(el.value || "").trim() === rawValue ? 1 : 0;
  }
  root.CcJQueryUiAdapter = {
    isSelectmenuButton,
    findSelectForButton,
    selectmenu,
    isDatepickerInput,
    fillDatepicker
  };
})(typeof globalThis !== "undefined" ? globalThis : this);

/* ==== jquery-interaction-adapter.ts ==== */
(function(root) {
  "use strict";
  function getJQuery() {
    var jq = root && (root.jQuery || root.$);
    return typeof jq === "function" && jq.fn && typeof jq.fn.trigger === "function" ? jq : null;
  }
  function makeEvent(el, name, detail) {
    var view = el && el.ownerDocument && el.ownerDocument.defaultView;
    var E = view && view.Event ? view.Event : typeof Event !== "undefined" ? Event : null;
    var CE = view && view.CustomEvent ? view.CustomEvent : typeof CustomEvent !== "undefined" ? CustomEvent : null;
    if (detail !== void 0 && CE) return new CE(name, { bubbles: true, cancelable: true, detail });
    return E ? new E(name, { bubbles: true, cancelable: true }) : null;
  }
  function trigger(el, name, detail) {
    if (!el || typeof name !== "string" || !name.trim()) return { success: false, strategy: "none", reason: "invalid-target-or-event" };
    var jq = getJQuery();
    if (jq) {
      try {
        jq(el).trigger(name.trim(), detail === void 0 ? void 0 : [detail]);
        return { success: true, strategy: "jquery-trigger", event: name.trim() };
      } catch (e) {
      }
    }
    var event = makeEvent(el, name.trim(), detail);
    if (!event || typeof el.dispatchEvent !== "function") return { success: false, strategy: "none", reason: "event-dispatch-unavailable" };
    try {
      return { success: el.dispatchEvent(event) !== false, strategy: "native-event", event: name.trim() };
    } catch (e) {
      return { success: false, strategy: "native-event", event: name.trim(), reason: "dispatch-failed" };
    }
  }
  function triggerHandler(el, name, detail) {
    var jq = getJQuery();
    if (!jq || !el || typeof name !== "string" || !name.trim()) return { success: false, strategy: "none", reason: "jquery-triggerHandler-unavailable" };
    try {
      jq(el).triggerHandler(name.trim(), detail === void 0 ? void 0 : [detail]);
      return { success: true, strategy: "jquery-triggerHandler", event: name.trim() };
    } catch (e) {
      return { success: false, strategy: "jquery-triggerHandler", event: name.trim(), reason: "handler-failed" };
    }
  }
  function setValue(el, value, options) {
    if (!el) return { success: false, verified: false, reason: "target-not-found" };
    var raw = value == null ? "" : String(value);
    var jq = getJQuery();
    var strategy = "native-setter";
    try {
      if (jq) {
        jq(el).val(raw);
        strategy = "jquery-val";
      } else {
        var view = el.ownerDocument && el.ownerDocument.defaultView;
        var tag = String(el.tagName || "").toLowerCase();
        var ctor = tag === "textarea" ? view && view.HTMLTextAreaElement : view && view.HTMLInputElement;
        var desc = ctor && Object.getOwnPropertyDescriptor(ctor.prototype, "value");
        if (desc && desc.set) desc.set.call(el, raw);
        else el.value = raw;
      }
    } catch (e) {
      return { success: false, verified: false, strategy, reason: "value-set-failed" };
    }
    var events = options && Array.isArray(options.events) ? options.events : [];
    var eventResults = events.map(function(eventName) {
      return trigger(el, eventName);
    });
    var actual = String(el.value == null ? "" : el.value);
    var verified = actual === raw;
    return { success: verified, verified, strategy, value: actual, events: eventResults, reason: verified ? "" : "value-verification-failed" };
  }
  function click(el) {
    if (!el || typeof el.click !== "function") return { success: false, strategy: "native-click", reason: "click-unavailable" };
    try {
      el.click();
      return { success: true, strategy: "native-click" };
    } catch (e) {
      return { success: false, strategy: "native-click", reason: "click-failed" };
    }
  }
  root.CcJQueryInteractionAdapter = {
    isJQueryAvailable: function() {
      return !!getJQuery();
    },
    trigger,
    triggerHandler,
    setValue,
    click
  };
})(typeof globalThis !== "undefined" ? globalThis : this);

/* ==== cascade-field-level.ts ==== */
(function(root2) {
  "use strict";
  var CASCADE_PARENTS = {
    district: ["state"],
    sub_division: ["district", "state"],
    block: ["district", "sub_division", "state"],
    panchayat: ["block", "district"],
    village: ["block", "district"],
    police_station: ["district", "block"],
    post_office: ["block", "village", "district"]
  };
  function cascadeFieldLevel(label, profileKey, selector) {
    var s = ((profileKey || "") + " " + (label || "") + " " + (selector || "")).toLowerCase();
    if (/sub[_\s-]*div|अनुमंडल|subdivision/.test(s)) return "sub_division";
    if (/state|rajya|राज्य/.test(s) && !/sub/.test(s)) return "state";
    if (/district|jila|जिला/.test(s)) return "district";
    if (/block|prakhand|प्रखंड|tehsil|taluka/.test(s)) return "block";
    if (/panchayat|पंचायत/.test(s)) return "panchayat";
    if (/village|gram|ग्राम|mohalla|मोहल्ला/.test(s)) return "village";
    if (/police|thana|थाना/.test(s)) return "police_station";
    if (/post[_\s-]*office|डाक/.test(s)) return "post_office";
    if (/\bpin\b|pincode|pin[_\s-]*code|पिन/.test(s)) return "pin_code";
    return "";
  }
  root2.CcCascadeFieldLevel = {
    cascadeFieldLevel,
    CASCADE_PARENTS
  };
})(typeof globalThis !== "undefined" ? globalThis : this);
if (typeof module !== "undefined") module.exports = root.CcCascadeFieldLevel;

/* ==== select-option-state.ts ==== */
(function(root2) {
  "use strict";
  function isPlaceholderOption(o) {
    if (!o) return true;
    var v = String(o.value == null ? "" : o.value).trim();
    var t = String(o.text || "").trim().toLowerCase();
    if (!v || v === "0" || v === "-1" || v === "") return true;
    if (!t || t === "--" || t.includes("select") || t.includes("choose") || t.includes("loading")) return true;
    return false;
  }
  function realOptions(el) {
    if (!el || !el.options) return [];
    return Array.from(el.options).filter(function(o) {
      return !isPlaceholderOption(o);
    });
  }
  function sampleOptions(el, n) {
    n = n || 8;
    return realOptions(el).slice(0, n).map(function(o) {
      return {
        value: String(o.value || "").slice(0, 40),
        text: String(o.text || "").trim().slice(0, 60)
      };
    });
  }
  function readSelectActual(el) {
    if (!el || el.tagName !== "SELECT") return { actualValue: null, actualOptionValue: null };
    var opt = el.options && el.options[el.selectedIndex];
    if (!opt || isPlaceholderOption(opt)) {
      return { actualValue: "", actualOptionValue: opt ? String(opt.value || "") : "" };
    }
    return {
      actualValue: String(opt.text || "").trim(),
      actualOptionValue: String(opt.value || "")
    };
  }
  function selectLoadMode(el) {
    if (!el || el.tagName !== "SELECT") return "unknown";
    return realOptions(el).length > 0 ? "static" : "ajax";
  }
  function selectIsActive(el) {
    if (!el) return false;
    if (el.disabled) return false;
    try {
      if (el.offsetParent === null && el.getClientRects && el.getClientRects().length === 0) return false;
    } catch (e) {
    }
    return true;
  }
  function isPlaceholderPlanned(v) {
    var t = String(v == null ? "" : v).toLowerCase().trim();
    return !t || t === "--" || t === "0" || t.includes("please select") || t === "select" || t.startsWith("select ");
  }
  root2.CcSelectOptionState = {
    isPlaceholderOption,
    realOptions,
    sampleOptions,
    readSelectActual,
    selectLoadMode,
    selectIsActive,
    isPlaceholderPlanned
  };
})(typeof globalThis !== "undefined" ? globalThis : this);
if (typeof module !== "undefined") module.exports = root.CcSelectOptionState;

/* ==== confirm-field-pattern.ts ==== */
(function(root2) {
  "use strict";
  var CONFIRM_PREFIX_PATTERN = /^c(?=[a-z])|^confirm|^retype|^re_?type|^re_?enter|^verify/i;
  var CONFIRM_LABEL_PATTERN = /confirm|retype|re.type|re.enter|verify/i;
  function isConfirmField(id, label) {
    var idStr = String(id || "").toLowerCase();
    if (!idStr) return false;
    if (CONFIRM_PREFIX_PATTERN.test(idStr)) return true;
    if (label && CONFIRM_LABEL_PATTERN.test(String(label))) return true;
    return false;
  }
  function getBaseId(id) {
    return String(id || "").replace(/^c(?=[a-z])/, "").replace(/^confirm_?/i, "").replace(/^retype_?/i, "").replace(/^re_?type_?/i, "").replace(/^re_?enter_?/i, "").replace(/^verify_?/i, "");
  }
  root2.CcConfirmFieldPattern = {
    isConfirmField,
    getBaseId,
    CONFIRM_PREFIX_PATTERN,
    CONFIRM_LABEL_PATTERN
  };
})(typeof globalThis !== "undefined" ? globalThis : this);
if (typeof module !== "undefined") module.exports = root.CcConfirmFieldPattern;

/* ==== ng-option-scorer.ts ==== */
(function(root2) {
  "use strict";
  function scoreOption(optText, planned) {
    var ot = String(optText || "").toLowerCase().trim();
    var v = String(planned || "").toLowerCase().trim();
    if (!ot || !v) return 0;
    if (ot === v) return 100;
    if (ot.includes(v)) return 80;
    if (v.includes(ot) && ot.length > 3) return 70;
    var vToks = v.split(/[\s()+,/\-]+/).filter(function(t) {
      return t.length > 2;
    });
    var oToks = ot.split(/[\s()+,/\-]+/).filter(function(t) {
      return t.length > 2;
    });
    var overlap = vToks.filter(function(t) {
      return oToks.some(function(o) {
        return o.includes(t) || t.includes(o);
      });
    }).length;
    if (overlap >= 2) return 60;
    if (overlap === 1 && (vToks.length <= 2 || oToks.length <= 2)) return 50;
    var EDU_SYNONYMS = [
      ["intermediate", "higher secondary", "10+2", "12th", "hsc", "senior secondary"],
      ["matriculation", "10th", "sslc", "secondary", "high school", "class 10", "class x"],
      ["graduation", "graduate", "degree", "bachelor", "ug"],
      ["post graduation", "post graduate", "masters", "master", "pg", "m.a", "m.sc", "m.com"]
    ];
    for (var i = 0; i < EDU_SYNONYMS.length; i++) {
      var group = EDU_SYNONYMS[i];
      var vIn = group.some(function(s) {
        return v.includes(s);
      });
      var oIn = group.some(function(s) {
        return ot.includes(s);
      });
      if (vIn && oIn) return 55;
    }
    return 0;
  }
  function scoreAndPick(opts, planned, minScore) {
    minScore = typeof minScore === "number" ? minScore : 50;
    var best = null;
    var bestScore = 0;
    for (var i = 0; i < opts.length; i++) {
      var score = scoreOption(opts[i].text, planned);
      if (score > bestScore) {
        bestScore = score;
        best = opts[i];
      }
    }
    if (bestScore >= minScore) {
      return Object.assign({ score: bestScore }, best);
    }
    return null;
  }
  root2.CcNgOptionScorer = {
    scoreOption,
    scoreAndPick
  };
})(typeof globalThis !== "undefined" ? globalThis : this);
if (typeof module !== "undefined") module.exports = root.CcNgOptionScorer;

/* ==== ng-session-manager.ts ==== */
(function(root2) {
  "use strict";
  function cancelSession(label, sessions) {
    if (!sessions || !sessions.has(label)) return;
    var old = sessions.get(label);
    old.cancelled = true;
    try {
      clearInterval(old.pollTimer);
    } catch (e) {
    }
    (old.timeoutIds || []).forEach(function(id) {
      try {
        clearTimeout(id);
      } catch (e) {
      }
    });
    if (old.observer) {
      try {
        old.observer.disconnect();
      } catch (e) {
      }
      old.observer = null;
    }
    sessions.delete(label);
  }
  function createSession(label, sessions) {
    var session = {
      id: Math.random().toString(36).slice(2, 8),
      fieldKey: label,
      resolved: false,
      cancelled: false,
      pollTimer: null,
      timeoutIds: [],
      observer: null,
      startedAt: Date.now()
    };
    sessions.set(label, session);
    return session;
  }
  function cleanupSession(session, sessions, label) {
    try {
      clearInterval(session.pollTimer);
    } catch (e) {
    }
    (session.timeoutIds || []).forEach(function(id) {
      try {
        clearTimeout(id);
      } catch (e) {
      }
    });
    if (session.observer) {
      try {
        session.observer.disconnect();
      } catch (e) {
      }
      session.observer = null;
    }
    if (sessions && label !== void 0) sessions.delete(label);
  }
  root2.CcNgSessionManager = {
    cancelSession,
    createSession,
    cleanupSession
  };
})(typeof globalThis !== "undefined" ? globalThis : this);
if (typeof module !== "undefined") module.exports = root.CcNgSessionManager;

/* ==== build-fill-record.ts ==== */
(function(root2) {
  "use strict";
  function buildFillRecord(base, opts) {
    opts = opts || {};
    var rv = opts.rv !== void 0 ? opts.rv : "";
    var fillMode = opts.fillMode !== void 0 ? opts.fillMode : "sequential";
    var now = typeof opts.now === "function" ? opts.now : Date.now;
    return Object.assign(
      { ts: now(), rv, fillMode },
      base
    );
  }
  root2.CcBuildFillRecord = {
    buildFillRecord
  };
})(typeof globalThis !== "undefined" ? globalThis : this);
if (typeof module !== "undefined") module.exports = root.CcBuildFillRecord;

/* ==== fill-debug-emitter.ts ==== */
(function(root2) {
  "use strict";
  function createEmitter(opts) {
    opts = opts || {};
    var getRunId = opts.getRunId || function() {
      return "";
    };
    var getRv = opts.getRv || function() {
      return "";
    };
    var getHostname = opts.getHostname || function() {
      return typeof location !== "undefined" ? location.hostname : "";
    };
    var send = opts.send || function() {
    };
    var _queue = [];
    var _timer = null;
    function _flush() {
      if (!_queue.length) return;
      var batch = _queue.splice(0, 40);
      send(batch);
      if (_queue.length) _schedule();
    }
    function _schedule() {
      if (_timer) return;
      _timer = setTimeout(function() {
        _timer = null;
        _flush();
      }, 40);
    }
    function emit(event, payload) {
      var evt = Object.assign(
        {
          event,
          fillRunId: getRunId(),
          hostname: getHostname(),
          ts: Date.now(),
          rv: getRv()
        },
        payload || {}
      );
      if (evt.type && evt.type !== "FILL_DEBUG") {
        evt.fieldType = evt.type;
        delete evt.type;
      }
      _queue.push(evt);
      var immediate = event === "fill.start" || event === "fill.end" || _queue.length >= 6;
      if (immediate) {
        if (_timer) {
          clearTimeout(_timer);
          _timer = null;
        }
        _flush();
      } else {
        _schedule();
      }
    }
    function flush() {
      if (_timer) {
        clearTimeout(_timer);
        _timer = null;
      }
      _flush();
    }
    return {
      emit,
      flush,
      get queue() {
        return _queue;
      }
    };
  }
  root2.CcFillDebugEmitter = {
    createEmitter
  };
})(typeof globalThis !== "undefined" ? globalThis : this);
if (typeof module !== "undefined") module.exports = root.CcFillDebugEmitter;

/* ==== wait-for-options.ts ==== */
(function(root2) {
  "use strict";
  function waitForOptions(selector, minCount, timeout, qs, observeTarget) {
    minCount = minCount || 1;
    timeout = timeout || 8e3;
    qs = qs || (typeof document !== "undefined" ? document.querySelector.bind(document) : function() {
      return null;
    });
    observeTarget = observeTarget || (typeof document !== "undefined" ? document.body : null);
    return new Promise(function(resolve) {
      var deadline = Date.now() + timeout;
      var resolved = false;
      var poll, mo;
      function cleanup(val) {
        if (resolved) return;
        resolved = true;
        if (poll) clearInterval(poll);
        if (mo) mo.disconnect();
        resolve(val);
      }
      function isRealOption(o) {
        return o.value && o.value !== "0" && o.value !== "" && o.value !== "-1";
      }
      function check() {
        if (resolved) return;
        var el = qs(selector);
        var real = Array.from(el ? el.options || [] : []).filter(isRealOption);
        if (real.length >= minCount) {
          cleanup(el);
          return;
        }
        if (Date.now() > deadline) {
          cleanup(null);
          return;
        }
      }
      if (observeTarget) {
        mo = new MutationObserver(check);
        mo.observe(observeTarget, {
          childList: true,
          subtree: true,
          attributes: true,
          attributeFilter: ["disabled", "class"]
        });
      }
      check();
      poll = setInterval(function() {
        if (Date.now() > deadline) cleanup(null);
        else check();
      }, 200);
    });
  }
  root2.CcWaitForOptions = {
    waitForOptions
  };
})(typeof globalThis !== "undefined" ? globalThis : this);
if (typeof module !== "undefined") module.exports = root.CcWaitForOptions;

/* ==== settle-after-act.ts ==== */
(function(root2) {
  "use strict";
  function createSettleEngine(opts) {
    opts = opts || {};
    var waitForNetworkIdle = opts.waitForNetworkIdle || function(q, m) {
      return Promise.resolve({ idle: true, waitedMs: 0 });
    };
    var waitForOptions = opts.waitForOptions || function() {
      return Promise.resolve(null);
    };
    var getBudget = opts.getBudget || function() {
      return 0;
    };
    var setBudget = opts.setBudget || function() {
    };
    async function settleAfterAct(kind, actOpts) {
      actOpts = actOpts || {};
      var budget = typeof actOpts.budgetMs === "number" ? actOpts.budgetMs : getBudget();
      if (kind === "text") {
        await new Promise(function(r) {
          setTimeout(r, 100);
        });
        return { idle: true, waitedMs: 100, kind: "text" };
      }
      var kick = kind === "button" ? 300 : 200;
      await new Promise(function(r) {
        setTimeout(r, kick);
      });
      var maxNet = kind === "button" ? 5e3 : kind === "select" ? 4500 : 3500;
      maxNet = Math.min(maxNet, Math.max(300, budget > 0 ? budget : 400));
      var quiet = kind === "select" ? 150 : 120;
      var t0 = Date.now();
      var net = await waitForNetworkIdle(quiet, maxNet);
      var used = Date.now() - t0;
      setBudget(Math.max(0, getBudget() - used));
      return Object.assign({ kind }, net);
    }
    async function waitForSelectOptionsSequential(selector, maxMs) {
      maxMs = Math.min(maxMs || 6e3, Math.max(400, getBudget() || 400));
      var t0 = Date.now();
      await settleAfterAct("choice", { budgetMs: Math.min(2e3, maxMs) });
      var left = Math.max(300, maxMs - (Date.now() - t0));
      var el = await waitForOptions(selector, 1, left);
      setBudget(Math.max(0, getBudget() - (Date.now() - t0)));
      return el;
    }
    return {
      settleAfterAct,
      waitForSelectOptionsSequential
    };
  }
  root2.CcSettleAfterAct = {
    createSettleEngine
  };
})(typeof globalThis !== "undefined" ? globalThis : this);
if (typeof module !== "undefined") module.exports = root.CcSettleAfterAct;

/* ==== resolve-cc-selector.ts ==== */
(function(root2) {
  "use strict";
  var FORM_FIELD_QUERY = [
    'input[type="text"]',
    'input[type="email"]',
    'input[type="tel"]',
    'input[type="number"]',
    'input[type="date"]',
    'input[type="radio"]',
    'input[type="checkbox"]',
    'input[type="range"]',
    "input:not([type])",
    "textarea",
    "select"
  ].join(",");
  function queryDeep(d, selector) {
    if (!d || !selector) return null;
    var hit = null;
    try {
      hit = d.querySelector(selector);
    } catch (e) {
      hit = null;
    }
    if (hit) return hit;
    var frames = [];
    try {
      frames = d.querySelectorAll("iframe,frame");
    } catch (e2) {
      return null;
    }
    for (var i = 0; i < frames.length; i++) {
      var frame = frames[i];
      var tag = String(frame && frame.tagName || "").toLowerCase();
      if (tag && tag !== "iframe" && tag !== "frame") continue;
      var child = null;
      try {
        child = frame.contentDocument;
      } catch (e3) {
        child = null;
      }
      if (!child) continue;
      hit = queryDeep(child, selector);
      if (hit) return hit;
    }
    return null;
  }
  function resolveCcSelector(selector, doc) {
    var d = doc || (typeof document !== "undefined" ? document : null);
    if (!d) return null;
    if (selector.startsWith("form-field-")) {
      var idx = parseInt(selector.slice("form-field-".length), 10);
      var all = d.querySelectorAll(FORM_FIELD_QUERY);
      return all[idx] || null;
    }
    if (selector.startsWith("ng-dropdown-")) {
      var ngIdx = parseInt(selector.slice("ng-dropdown-".length), 10);
      var dropdowns = d.querySelectorAll("div.ng-dropdown");
      return dropdowns[ngIdx] || null;
    }
    return queryDeep(d, selector);
  }
  root2.CcResolveCcSelector = {
    resolveCcSelector,
    /** Exposed for consumers that need to build compatible form-field selectors. */
    FORM_FIELD_QUERY
  };
})(typeof globalThis !== "undefined" ? globalThis : this);
if (typeof module !== "undefined") module.exports = root.CcResolveCcSelector;

/* ==== sort-fields-by-dom-order.ts ==== */
(function(root2) {
  "use strict";
  function sortFieldsByDomOrder(entries, resolveEl) {
    if (!Array.isArray(entries) || entries.length < 2) return entries;
    var FOLLOWING = typeof Node !== "undefined" && Node.DOCUMENT_POSITION_FOLLOWING || 4;
    entries.sort(function(pairA, pairB) {
      var a = resolveEl(pairA[0]);
      var b = resolveEl(pairB[0]);
      if (!a || !b) return 0;
      if (a === b) return 0;
      if (typeof a.compareDocumentPosition !== "function") return 0;
      return a.compareDocumentPosition(b) & FOLLOWING ? -1 : 1;
    });
    return entries;
  }
  root2.CcSortFieldsByDomOrder = {
    sortFieldsByDomOrder
  };
})(typeof globalThis !== "undefined" ? globalThis : this);
if (typeof module !== "undefined") module.exports = root.CcSortFieldsByDomOrder;

/* ==== verify-fill-value.ts ==== */
(function(root2) {
  "use strict";
  async function verifyFillValue(selector, expected, resolveEl, settleMs) {
    settleMs = typeof settleMs === "number" ? settleMs : 150;
    if (settleMs > 0) await new Promise(function(r) {
      setTimeout(r, settleMs);
    });
    var liveEl;
    if (selector && selector.startsWith && selector.startsWith("ng-dropdown-")) {
      liveEl = null;
    } else {
      liveEl = resolveEl(selector);
    }
    if (!liveEl) {
      return { ok: false, actualValue: "", normExpected: "", normActual: "", reason: "no-element-on-verify" };
    }
    var tag = (liveEl.tagName || "").toLowerCase();
    if (liveEl.type === "checkbox") {
      var expCb = String(expected || "").trim().toLowerCase();
      var wantOff = /^(false|off|unchecked|no|0)$/.test(expCb);
      var wantOn = /^(true|on|checked|yes|1)$/.test(expCb) || !wantOff && !!expCb;
      var isOn = !!liveEl.checked;
      var okCb = wantOff ? !isOn : wantOn ? isOn : isOn;
      return {
        ok: okCb,
        actualValue: isOn ? liveEl.value || "on" : "false",
        normExpected: String(expected || ""),
        normActual: isOn ? "true" : "false"
      };
    }
    if (liveEl.type === "radio") {
      var groupName = liveEl.name;
      var selected = liveEl.checked ? liveEl : null;
      if (groupName) {
        var checked = document.querySelector('input[type="radio"][name="' + groupName + '"]:checked');
        if (checked) selected = checked;
      }
      if (!selected) {
        return { ok: false, actualValue: "", normExpected: String(expected || ""), normActual: "", reason: "radio-none-checked" };
      }
      var lbl = selected.id ? document.querySelector('label[for="' + selected.id + '"]') : null;
      var actualLabel = lbl && lbl.textContent.trim() || selected.value || "true";
      var normFn = function(s) {
        return String(s || "").toLowerCase().replace(/[^a-z0-9]/g, "");
      };
      var normExp0 = normFn(expected);
      var normAct0 = normFn(actualLabel);
      var ok0 = !expected || normAct0.includes(normExp0.slice(0, 4)) || normExp0.includes(normAct0.slice(0, 4)) || selected.checked;
      return { ok: !!ok0, actualValue: actualLabel, normExpected: normExp0, normActual: normAct0 };
    }
    if (tag === "select") {
      var opt = liveEl.options[liveEl.selectedIndex];
      var actualVal = (opt ? opt.text || opt.value : "") || "";
      var optVal = opt ? String(opt.value || "") : "";
      var normExpS = String(expected || "").toLowerCase().replace(/[^a-z0-9]/g, "");
      var normActS = actualVal.toLowerCase().replace(/[^a-z0-9]/g, "");
      var normValS = optVal.toLowerCase().replace(/[^a-z0-9]/g, "");
      var okS = normExpS.length > 0 && (normActS === normExpS || normValS === normExpS || normActS.includes(normExpS) || normExpS.includes(normActS) || normValS.includes(normExpS));
      return { ok: okS, actualValue: actualVal, normExpected: normExpS, normActual: normActS };
    }
    var actual = liveEl.value || "";
    var expStr = String(expected || "");
    if (!expStr) {
      return { ok: false, actualValue: actual, normExpected: "", normActual: actual, reason: "empty-expected" };
    }
    var normExp = expStr.toLowerCase().replace(/[^a-z0-9]/g, "");
    var normAct = actual.toLowerCase().replace(/[^a-z0-9]/g, "");
    if (normExp === normAct) {
      return { ok: true, actualValue: actual, normExpected: normExp, normActual: normAct };
    }
    if (normAct.length > 0 && (normAct.startsWith(normExp.slice(0, Math.max(8, normExp.length - 2))) || normExp.startsWith(normAct.slice(0, 8)))) {
      return { ok: true, actualValue: actual, normExpected: normExp, normActual: normAct, partial: true };
    }
    if (actual.length >= 8 && actual.length === expStr.length) {
      var tail = expStr.slice(-4).toLowerCase();
      if (actual.toLowerCase().endsWith(tail)) {
        return { ok: true, actualValue: actual, normExpected: normExp, normActual: normAct, masked: true };
      }
    }
    return {
      ok: false,
      actualValue: actual,
      normExpected: normExp,
      normActual: normAct,
      reason: actual === "" ? "value-rejected-empty" : "value-mismatch"
    };
  }
  root2.CcVerifyFillValue = {
    verifyFillValue
  };
})(typeof globalThis !== "undefined" ? globalThis : this);
if (typeof module !== "undefined") module.exports = root.CcVerifyFillValue;

/* ==== label-still-matches.ts ==== */
(function(root) {
  "use strict";
  function norm(s) {
    return String(s || "").toLowerCase().replace(/[^a-z0-9]+/g, " ").replace(/\s+/g, " ").trim();
  }
  function readVisualLabel(el, readLabel) {
    if (typeof readLabel === "function") return readLabel(el) || "";
    var utils = typeof window !== "undefined" && window.ccDomUtils;
    if (utils && typeof utils.getLabel === "function") return utils.getLabel(el) || "";
    if (!el) return "";
    var aria = el.getAttribute && el.getAttribute("aria-label");
    if (aria) return String(aria).trim();
    return String(el.placeholder || "").trim();
  }
  function isSectionHeading(s) {
    return /country of nationality|^nationality$|^country$/.test(norm(s));
  }
  function widgetAgrees(el, expected) {
    if (!el || !expected) return false;
    var hint = [
      el.placeholder,
      el.id,
      el.name,
      el.getAttribute && el.getAttribute("placeholder"),
      el.getAttribute && el.getAttribute("aria-label")
    ].filter(Boolean).join(" ").toLowerCase();
    if (/date of birth|\bdob\b|birth date/.test(expected)) {
      return /date|birth|dob|dd\s*[\/\-.]\s*mm|datebirth|effectivedate/.test(hint);
    }
    if (/father/.test(expected)) return /father|pita/.test(hint);
    if (/mother/.test(expected)) return /mother|mata/.test(hint);
    return false;
  }
  function compact(s) {
    return norm(s).replace(/\s+/g, "");
  }
  function isDobish(s) {
    return /date of birth|birth date|\bdob\b|date birth/.test(String(s || ""));
  }
  function matches(el, expectedLabel, readLabel) {
    var expected = norm(expectedLabel);
    if (!expected) return true;
    var liveRaw = readVisualLabel(el, readLabel);
    var live = norm(liveRaw);
    if (!live) return true;
    if (live === expected) return true;
    if (compact(live) === compact(expected)) return true;
    if (isSectionHeading(liveRaw) && widgetAgrees(el, expected)) return true;
    if (isDobish(expected) && isDobish(live)) return true;
    return false;
  }
  root.CcLabelStillMatches = { matches, norm, read: readVisualLabel };
})(typeof globalThis !== "undefined" ? globalThis : this);
if (typeof module !== "undefined") module.exports = globalThis.CcLabelStillMatches;

/* ==== click-control.ts ==== */
(function(root) {
  "use strict";
  function norm(s) {
    return String(s || "").toLowerCase().replace(/[^a-z0-9]+/g, " ").replace(/\s+/g, " ").trim();
  }
  function textOf(el) {
    if (!el) return "";
    var aria = el.getAttribute && el.getAttribute("aria-label");
    var raw = el.innerText || el.textContent || el.value || aria || "";
    return String(raw).replace(/\s+/g, " ").trim();
  }
  function isDisabled(el) {
    if (!el) return true;
    if (el.disabled) return true;
    var aria = el.getAttribute && el.getAttribute("aria-disabled");
    return aria === "true";
  }
  function visible(el) {
    if (!el) return false;
    if (typeof el.getBoundingClientRect === "function") {
      var box = el.getBoundingClientRect();
      if (box.width < 2 || box.height < 2) return false;
    }
    try {
      var view = el.ownerDocument && el.ownerDocument.defaultView || (typeof window !== "undefined" ? window : null);
      if (view && view.getComputedStyle) {
        var cs = view.getComputedStyle(el);
        if (cs && (cs.display === "none" || cs.visibility === "hidden")) return false;
      }
    } catch (e) {
    }
    if (el.closest) {
      if (el.closest('[hidden], [aria-hidden="true"]')) return false;
      var pane = el.closest('.tab-pane, [role="tabpanel"]');
      if (pane && pane !== el) {
        var paneCls = String(pane.className || "");
        var inactive = /\btab-pane\b/.test(paneCls) && !/\bactive\b/.test(paneCls) && !/\bshow\b/.test(paneCls);
        var ariaHidden = pane.getAttribute && pane.getAttribute("aria-hidden") === "true";
        if (inactive || ariaHidden) return false;
      }
    }
    return true;
  }
  var CONTROL_QUERY = 'button, input[type="submit"], input[type="button"], [role="button"], [role="checkbox"], [role="radio"], [role="option"], [role="combobox"], mat-select, mat-checkbox, mat-radio-button, td, div, span, a, li, strong, p, label, small, .rct-checkbox, .rct-title, .custom-control-label, [class*="auto-complete__option"], figure, .figure, [draggable="true"], .ui-draggable, .ui-droppable, .droppable, [ondrop]';
  var CLASS_WORD = /\b(1A|2A|3A|3E|SL|CC|EC|2S|FC|EA|EV)\b/i;
  var CLASS_ONLY = /^(1A|2A|3A|3E|SL|CC|EC|2S|FC|EA|EV)$/i;
  var AVAIL_WORD = /\b(AVAILABLE|GNWL|RAC|REGRET|CURR)\b/i;
  function inChrome(el) {
    return !!(el && el.closest && el.closest('nav,header,footer,[role="navigation"],[role="banner"]'));
  }
  function isButton(el) {
    if (!el || !el.tagName) return false;
    var tag = String(el.tagName).toLowerCase();
    if (tag === "button") return true;
    if (tag === "input") {
      var t = String(el.type || el.getAttribute && el.getAttribute("type") || "").toLowerCase();
      return t === "submit" || t === "button";
    }
    var role = el.getAttribute && el.getAttribute("role");
    return role === "button";
  }
  function isChoice(el) {
    if (!el || !el.tagName || inChrome(el)) return false;
    var role = el.getAttribute && el.getAttribute("role");
    var tagName = String(el.tagName || "").toLowerCase();
    if (role === "checkbox" || role === "radio" || role === "option" || role === "combobox") return true;
    if (tagName === "mat-select" || tagName === "mat-checkbox" || tagName === "mat-radio-button") return true;
    var componentClass = String(el.className || "");
    if (/\bv-select\b|\bv-autocomplete\b|\bv-combobox\b/.test(componentClass)) return true;
    if (/\b\S*auto-complete__option\b/.test(String(el.className || ""))) return true;
    var tag = tagName;
    var cls = String(el.className || "");
    if (tag === "a") {
      var href = el.getAttribute && el.getAttribute("href");
      var text = textOf(el);
      return !!(href && text && text.length >= 2 && text.length <= 60);
    }
    if (tag === "label") {
      if (el.closest && el.closest("mat-checkbox, mat-radio-button")) return false;
      if (/custom-control-label|form-check-label|rct-text/.test(cls)) return true;
      if (el.getAttribute && el.getAttribute("for")) return true;
      if (el.querySelector && el.querySelector('input[type="radio"], input[type="checkbox"], .rct-checkbox')) return true;
    }
    if (/\brct-checkbox\b|\brct-title\b|\bcustom-control-label\b/.test(cls)) return true;
    return false;
  }
  function isHoverable(el) {
    if (!el || !el.tagName || inChrome(el)) return false;
    var tag = String(el.tagName).toLowerCase();
    if (tag === "figure") return true;
    var cls = String(el.className || "");
    if (/\bfigure\b/.test(cls)) return true;
    var popup = el.getAttribute && el.getAttribute("aria-haspopup");
    if (popup && popup !== "false" && !isButton(el)) return true;
    return false;
  }
  function isDraggable(el) {
    if (!el || !el.tagName || inChrome(el)) return false;
    if (el.draggable === true) return true;
    var attr = el.getAttribute && el.getAttribute("draggable");
    if (attr === "true") return true;
    return /\bui-draggable\b/.test(String(el.className || ""));
  }
  function isDroppable(el) {
    if (!el || !el.tagName || inChrome(el)) return false;
    if (isDraggable(el)) return false;
    var ondrop = el.getAttribute && el.getAttribute("ondrop") != null;
    var cls = String(el.className || "");
    if (!ondrop && !/\bui-droppable\b|\bdroppable\b/.test(cls)) return false;
    if (el.querySelector && el.querySelector(".ui-droppable, .droppable, [ondrop]")) return false;
    return true;
  }
  function isLinkCell(el) {
    return String(el.tagName || "").toLowerCase() === "td" && /(?:^|\s)link(?:\s|$)/.test(String(el.className || ""));
  }
  function inTrainCard(el, text) {
    if (!el || typeof el.closest !== "function") return true;
    if (el.closest(".bull-back, app-train-avl-enq")) return true;
    return CLASS_ONLY.test(text);
  }
  function isClassCell(el) {
    if (!el || !el.tagName) return false;
    var tag = String(el.tagName).toLowerCase();
    if (!/^(td|div|span|a|li|strong|button|p|label|small)$/.test(tag)) return false;
    var text = textOf(el);
    if (!text || text.length > 80) return false;
    var coded = CLASS_WORD.test(text);
    var avail = AVAIL_WORD.test(text);
    if (!isLinkCell(el) && !coded && !avail) return false;
    if (!isLinkCell(el) && !inTrainCard(el, text)) return false;
    if (typeof el.querySelectorAll === "function") {
      var kids = el.querySelectorAll("td, div, span, a, li, strong, button, p, label, small");
      for (var i = 0; i < kids.length; i++) {
        var kt = textOf(kids[i]);
        if (!kt || kt.length >= text.length || kt.length > 80) continue;
        if (CLASS_WORD.test(kt) || AVAIL_WORD.test(kt) || isLinkCell(kids[i])) return false;
      }
    }
    return true;
  }
  function labelOf(el) {
    if (isHoverable(el)) {
      var blob = String(el.textContent || "").replace(/\s+/g, " ").trim();
      if (blob) return blob.slice(0, 80);
      var img = el.querySelector && el.querySelector("img");
      var alt = img && img.getAttribute && img.getAttribute("alt");
      if (alt) return String(alt).slice(0, 80);
      return "hover";
    }
    if (isDraggable(el)) {
      var dragText = textOf(el);
      if (dragText) return dragText.slice(0, 80);
      if (el.id) return String(el.id);
      return "drag";
    }
    if (isDroppable(el)) {
      var dropText = textOf(el);
      if (dropText) return dropText.slice(0, 80);
      if (el.id) return String(el.id);
      return "drop";
    }
    var label = textOf(el);
    if (isClassCell(el)) return label.slice(0, 80);
    return label;
  }
  function candidates(doc) {
    if (!doc || typeof doc.querySelectorAll !== "function") return [];
    var nodes = doc.querySelectorAll(CONTROL_QUERY);
    var out = [];
    for (var i = 0; i < nodes.length; i++) {
      var el = nodes[i];
      var button = isButton(el);
      var klass = !button && isClassCell(el);
      var choice = !button && !klass && isChoice(el);
      var hover = !button && !klass && !choice && isHoverable(el);
      var drag = !button && !klass && !choice && !hover && isDraggable(el);
      var drop = !button && !klass && !choice && !hover && !drag && isDroppable(el);
      if (!button && !klass && !choice && !hover && !drag && !drop) continue;
      if (!visible(el)) continue;
      var label = labelOf(el);
      if (!label || button && label.length > 80) continue;
      if (/captcha|otp/i.test(label)) continue;
      out.push(el);
    }
    return out;
  }
  function selectorFor(el, index, doc) {
    if (el.id && /^[A-Za-z][\w:-]*$/.test(el.id)) {
      var byId = "#" + el.id;
      if (doc.querySelectorAll && doc.querySelectorAll(byId).length === 1) return byId;
      var parent = el.parentElement;
      while (parent && parent !== (doc.documentElement || null)) {
        if (parent.id && /^[A-Za-z][\w:-]*$/.test(parent.id)) {
          var scoped = "#" + parent.id + " #" + el.id;
          if (doc.querySelectorAll && doc.querySelectorAll(scoped).length === 1) return scoped;
        }
        parent = parent.parentElement;
      }
    }
    var cls = String(el.className || "").trim().split(/\s+/).filter(function(c) {
      return c && c.length < 40 && /^[A-Za-z][\w-]*$/.test(c);
    });
    if (cls.length && el.tagName) {
      var sel = String(el.tagName).toLowerCase() + "." + cls[0];
      if (doc.querySelectorAll && doc.querySelectorAll(sel).length === 1) return sel;
    }
    return "cc-button-" + index;
  }
  function list(doc) {
    var nodes = candidates(doc);
    var fields = [];
    for (var i = 0; i < nodes.length; i++) {
      var label = labelOf(nodes[i]);
      var tag = String(nodes[i].tagName || "").toLowerCase();
      var asLink = tag === "a";
      var asHover = !asLink && isHoverable(nodes[i]);
      var asDrag = !asLink && !asHover && isDraggable(nodes[i]);
      var asDrop = !asLink && !asHover && !asDrag && isDroppable(nodes[i]);
      var kind = asLink ? "link" : asHover ? "hover" : asDrag ? "drag" : asDrop ? "drop" : "button";
      fields.push({
        selector: selectorFor(nodes[i], fields.length, doc),
        label,
        visualLabel: label,
        type: kind,
        role: kind
      });
    }
    return fields;
  }
  function findByText(text, doc) {
    var want = norm(text);
    if (!want) return { node: null, field: null, reason: "not_found" };
    var nodes = candidates(doc);
    var fields = list(doc);
    for (var i = 0; i < fields.length; i++) {
      if (norm(fields[i].visualLabel) === want) return { node: nodes[i], field: fields[i] };
    }
    if (!doc || typeof doc.querySelectorAll !== "function") return { node: null, field: null, reason: "not_found" };
    var links = doc.querySelectorAll("a[href]");
    for (var j = 0; j < links.length; j++) {
      if (inChrome(links[j]) || !visible(links[j])) continue;
      var live = textOf(links[j]);
      if (norm(live) !== want) continue;
      var field = {
        selector: selectorFor(links[j], fields.length, doc),
        label: live.slice(0, 80),
        visualLabel: live.slice(0, 80),
        type: "link",
        role: "link"
      };
      return { node: links[j], field };
    }
    return { node: null, field: null, reason: "not_found" };
  }
  function findNode(spec, doc) {
    var nodes = candidates(doc);
    var fields = list(doc);
    var sel = spec && spec.selector ? String(spec.selector) : "";
    var expected = norm(spec && (spec.visualLabel || spec.label));
    if (sel) {
      for (var i = 0; i < fields.length; i++) {
        if (fields[i].selector !== sel) continue;
        if (expected && norm(fields[i].visualLabel) !== expected) {
          return { node: null, reason: "label_drift", live: fields[i].visualLabel };
        }
        return { node: nodes[i], field: fields[i] };
      }
    }
    if (expected) {
      for (var j = 0; j < fields.length; j++) {
        if (norm(fields[j].visualLabel) !== expected) continue;
        return { node: nodes[j], field: fields[j] };
      }
    }
    return { node: null, reason: "not_found" };
  }
  function centerOf(el) {
    if (!el || typeof el.getBoundingClientRect !== "function") return null;
    var box = el.getBoundingClientRect();
    if (box.width < 2 || box.height < 2) return null;
    return { x: box.left + box.width / 2, y: box.top + box.height / 2 };
  }
  function fire(el) {
    if (typeof el.scrollIntoView === "function") {
      try {
        el.scrollIntoView({ block: "center", inline: "center" });
      } catch (e) {
      }
    }
    var target = el;
    var point = centerOf(el);
    var doc = el.ownerDocument || (typeof document !== "undefined" ? document : null);
    if (point && doc && typeof doc.elementFromPoint === "function") {
      var hit = doc.elementFromPoint(point.x, point.y);
      if (hit && (hit === el || typeof el.contains === "function" && el.contains(hit))) target = hit;
    }
    var view = el.ownerDocument && el.ownerDocument.defaultView || (typeof window !== "undefined" ? window : null);
    var names = ["pointerdown", "mousedown", "pointerup", "mouseup"];
    for (var i = 0; i < names.length; i++) {
      var ev = null;
      var init = {
        bubbles: true,
        cancelable: true,
        view,
        clientX: point ? point.x : 0,
        clientY: point ? point.y : 0,
        button: 0,
        buttons: 1
      };
      try {
        if (names[i].indexOf("pointer") === 0 && view && typeof view.PointerEvent === "function") {
          ev = new view.PointerEvent(names[i], Object.assign({ pointerId: 1, pointerType: "mouse", isPrimary: true }, init));
        } else if (view && typeof view.MouseEvent === "function") {
          ev = new view.MouseEvent(names[i], init);
        }
      } catch (e) {
      }
      if (ev && typeof target.dispatchEvent === "function") target.dispatchEvent(ev);
      else if (typeof target.dispatchEvent === "function") target.dispatchEvent({ type: names[i], bubbles: true, cancelable: true });
    }
    if (typeof target.click === "function") {
      target.click();
    } else if (typeof el.click === "function") {
      el.click();
    } else if (typeof target.dispatchEvent === "function") {
      var clickView = target.ownerDocument && target.ownerDocument.defaultView || (typeof window !== "undefined" ? window : null);
      var clickEvent = clickView && typeof clickView.MouseEvent === "function" ? new clickView.MouseEvent("click", { bubbles: true, cancelable: true, view: clickView }) : { type: "click", bubbles: true, cancelable: true };
      target.dispatchEvent(clickEvent);
    }
  }
  function forceHoverCss(el) {
    var rootDoc = el && el.ownerDocument || (typeof document !== "undefined" ? document : null);
    if (!rootDoc) return;
    try {
      var marked = rootDoc.documentElement;
      if (marked && marked.getAttribute && marked.getAttribute("data-cc-hover-css") !== "1") {
        if (marked.setAttribute) marked.setAttribute("data-cc-hover-css", "1");
        var sheets = rootDoc.styleSheets || [];
        for (var s = 0; s < sheets.length; s++) {
          var rules = null;
          try {
            rules = sheets[s].cssRules;
          } catch (e0) {
            continue;
          }
          if (!rules || !sheets[s].insertRule) continue;
          var add = [];
          for (var r = 0; r < rules.length; r++) {
            var rule = rules[r];
            if (!rule || !rule.selectorText || String(rule.selectorText).indexOf(":hover") === -1) continue;
            add.push(String(rule.selectorText).replace(/:hover/g, ".cc-force-hover") + "{" + (rule.style && rule.style.cssText || "") + "}");
          }
          for (var a = 0; a < add.length; a++) {
            try {
              sheets[s].insertRule(add[a], sheets[s].cssRules.length);
            } catch (e1) {
            }
          }
        }
      }
    } catch (e2) {
    }
    try {
      var prev = rootDoc.querySelectorAll && rootDoc.querySelectorAll(".cc-force-hover");
      if (prev) {
        for (var c = 0; c < prev.length; c++) {
          if (prev[c] && prev[c].classList) prev[c].classList.remove("cc-force-hover");
        }
      }
    } catch (e3) {
    }
    var node = el;
    while (node && node.classList) {
      try {
        node.classList.add("cc-force-hover");
      } catch (e4) {
        break;
      }
      node = node.parentElement || node.parentNode;
    }
  }
  function fireHover(el) {
    if (typeof el.scrollIntoView === "function") {
      try {
        el.scrollIntoView({ block: "center", inline: "center" });
      } catch (e) {
      }
    }
    var point = centerOf(el);
    var view = el.ownerDocument && el.ownerDocument.defaultView || (typeof window !== "undefined" ? window : null);
    var names = ["pointerover", "pointerenter", "mouseover", "mouseenter", "pointermove", "mousemove"];
    for (var i = 0; i < names.length; i++) {
      var ev = null;
      var init = {
        bubbles: true,
        cancelable: true,
        view,
        clientX: point ? point.x : 0,
        clientY: point ? point.y : 0,
        button: 0,
        buttons: 0
      };
      try {
        if (names[i].indexOf("pointer") === 0 && view && typeof view.PointerEvent === "function") {
          ev = new view.PointerEvent(names[i], Object.assign({ pointerId: 1, pointerType: "mouse", isPrimary: true }, init));
        } else if (view && typeof view.MouseEvent === "function") {
          ev = new view.MouseEvent(names[i], init);
        }
      } catch (e2) {
      }
      if (ev && typeof el.dispatchEvent === "function") el.dispatchEvent(ev);
      else if (typeof el.dispatchEvent === "function") el.dispatchEvent({ type: names[i], bubbles: true, cancelable: true });
    }
    forceHoverCss(el);
  }
  function chooseOption(doc, text) {
    var want = norm(text);
    if (!want || !doc || typeof doc.querySelectorAll !== "function") {
      return { pressed: false, reason: "not_found", clicked: "" };
    }
    var nodes = doc.querySelectorAll('[role="option"]');
    for (var i = 0; i < nodes.length; i++) {
      var label = textOf(nodes[i]);
      if (!label || norm(label).indexOf(want) === -1) continue;
      if (!visible(nodes[i])) continue;
      fire(nodes[i]);
      return { pressed: true, reason: "", clicked: label };
    }
    return { pressed: false, reason: "not_found", clicked: "" };
  }
  function press(spec, doc) {
    var found = findNode(spec || {}, doc);
    if (!found.node) {
      return { pressed: false, reason: found.reason || "not_found", clicked: "", selector: spec && spec.selector || "" };
    }
    if (isDisabled(found.node)) {
      return { pressed: false, reason: "disabled", clicked: textOf(found.node), selector: found.field.selector };
    }
    if (found.field && found.field.type === "hover") {
      fireHover(found.node);
      return { pressed: true, reason: "", clicked: labelOf(found.node), selector: found.field.selector, hovered: true };
    }
    fire(found.node);
    return { pressed: true, reason: "", clicked: textOf(found.node), selector: found.field.selector };
  }
  function elementFor(selector, doc) {
    var found = findNode({ selector }, doc);
    return found && found.node ? found.node : null;
  }
  root.CcClickControl = { list, press, chooseOption, norm, elementFor, findByText };
})(typeof globalThis !== "undefined" ? globalThis : this);
if (typeof module !== "undefined") module.exports = globalThis.CcClickControl;

/* ==== pointer-keys.ts ==== */
(function(root) {
  "use strict";
  function clickAt(spec) {
    var g = typeof globalThis !== "undefined" ? globalThis : this;
    var doc = g.document;
    if (!doc) return { ok: false, error: "no_document" };
    function isShown(el) {
      if (!el || typeof el.getBoundingClientRect !== "function") return true;
      var box2 = el.getBoundingClientRect();
      if (box2.width < 1 || box2.height < 1) return false;
      try {
        var st = el.ownerDocument && el.ownerDocument.defaultView || g.window || g;
        if (st && st.getComputedStyle) {
          var cs = st.getComputedStyle(el);
          if (cs && (cs.display === "none" || cs.visibility === "hidden")) return false;
        }
      } catch (e) {
      }
      return true;
    }
    function queryDeep(rootDoc, sel) {
      if (!rootDoc || !sel) return null;
      var nodes = [];
      try {
        nodes = rootDoc.querySelectorAll(sel);
      } catch (e0) {
        nodes = [];
      }
      var first = null;
      for (var n = 0; n < nodes.length; n++) {
        if (!first) first = nodes[n];
        if (isShown(nodes[n])) return nodes[n];
      }
      if (first) return first;
      var frames = [];
      try {
        frames = rootDoc.querySelectorAll("iframe,frame");
      } catch (e1) {
        return null;
      }
      for (var i = 0; i < frames.length; i++) {
        var child = null;
        try {
          child = frames[i].contentDocument;
        } catch (e2) {
          child = null;
        }
        if (!child) continue;
        var nested = queryDeep(child, sel);
        if (nested) return nested;
      }
      return null;
    }
    function resolve(sel) {
      if (!sel) return null;
      try {
        var resolver = g.CcResolveCcSelector;
        if (resolver && typeof resolver.resolveCcSelector === "function") {
          var byCc = resolver.resolveCcSelector(sel, doc);
          if (byCc) return byCc;
        }
      } catch (e) {
      }
      try {
        var clickApi = g.CcClickControl;
        if (clickApi && typeof clickApi.elementFor === "function") {
          var byClick = clickApi.elementFor(sel, doc);
          if (byClick) return byClick;
        }
      } catch (e2) {
      }
      return queryDeep(doc, sel);
    }
    function labelOf(el) {
      if (!el) return "";
      var aria = el.getAttribute && el.getAttribute("aria-label");
      var raw = aria || el.innerText || el.textContent || el.value || el.placeholder || "";
      return String(raw).replace(/\s+/g, " ").trim().slice(0, 80);
    }
    function makeEvent(name, point2, button2, buttons2, detail) {
      var view2 = doc.defaultView || g.window || g;
      var scrollX = view2 && view2.scrollX || 0;
      var scrollY = view2 && view2.scrollY || 0;
      var init = {
        bubbles: true,
        cancelable: true,
        view: view2,
        clientX: point2.x,
        clientY: point2.y,
        pageX: point2.x + scrollX,
        pageY: point2.y + scrollY,
        screenX: point2.x,
        screenY: point2.y,
        button: button2,
        buttons: buttons2,
        which: button2 === 0 ? 1 : button2 === 2 ? 3 : 2,
        detail
      };
      try {
        if (name.indexOf("pointer") === 0 && view2 && typeof view2.PointerEvent === "function") {
          return new view2.PointerEvent(name, Object.assign({ pointerId: 1, pointerType: "mouse", isPrimary: true }, init));
        }
        if (view2 && typeof view2.MouseEvent === "function") return new view2.MouseEvent(name, init);
      } catch (e) {
      }
      return { type: name, bubbles: true, cancelable: true, clientX: point2.x, clientY: point2.y, button: button2 };
    }
    function fire(el, point2, button2, buttons2, names2, detail) {
      for (var i = 0; i < names2.length; i++) {
        var ev = makeEvent(names2[i], point2, button2, buttons2, detail);
        if (el && typeof el.dispatchEvent === "function") el.dispatchEvent(ev);
      }
    }
    function forceHover(el) {
      var rootDoc = el && el.ownerDocument || doc;
      try {
        var marked = rootDoc.documentElement;
        if (marked && marked.getAttribute && marked.getAttribute("data-cc-hover-css") !== "1") {
          if (marked.setAttribute) marked.setAttribute("data-cc-hover-css", "1");
          var sheets = rootDoc.styleSheets || [];
          for (var s = 0; s < sheets.length; s++) {
            var rules = null;
            try {
              rules = sheets[s].cssRules;
            } catch (e0) {
              continue;
            }
            if (!rules || !sheets[s].insertRule) continue;
            var add = [];
            for (var r = 0; r < rules.length; r++) {
              var rule = rules[r];
              if (!rule || !rule.selectorText || String(rule.selectorText).indexOf(":hover") === -1) continue;
              add.push(String(rule.selectorText).replace(/:hover/g, ".cc-force-hover") + "{" + (rule.style && rule.style.cssText || "") + "}");
            }
            for (var a = 0; a < add.length; a++) {
              try {
                sheets[s].insertRule(add[a], sheets[s].cssRules.length);
              } catch (e1) {
              }
            }
          }
        }
      } catch (e2) {
      }
      try {
        var prev = rootDoc.querySelectorAll && rootDoc.querySelectorAll(".cc-force-hover");
        if (prev) {
          for (var c = 0; c < prev.length; c++) {
            if (prev[c] && prev[c].classList) prev[c].classList.remove("cc-force-hover");
          }
        }
      } catch (e3) {
      }
      var node = el;
      while (node && node.classList) {
        try {
          node.classList.add("cc-force-hover");
        } catch (e4) {
          break;
        }
        node = node.parentElement || node.parentNode;
      }
    }
    var selector = spec && spec.selector ? String(spec.selector) : "";
    var buttonName = spec && spec.button === "right" ? "right" : spec && spec.button === "middle" ? "middle" : "left";
    var count = Number(spec && spec.count) === 2 ? 2 : 1;
    var button = buttonName === "right" ? 2 : buttonName === "middle" ? 1 : 0;
    var buttons = button === 0 ? 1 : button === 2 ? 2 : 4;
    var target = null;
    var point = null;
    if (selector) {
      target = resolve(selector);
      if (!target) return { ok: false, error: "not_found" };
      if (typeof target.scrollIntoView === "function") {
        try {
          target.scrollIntoView({ block: "center", inline: "center" });
        } catch (e4) {
        }
      }
      var box = typeof target.getBoundingClientRect === "function" ? target.getBoundingClientRect() : null;
      if (!box || box.width < 1 || box.height < 1) return { ok: false, error: "not_visible" };
      point = { x: box.left + box.width / 2, y: box.top + box.height / 2 };
    } else {
      var x = Number(spec && spec.x);
      var y = Number(spec && spec.y);
      if (!isFinite(x) || !isFinite(y)) return { ok: false, error: "x and y required" };
      point = { x, y };
      if (typeof doc.elementFromPoint === "function") target = doc.elementFromPoint(x, y);
      if (!target) return { ok: false, error: "nothing_there", x: Math.round(x), y: Math.round(y) };
    }
    var action = spec && spec.action === "hover" ? "hover" : spec && spec.action === "drag" ? "drag" : "click";
    if (action === "hover") {
      fire(target, point, 0, 0, ["pointerover", "pointerenter", "mouseover", "mouseenter", "pointermove", "mousemove"], 0);
      forceHover(target);
      return {
        ok: true,
        action: "hover",
        url: String(g.location && g.location.href || "").split("?")[0].slice(0, 300),
        title: doc.title || "",
        x: Math.round(point.x),
        y: Math.round(point.y),
        tag: String(target.tagName || "").toLowerCase(),
        hovered: labelOf(target)
      };
    }
    if (action === "drag") {
      let html5Drag = function(el) {
        if (!el) return false;
        if (el.draggable === true) return true;
        return !!(el.getAttribute && el.getAttribute("draggable") === "true");
      }, html5Drop = function(el) {
        if (!el) return false;
        if (typeof el.hasAttribute === "function" && el.hasAttribute("ondrop")) return true;
        return /\bui-droppable\b|\bdroppable\b/.test(String(el.className || ""));
      }, closestHtml5 = function(el) {
        var n = el;
        var hops = 0;
        while (n && n.nodeType === 1 && hops < 8) {
          if (html5Drag(n) || html5Drop(n)) return n;
          n = n.parentElement;
          hops += 1;
        }
        return el;
      }, dragEv = function(name, el, pt) {
        var ev = null;
        try {
          if (view && typeof view.DragEvent === "function") {
            ev = new view.DragEvent(name, {
              bubbles: true,
              cancelable: true,
              view,
              clientX: pt.x,
              clientY: pt.y,
              screenX: pt.x,
              screenY: pt.y,
              dataTransfer: dt
            });
          }
        } catch (e11) {
          ev = null;
        }
        if (!ev) {
          try {
            ev = view && typeof view.Event === "function" ? new view.Event(name, { bubbles: true, cancelable: true }) : { type: name, bubbles: true, cancelable: true };
          } catch (e12) {
            ev = { type: name, bubbles: true, cancelable: true };
          }
        }
        try {
          Object.defineProperty(ev, "dataTransfer", { get: function() {
            return dt;
          }, configurable: true });
        } catch (e13) {
          try {
            ev.dataTransfer = dt;
          } catch (e14) {
          }
        }
        try {
          ev.clientX = pt.x;
          ev.clientY = pt.y;
        } catch (e15) {
        }
        if (typeof ev.preventDefault !== "function") ev.preventDefault = function() {
        };
        if (typeof ev.stopPropagation !== "function") ev.stopPropagation = function() {
        };
        if (el && typeof el.dispatchEvent === "function") el.dispatchEvent(ev);
      };
      var end = null;
      var toSel = spec && spec.toSelector ? String(spec.toSelector) : "";
      if (toSel) {
        var toEl = resolve(toSel);
        if (!toEl) return { ok: false, error: "not_found" };
        var toBox = typeof toEl.getBoundingClientRect === "function" ? toEl.getBoundingClientRect() : null;
        if (!toBox || toBox.width < 1 || toBox.height < 1) return { ok: false, error: "not_visible" };
        end = { x: toBox.left + toBox.width / 2, y: toBox.top + toBox.height / 2 };
      } else {
        var x2 = Number(spec && spec.x2);
        var y2 = Number(spec && spec.y2);
        if (!isFinite(x2) || !isFinite(y2)) return { ok: false, error: "x2 and y2, or toSelector, required" };
        end = { x: x2, y: y2 };
      }
      var resolvedEnd = toSel ? toEl : null;
      var hitEnd = typeof doc.elementFromPoint === "function" ? doc.elementFromPoint(end.x, end.y) : null;
      var endTarget = closestHtml5(resolvedEnd || hitEnd || target);
      var view = doc.defaultView || g.window || g;
      var store = {};
      var dt = {
        dropEffect: "move",
        effectAllowed: "all",
        files: [],
        items: [],
        types: [],
        setData: function(type, val) {
          store[String(type)] = String(val == null ? "" : val);
          dt.types = Object.keys(store);
        },
        getData: function(type) {
          var key = String(type);
          if (store[key] != null) return store[key];
          if (key === "text" && store["text/plain"] != null) return store["text/plain"];
          return "";
        },
        clearData: function(type) {
          if (type) delete store[String(type)];
          else store = {};
          dt.types = Object.keys(store);
        },
        setDragImage: function() {
        }
      };
      try {
        var nativeDt = view && view.DataTransfer ? new view.DataTransfer() : null;
        if (nativeDt) {
          var origSet = dt.setData;
          dt.setData = function(type, val) {
            origSet(type, val);
            try {
              nativeDt.setData(type, val);
            } catch (e7) {
            }
          };
        }
      } catch (e8) {
      }
      try {
        dt.setData("text/plain", labelOf(target) || target && target.id || "drag");
      } catch (e9) {
      }
      try {
        dt.setData("text/html", target && target.innerHTML || "");
      } catch (e10) {
      }
      var srcHtml = target && target.innerHTML;
      var dstHtml = endTarget && endTarget.innerHTML;
      fire(target, point, 0, 1, ["pointerdown", "mousedown"], 1);
      dragEv("dragstart", target, point);
      for (var step = 1; step <= 8; step++) {
        var mid = {
          x: point.x + (end.x - point.x) * step / 8,
          y: point.y + (end.y - point.y) * step / 8
        };
        fire(step === 8 ? endTarget : target, mid, 0, 1, ["pointermove", "mousemove"], 0);
        dragEv("drag", step === 8 ? endTarget : target, mid);
      }
      dragEv("dragenter", endTarget, end);
      dragEv("dragover", endTarget, end);
      dragEv("drop", endTarget, end);
      fire(endTarget, end, 0, 0, ["pointerup", "mouseup"], 1);
      dragEv("dragend", target, end);
      if (target && endTarget && target !== endTarget && html5Drag(target) && html5Drag(endTarget) && srcHtml !== dstHtml) {
        if (target.innerHTML !== dstHtml || endTarget.innerHTML !== srcHtml) {
          try {
            target.innerHTML = dstHtml;
            endTarget.innerHTML = srcHtml;
          } catch (e16) {
          }
        }
      }
      return {
        ok: true,
        action: "drag",
        url: String(g.location && g.location.href || "").split("?")[0].slice(0, 300),
        title: doc.title || "",
        x: Math.round(point.x),
        y: Math.round(point.y),
        x2: Math.round(end.x),
        y2: Math.round(end.y),
        tag: String(endTarget.tagName || "").toLowerCase(),
        dragged: true
      };
    }
    var names = buttonName === "right" ? ["pointerdown", "mousedown", "pointerup", "mouseup", "contextmenu"] : ["pointerdown", "mousedown", "pointerup", "mouseup"];
    fire(target, point, button, buttons, names, 1);
    if (count === 2 && buttonName === "left") {
      fire(target, point, button, buttons, names, 2);
    }
    if (buttonName === "left") {
      var activations = count === 2 ? 2 : 1;
      if (typeof target.click === "function") {
        for (var activation = 0; activation < activations; activation++) {
          try {
            target.click();
          } catch (e5) {
            break;
          }
        }
      } else if (typeof target.dispatchEvent === "function") {
        var clickView = target.ownerDocument && target.ownerDocument.defaultView || g.window || g;
        for (var fallbackActivation = 0; fallbackActivation < activations; fallbackActivation++) {
          var clickEvent = clickView && typeof clickView.MouseEvent === "function" ? new clickView.MouseEvent("click", { bubbles: true, cancelable: true, view: clickView, clientX: point.x, clientY: point.y, button: 0, detail: fallbackActivation + 1 }) : { type: "click", bubbles: true, cancelable: true };
          target.dispatchEvent(clickEvent);
        }
      }
      if (count === 2 && typeof target.dispatchEvent === "function") {
        var dbl = makeEvent("dblclick", point, 0, 1, 2);
        target.dispatchEvent(dbl);
      }
    }
    if (typeof target.focus === "function") {
      try {
        target.focus();
      } catch (e6) {
      }
    }
    return {
      ok: true,
      action: "click",
      url: String(g.location && g.location.href || "").split("?")[0].slice(0, 300),
      title: doc.title || "",
      x: Math.round(point.x),
      y: Math.round(point.y),
      tag: String(target.tagName || "").toLowerCase(),
      clicked: labelOf(target),
      button: buttonName,
      count
    };
  }
  function pressKeys(spec) {
    var g = typeof globalThis !== "undefined" ? globalThis : this;
    var doc = g.document;
    if (!doc) return { ok: false, error: "no_document" };
    var NAMED = {
      enter: { key: "Enter", code: "Enter", keyCode: 13 },
      tab: { key: "Tab", code: "Tab", keyCode: 9 },
      escape: { key: "Escape", code: "Escape", keyCode: 27 },
      esc: { key: "Escape", code: "Escape", keyCode: 27 },
      backspace: { key: "Backspace", code: "Backspace", keyCode: 8 },
      delete: { key: "Delete", code: "Delete", keyCode: 46 },
      space: { key: " ", code: "Space", keyCode: 32 },
      arrowup: { key: "ArrowUp", code: "ArrowUp", keyCode: 38 },
      arrowdown: { key: "ArrowDown", code: "ArrowDown", keyCode: 40 },
      arrowleft: { key: "ArrowLeft", code: "ArrowLeft", keyCode: 37 },
      arrowright: { key: "ArrowRight", code: "ArrowRight", keyCode: 39 },
      home: { key: "Home", code: "Home", keyCode: 36 },
      end: { key: "End", code: "End", keyCode: 35 },
      pageup: { key: "PageUp", code: "PageUp", keyCode: 33 },
      pagedown: { key: "PageDown", code: "PageDown", keyCode: 34 }
    };
    function isShown(el2) {
      if (!el2 || typeof el2.getBoundingClientRect !== "function") return true;
      var box = el2.getBoundingClientRect();
      if (box.width < 1 || box.height < 1) return false;
      try {
        var st = el2.ownerDocument && el2.ownerDocument.defaultView || g.window || g;
        if (st && st.getComputedStyle) {
          var cs = st.getComputedStyle(el2);
          if (cs && (cs.display === "none" || cs.visibility === "hidden")) return false;
        }
      } catch (e) {
      }
      return true;
    }
    function queryDeep(rootDoc, sel) {
      if (!rootDoc || !sel) return null;
      var nodes = [];
      try {
        nodes = rootDoc.querySelectorAll(sel);
      } catch (e0) {
        nodes = [];
      }
      var first = null;
      for (var n = 0; n < nodes.length; n++) {
        if (!first) first = nodes[n];
        if (isShown(nodes[n])) return nodes[n];
      }
      if (first) return first;
      var frames = [];
      try {
        frames = rootDoc.querySelectorAll("iframe,frame");
      } catch (e1) {
        return null;
      }
      for (var i2 = 0; i2 < frames.length; i2++) {
        var child = null;
        try {
          child = frames[i2].contentDocument;
        } catch (e2) {
          child = null;
        }
        if (!child) continue;
        var nested = queryDeep(child, sel);
        if (nested) return nested;
      }
      return null;
    }
    function resolve(sel) {
      if (!sel) return null;
      try {
        var resolver = g.CcResolveCcSelector;
        if (resolver && typeof resolver.resolveCcSelector === "function") {
          var byCc = resolver.resolveCcSelector(sel, doc);
          if (byCc) return byCc;
        }
      } catch (e) {
      }
      try {
        var clickApi = g.CcClickControl;
        if (clickApi && typeof clickApi.elementFor === "function") {
          var byClick = clickApi.elementFor(sel, doc);
          if (byClick) return byClick;
        }
      } catch (e2) {
      }
      return queryDeep(doc, sel);
    }
    function tagOf(el2) {
      return String(el2 && el2.tagName || "").toLowerCase();
    }
    function isEditable(el2) {
      if (!el2) return false;
      var tag = tagOf(el2);
      if (tag === "input" || tag === "textarea") return !el2.disabled && !el2.readOnly;
      return !!el2.isContentEditable;
    }
    function blockedText(el2) {
      if (!el2) return false;
      var t = String(el2.type || "").toLowerCase();
      if (t === "password" || t === "hidden") return true;
      var blob = ((el2.name || "") + " " + (el2.id || "") + " " + (el2.getAttribute && el2.getAttribute("aria-label") || "")).toLowerCase();
      return /captcha|otp|\bpin\b|cvv|card number/.test(blob);
    }
    function emitInput(el2, data, inputType) {
      var view = doc.defaultView || g.window || g;
      try {
        if (view && typeof view.InputEvent === "function") {
          el2.dispatchEvent(new view.InputEvent("input", { bubbles: true, cancelable: true, inputType: inputType || "insertText", data: data || null }));
          return;
        }
      } catch (e) {
      }
      try {
        if (view && typeof view.Event === "function") el2.dispatchEvent(new view.Event("input", { bubbles: true }));
      } catch (e2) {
      }
    }
    function insertText(el2, text2) {
      if (!el2 || !text2) return;
      var tag = tagOf(el2);
      if (tag === "input" || tag === "textarea") {
        var value = String(el2.value || "");
        var start = el2.selectionStart != null ? el2.selectionStart : value.length;
        var end = el2.selectionEnd != null ? el2.selectionEnd : start;
        el2.value = value.slice(0, start) + text2 + value.slice(end);
        var pos = start + String(text2).length;
        try {
          el2.setSelectionRange(pos, pos);
        } catch (e) {
        }
        emitInput(el2, text2, "insertText");
        return;
      }
      if (el2.isContentEditable && doc.execCommand) {
        try {
          doc.execCommand("insertText", false, text2);
        } catch (e2) {
        }
        emitInput(el2, text2, "insertText");
      }
    }
    function deleteOne(el2, forward) {
      var tag = tagOf(el2);
      if (tag !== "input" && tag !== "textarea") return;
      var value = String(el2.value || "");
      var start = el2.selectionStart != null ? el2.selectionStart : value.length;
      var end = el2.selectionEnd != null ? el2.selectionEnd : start;
      if (start !== end) {
        el2.value = value.slice(0, start) + value.slice(end);
        try {
          el2.setSelectionRange(start, start);
        } catch (e) {
        }
      } else if (forward) {
        el2.value = value.slice(0, start) + value.slice(start + 1);
        try {
          el2.setSelectionRange(start, start);
        } catch (e2) {
        }
      } else if (start > 0) {
        el2.value = value.slice(0, start - 1) + value.slice(start);
        try {
          el2.setSelectionRange(start - 1, start - 1);
        } catch (e3) {
        }
      }
      emitInput(el2, null, forward ? "deleteContentForward" : "deleteContentBackward");
    }
    function tabbables() {
      var nodes = doc.querySelectorAll('a[href], button, input, select, textarea, [tabindex]:not([tabindex="-1"])');
      var out = [];
      for (var i2 = 0; i2 < nodes.length; i2++) {
        var n = nodes[i2];
        if (n.disabled) continue;
        out.push(n);
      }
      return out;
    }
    function moveTab(el2, back) {
      var list = tabbables();
      if (!list.length) return el2;
      var idx = list.indexOf(el2);
      var next = back ? idx <= 0 ? list[list.length - 1] : list[idx - 1] : idx < 0 || idx >= list.length - 1 ? list[0] : list[idx + 1];
      if (next && typeof next.focus === "function") {
        try {
          next.focus();
        } catch (e) {
        }
      }
      return next || el2;
    }
    function named(raw) {
      var token = String(raw || "").trim();
      if (!token) return null;
      var lower = token.toLowerCase();
      if (NAMED[lower]) return NAMED[lower];
      if (token.length === 1) {
        var upper = token.toUpperCase();
        var code = /[a-z]/i.test(token) ? "Key" + upper : /[0-9]/.test(token) ? "Digit" + token : token;
        return { key: token, code, keyCode: token.charCodeAt(0) };
      }
      return null;
    }
    function fireKey(el2, def2, mods2) {
      var view = doc.defaultView || g.window || g;
      var opts = {
        key: def2.key,
        code: def2.code,
        keyCode: def2.keyCode,
        which: def2.keyCode,
        bubbles: true,
        cancelable: true,
        ctrlKey: !!mods2.ctrl,
        altKey: !!mods2.alt,
        shiftKey: !!mods2.shift,
        metaKey: !!mods2.meta
      };
      function send(name) {
        var ev = null;
        try {
          if (view && typeof view.KeyboardEvent === "function") ev = new view.KeyboardEvent(name, opts);
        } catch (e) {
          ev = null;
        }
        if (ev && typeof el2.dispatchEvent === "function") el2.dispatchEvent(ev);
        else if (typeof el2.dispatchEvent === "function") el2.dispatchEvent({ type: name, key: def2.key, bubbles: true, cancelable: true });
      }
      send("keydown");
      if (nudgeRange(el2, def2)) {
      } else if (def2.key === "Backspace" && isEditable(el2) && !mods2.ctrl && !mods2.alt && !mods2.meta) deleteOne(el2, false);
      else if (def2.key === "Delete" && isEditable(el2) && !mods2.ctrl && !mods2.alt && !mods2.meta) deleteOne(el2, true);
      else if (def2.key === "Tab") moveTab(el2, !!mods2.shift);
      else if (def2.key.length === 1 && !mods2.ctrl && !mods2.alt && !mods2.meta && isEditable(el2) && !blockedText(el2)) insertText(el2, def2.key);
      send("keypress");
      send("keyup");
    }
    function nudgeRange(el2, def2) {
      if (!el2 || tagOf(el2) !== "input") return false;
      if (String(el2.type || "").toLowerCase() !== "range") return false;
      var min = Number(el2.min);
      var max = Number(el2.max);
      var step = Number(el2.step);
      if (!isFinite(min)) min = 0;
      if (!isFinite(max)) max = 100;
      if (!isFinite(step) || step <= 0) step = 1;
      var cur = Number(el2.value);
      if (!isFinite(cur)) cur = min;
      var next = cur;
      if (def2.key === "ArrowRight" || def2.key === "ArrowUp") next = cur + step;
      else if (def2.key === "ArrowLeft" || def2.key === "ArrowDown") next = cur - step;
      else if (def2.key === "Home") next = min;
      else if (def2.key === "End") next = max;
      else return false;
      if (next > max) next = max;
      if (next < min) next = min;
      el2.value = String(next);
      emitInput(el2, null, "insertReplacementText");
      var view = doc.defaultView || g.window || g;
      try {
        if (view && typeof view.Event === "function") el2.dispatchEvent(new view.Event("change", { bubbles: true }));
      } catch (e) {
      }
      return true;
    }
    var selector = spec && spec.selector ? String(spec.selector) : "";
    var mods = {
      ctrl: !!(spec && spec.ctrl),
      alt: !!(spec && spec.alt),
      shift: !!(spec && spec.shift),
      meta: !!(spec && spec.meta)
    };
    var el = doc.activeElement || doc.body;
    if (selector) {
      var target = resolve(selector);
      if (!target) return { ok: false, error: "not_found" };
      if (typeof target.scrollIntoView === "function") {
        try {
          target.scrollIntoView({ block: "center", inline: "nearest" });
        } catch (e4) {
        }
      }
      if (typeof target.focus === "function") {
        try {
          target.focus();
        } catch (e5) {
        }
      }
      if (typeof target.click === "function" && tagOf(target) === "input") {
        try {
          target.click();
        } catch (e6) {
        }
      }
      el = target;
    }
    if (!el) el = doc.body;
    var typed = "";
    var keys = [];
    if (spec && spec.text) {
      var text = String(spec.text).slice(0, 300);
      if (blockedText(el)) return { ok: false, error: "blocked_field", tag: tagOf(el) };
      if (isEditable(el)) insertText(el, text);
      else if (el.isContentEditable) insertText(el, text);
      typed = text;
    }
    if (spec && spec.key) keys.push(spec.key);
    if (spec && Array.isArray(spec.keys)) {
      for (var k = 0; k < spec.keys.length && keys.length < 20; k++) keys.push(spec.keys[k]);
    }
    for (var i = 0; i < keys.length; i++) {
      var def = named(keys[i]);
      if (!def) return { ok: false, error: "unknown_key", key: String(keys[i] || "").slice(0, 40) };
      fireKey(el, def, mods);
      el = doc.activeElement || el;
    }
    var focused = doc.activeElement || el;
    return {
      ok: true,
      url: String(g.location && g.location.href || "").split("?")[0].slice(0, 300),
      title: doc.title || "",
      tag: tagOf(focused),
      focused: String(focused && (focused.id || focused.name || focused.getAttribute && focused.getAttribute("aria-label")) || tagOf(focused)).slice(0, 80),
      typed: typed ? typed.slice(0, 80) : "",
      key: keys.length ? String(keys[keys.length - 1]).slice(0, 40) : "",
      value: isEditable(focused) && !blockedText(focused) ? String(focused.value || "").slice(0, 80) : ""
    };
  }
  root.CcPagePointer = { clickAt, pressKeys };
})(typeof globalThis !== "undefined" ? globalThis : this);
if (typeof module !== "undefined") module.exports = globalThis.CcPagePointer;

/* ==== choose-autocomplete.ts ==== */
(function(root) {
  "use strict";
  var OPTION_QUERY = [
    '[role="option"]',
    '[role="listbox"] li',
    ".p-autocomplete-item",
    ".ui-autocomplete-list-item",
    ".auto-complete__option",
    '[class*="auto-complete__option"]',
    '[class*="-option"]',
    '[id^="react-select-"][id*="-option"]',
    '[id*="-option-"]'
  ].join(",");
  function norm(s) {
    return String(s || "").toLowerCase().replace(/[^a-z0-9]+/g, " ").replace(/\s+/g, " ").trim();
  }
  function tokens(s) {
    var n = norm(s);
    return n ? n.split(" ") : [];
  }
  function score(option, value) {
    var o = norm(option);
    var v = norm(value);
    if (!o || !v) return 0;
    if (o === v) return 100;
    var oTokens = tokens(option);
    var vTokens = tokens(value);
    if (o.indexOf(v) === 0 && (o.length === v.length || o.charAt(v.length) === " ")) return 90;
    if (oTokens[0] && oTokens[0] === v) return 88;
    if (vTokens.length > 1 && o.indexOf(v) === 0) return 86;
    var all = vTokens.length > 0 && vTokens.every(function(t) {
      return oTokens.indexOf(t) !== -1;
    });
    if (all && oTokens[0] === vTokens[0]) return 84;
    return 0;
  }
  function best(labels, value) {
    var list = Array.isArray(labels) ? labels : [];
    var winner = -1;
    var winnerScore = 0;
    var winnerLen = 0;
    for (var i = 0; i < list.length; i++) {
      var s = score(list[i], value);
      var len = norm(list[i]).length;
      if (s > winnerScore || s === winnerScore && s > 0 && len < winnerLen) {
        winner = i;
        winnerScore = s;
        winnerLen = len;
      }
    }
    if (winner < 0 || winnerScore < 84) return null;
    return { index: winner, label: String(list[winner]), score: winnerScore };
  }
  function textOf(el) {
    if (!el) return "";
    var raw = el.innerText || el.textContent || el.value || "";
    return String(raw).replace(/\s+/g, " ").trim();
  }
  function visible(el) {
    if (!el || typeof el.getBoundingClientRect !== "function") return true;
    var box = el.getBoundingClientRect();
    return box.width >= 2 && box.height >= 2;
  }
  function options(doc) {
    if (!doc || typeof doc.querySelectorAll !== "function") return [];
    var nodes = doc.querySelectorAll(OPTION_QUERY);
    var out = [];
    for (var i = 0; i < nodes.length; i++) {
      if (!visible(nodes[i]) || !textOf(nodes[i])) continue;
      out.push(nodes[i]);
    }
    return out;
  }
  function typeKeepFocus(el, value) {
    if (!el) return false;
    var str = String(value == null ? "" : value);
    var proto = el.tagName === "TEXTAREA" ? typeof window !== "undefined" && window.HTMLTextAreaElement ? window.HTMLTextAreaElement.prototype : null : typeof window !== "undefined" && window.HTMLInputElement ? window.HTMLInputElement.prototype : null;
    var desc = proto ? Object.getOwnPropertyDescriptor(proto, "value") : null;
    var setVal = desc && desc.set ? function(v) {
      desc.set.call(el, v);
    } : function(v) {
      el.value = v;
    };
    try {
      el.focus();
    } catch (e) {
    }
    try {
      el.click();
    } catch (e) {
    }
    if (el.value) {
      try {
        el.select();
      } catch (e) {
      }
      setVal("");
      try {
        el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "deleteContentBackward" }));
      } catch (e) {
      }
    }
    var current = "";
    for (var i = 0; i < str.length; i++) {
      var ch = str.charAt(i);
      var kc = ch.charCodeAt(0);
      var code = /[a-z]/i.test(ch) ? "Key" + ch.toUpperCase() : /[0-9]/.test(ch) ? "Digit" + ch : "";
      try {
        el.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, cancelable: true, key: ch, code, keyCode: kc, which: kc }));
      } catch (e) {
      }
      current += ch;
      setVal(current);
      try {
        el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: ch }));
      } catch (e) {
        try {
          el.dispatchEvent(new Event("input", { bubbles: true }));
        } catch (e2) {
        }
      }
      try {
        el.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: ch, code, keyCode: kc, which: kc }));
      } catch (e) {
      }
    }
    return true;
  }
  function open(el) {
    if (!el) return;
    if (typeof el.scrollIntoView === "function") {
      try {
        el.scrollIntoView({ block: "center", inline: "nearest" });
      } catch (e) {
      }
    }
    if (typeof el.focus === "function") el.focus();
    if (typeof el.click === "function") el.click();
    if (typeof el.dispatchEvent !== "function") return;
    var view = el.ownerDocument && el.ownerDocument.defaultView || (typeof window !== "undefined" ? window : null);
    try {
      el.dispatchEvent(new Event("focus", { bubbles: true }));
    } catch (e) {
    }
    var names = ["pointerdown", "mousedown", "pointerup", "mouseup", "click"];
    for (var i = 0; i < names.length; i++) {
      try {
        var ev = view && typeof view.MouseEvent === "function" ? new view.MouseEvent(names[i], { bubbles: true, cancelable: true, view, button: 0 }) : { type: names[i], bubbles: true, cancelable: true };
        el.dispatchEvent(ev);
      } catch (e) {
      }
    }
    try {
      var keyInit = { bubbles: true, cancelable: true, key: "ArrowDown", code: "ArrowDown", keyCode: 40, which: 40 };
      var key = view && typeof view.KeyboardEvent === "function" ? new view.KeyboardEvent("keydown", keyInit) : Object.assign({ type: "keydown" }, keyInit);
      el.dispatchEvent(key);
    } catch (e) {
    }
  }
  function activate(el) {
    if (!el) return;
    if (typeof el.dispatchEvent === "function") {
      try {
        el.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true }));
      } catch (e) {
        el.dispatchEvent({ type: "click", bubbles: true, cancelable: true });
      }
    }
    if (typeof el.click === "function") el.click();
  }
  function choose(doc, value) {
    var nodes = options(doc);
    var labels = [];
    for (var i = 0; i < nodes.length; i++) labels.push(textOf(nodes[i]));
    var picked = best(labels, value);
    if (!picked) return { pressed: false, reason: "not_found", clicked: "", score: 0 };
    activate(nodes[picked.index]);
    return { pressed: true, reason: "", clicked: picked.label, score: picked.score };
  }
  root.CcChooseAutocomplete = { best, options, open, choose, score, typeKeepFocus };
})(typeof globalThis !== "undefined" ? globalThis : this);
if (typeof module !== "undefined") module.exports = globalThis.CcChooseAutocomplete;

/* ==== ag-ui-loop.ts ==== */
(function(root) {
  "use strict";
  function norm(s) {
    return String(s || "").toLowerCase().replace(/[^a-z0-9]+/g, " ").replace(/\s+/g, " ").trim();
  }
  function landed(typed, actual, chosen) {
    var a = norm(actual);
    var t = norm(typed);
    var c = norm(chosen);
    if (c && t && !a && c === t) return true;
    if (!a) return false;
    if (c && a === c) return true;
    if (c && a !== t && (a.indexOf(c) !== -1 || c.indexOf(a) !== -1)) return true;
    if (!c && t && a === t) return true;
    return false;
  }
  function truthyChoice(v) {
    var n = norm(v);
    return n === "true" || n === "on" || n === "checked" || n === "yes" || n === "1";
  }
  function valuesMatch(field, el, actual) {
    var planned = String(field && field.value || "");
    var t = String(el && el.type || field && field.type || "").toLowerCase();
    var tag = String(el && el.tagName || "").toLowerCase();
    if (t === "checkbox" || t === "checkbox-agreement" || t === "checkbox-group") {
      var checked = !!(el && el.checked);
      if (truthyChoice(planned)) return checked;
      if (norm(planned) === "false" || norm(planned) === "off" || norm(planned) === "unchecked") return !checked;
      return checked && (norm(actual) === norm(planned) || truthyChoice(actual));
    }
    if (tag === "select" || t === "dropdown" || t === "select") {
      var opt = el && el.options && el.selectedIndex >= 0 ? el.options[el.selectedIndex] : null;
      var text = opt ? String(opt.text || "") : "";
      var val = opt ? String(opt.value || "") : String(actual || "");
      var p = norm(planned);
      if (!p) return false;
      return norm(text) === p || norm(val) === p || text && (norm(text).indexOf(p) !== -1 || p.indexOf(norm(text)) !== -1);
    }
    if (t === "range" || t === "slider") {
      var liveN = Number(el && el.value != null ? el.value : actual);
      var planN = Number(planned);
      return isFinite(liveN) && isFinite(planN) && liveN === planN;
    }
    return norm(actual) === norm(planned);
  }
  function isButton(field) {
    return /^(button|submit)$/i.test(field && field.type || "");
  }
  function labelOf(field) {
    return field && (field.visualLabel || field.label) || "";
  }
  function needsList(field, el) {
    var label = labelOf(field).toLowerCase();
    if (label.indexOf("station") !== -1) return true;
    if (!el || !el.getAttribute) return false;
    return !!(el.getAttribute("aria-autocomplete") || el.getAttribute("aria-controls"));
  }
  function readValue(el) {
    if (!el) return "";
    var ceAttr = el.getAttribute && el.getAttribute("contenteditable");
    if (el.isContentEditable === true || ceAttr != null && (String(ceAttr).toLowerCase().trim() === "true" || String(ceAttr).trim() === "")) {
      return String(el.innerText || el.textContent || "").replace(/\s+/g, " ").trim();
    }
    return el.value != null ? String(el.value) : "";
  }
  function liveDeps(doc) {
    return {
      resolve: function(selector) {
        var resolver = root.CcResolveCcSelector;
        if (!resolver || typeof resolver.resolveCcSelector !== "function") return null;
        return resolver.resolveCcSelector(selector, doc);
      },
      fill: async function(field) {
        if (typeof root.fillFormFieldsSequential !== "function") return;
        var label = labelOf(field);
        var mapping = {};
        var fbs = {};
        mapping[field.selector] = { value: String(field.value), type: field.type || "text", label, visualLabel: label };
        fbs[field.selector] = { label, visualLabel: label, source: "operator" };
        await root.fillFormFieldsSequential(mapping, fbs, {}, [field]);
      },
      open: function(el) {
        var chooser = root.CcChooseAutocomplete;
        if (chooser && typeof chooser.open === "function") chooser.open(el);
      },
      choose: function(value) {
        var chooser = root.CcChooseAutocomplete;
        if (!chooser || typeof chooser.choose !== "function") return { pressed: false, clicked: "" };
        return chooser.choose(doc, value);
      },
      press: function(field) {
        var clickApi = root.CcClickControl;
        if (!clickApi || typeof clickApi.press !== "function") return { pressed: false, reason: "not_found", clicked: "" };
        return clickApi.press(field, doc);
      },
      sleep: function(ms) {
        return new Promise(function(resolve) {
          setTimeout(resolve, ms);
        });
      },
      url: function() {
        return doc.defaultView && doc.defaultView.location && doc.defaultView.location.href || "";
      },
      title: function() {
        return doc.defaultView && doc.defaultView.document && doc.defaultView.document.title || (doc.title || "");
      }
    };
  }
  async function actOnce(field, doc, deps) {
    var el = deps.resolve(field.selector, doc);
    if (!el) {
      return { selector: field.selector, label: labelOf(field), result: "failed", failReason: "not_found", plannedValue: String(field.value || ""), actualValue: "" };
    }
    await deps.fill(field, el, doc);
    if (!needsList(field, el)) {
      var live = deps.resolve(field.selector, doc) || el;
      var plain = readValue(live);
      if (live && live.type === "checkbox") plain = live.checked ? live.value || "on" : "false";
      if (live && String(live.tagName || "").toLowerCase() === "select" && live.options && live.selectedIndex >= 0) {
        var opt = live.options[live.selectedIndex];
        plain = opt && (opt.text || opt.value) || plain;
      }
      var ok = valuesMatch(field, live, plain);
      return {
        selector: field.selector,
        label: labelOf(field),
        result: ok ? "filled" : "failed",
        failReason: ok ? "" : "value_mismatch",
        plannedValue: String(field.value || ""),
        actualValue: plain
      };
    }
    el = deps.resolve(field.selector, doc) || el;
    var chooser = root.CcChooseAutocomplete;
    if (chooser && typeof chooser.typeKeepFocus === "function") chooser.typeKeepFocus(el, field.value);
    if (deps.open) deps.open(el);
    if (deps.sleep) await deps.sleep(300);
    var chosen = null;
    var attempts = 0;
    while (attempts < 12) {
      chosen = deps.choose(String(field.value), doc);
      if (chosen && chosen.pressed) break;
      if (deps.open && attempts === 3) deps.open(el);
      attempts += 1;
      if (deps.sleep) await deps.sleep(250);
    }
    if (chosen && chosen.pressed && deps.sleep) await deps.sleep(200);
    var actual = readValue(deps.resolve(field.selector, doc) || el);
    var choice = chosen && chosen.clicked || "";
    if (landed(field.value, actual, choice)) {
      return {
        selector: field.selector,
        label: labelOf(field),
        result: "chosen",
        failReason: "",
        plannedValue: String(field.value || ""),
        actualValue: actual || choice
      };
    }
    return {
      selector: field.selector,
      label: labelOf(field),
      result: chosen && chosen.pressed ? "not_landed" : "no_option",
      failReason: chosen && chosen.pressed ? "not_landed" : "no_option",
      plannedValue: String(field.value || ""),
      actualValue: actual || choice
    };
  }
  async function run(fields, doc, deps) {
    var list = Array.isArray(fields) ? fields : [];
    deps = deps || liveDeps(doc || (typeof document !== "undefined" ? document : null));
    var records = [];
    var stopped = false;
    var i = 0;
    for (i = 0; i < list.length; i++) {
      var field = list[i];
      if (!field || !field.selector) continue;
      if (isButton(field)) continue;
      if (field.value == null || String(field.value) === "") continue;
      if (stopped) {
        records.push({ selector: field.selector, label: labelOf(field), result: "skipped", failReason: "previous_field", plannedValue: String(field.value), actualValue: "" });
        continue;
      }
      var record = await actOnce(field, doc, deps);
      if (record.result !== "filled" && record.result !== "chosen") {
        record = await actOnce(field, doc, deps);
      }
      records.push(record);
      if (record.result === "not_landed" || record.result === "no_option") stopped = true;
    }
    for (i = 0; i < list.length; i++) {
      var button = list[i];
      if (!button || !isButton(button)) continue;
      if (stopped) {
        records.push({ selector: button.selector, label: labelOf(button), result: "skipped", failReason: "previous_field", plannedValue: labelOf(button), actualValue: "" });
        continue;
      }
      var beforeUrl = deps.url ? deps.url() : "";
      var beforeTitle = deps.title ? deps.title() : "";
      var pressed = deps.press ? deps.press(button, doc) : { pressed: false, reason: "not_found", clicked: "" };
      if (deps.sleep) await deps.sleep(700);
      var changed = (deps.url ? deps.url() : "") !== beforeUrl || (deps.title ? deps.title() : "") !== beforeTitle;
      var didPress = !!(pressed && pressed.pressed);
      records.push({
        selector: pressed && pressed.selector || button.selector,
        label: labelOf(button),
        result: didPress ? "clicked" : "no_effect",
        failReason: didPress ? "" : pressed && pressed.reason || "not_found",
        plannedValue: labelOf(button),
        actualValue: pressed && pressed.clicked || "",
        moved: changed
      });
    }
    return { stopped, records };
  }
  root.CcAgUiLoop = { landed, run, needsList };
})(typeof globalThis !== "undefined" ? globalThis : this);
if (typeof module !== "undefined") module.exports = globalThis.CcAgUiLoop;

/* ==== detect-fill-strategy.ts ==== */
(function(root2) {
  "use strict";
  var STRATEGY_REGISTRY = {
    "ng-dropdown-click": {
      name: "ng-dropdown-click",
      description: "Angular custom ng-dropdown: click trigger, wait for li options, click match",
      applies: function(el, type) {
        return type === "ng-dropdown" || el && el.classList && el.classList.contains("ng-dropdown");
      },
      verify: {
        method: "visual_text",
        check: function(el, expected) {
          var displayed = el.querySelector(".select-type,.value-area,.ng-value-label");
          return displayed ? displayed.textContent.trim().toLowerCase().includes(expected.toLowerCase().slice(0, 6)) : false;
        },
        timeout: 1e3
      }
    },
    "mat-select-click": {
      name: "mat-select-click",
      description: "Angular Material mat-select: click trigger, wait for panel, click option",
      applies: function(el, type) {
        return type === "mat-select" || el && el.tagName === "MAT-SELECT";
      },
      verify: {
        method: "visual_text",
        check: function(el, expected) {
          var v = el.querySelector(".mat-select-value-text,.mat-mdc-select-value-text");
          return v ? v.textContent.trim().toLowerCase().includes(expected.toLowerCase().slice(0, 4)) : false;
        },
        timeout: 500
      }
    },
    "native-select": {
      name: "native-select",
      description: "Native <select>: set value via nativeSetter, dispatch change",
      applies: function(el, type) {
        return type === "select" || el && el.tagName === "SELECT";
      },
      verify: {
        method: "dom_value",
        check: function(el, expected) {
          var norm = function(s) {
            return s.toLowerCase().replace(/[^a-z0-9\s]/g, " ").replace(/\s+/g, " ").trim();
          };
          return norm(el.value) === norm(expected) || norm(el.options && el.options[el.selectedIndex] && el.options[el.selectedIndex].text || "").includes(norm(expected).slice(0, 6));
        },
        timeout: 300
      }
    },
    "dwr-cascade-select": {
      name: "dwr-cascade-select",
      description: "ServicePlus DWR cascade: waitForOptions then set value, re-apply after DWR reset",
      applies: function(el, type) {
        return type === "select" && el && el.getAttribute && el.getAttribute("data-datatype") === "custLGDHierarchy";
      },
      verify: {
        method: "dom_value",
        check: function(el, expected) {
          var norm = function(s) {
            return s.toLowerCase().replace(/[^a-z0-9\s]/g, " ").replace(/\s+/g, " ").trim();
          };
          return norm(el.options && el.options[el.selectedIndex] && el.options[el.selectedIndex].text || "").includes(norm(expected).slice(0, 4));
        },
        timeout: 500
      }
    },
    "text-input": {
      name: "text-input",
      description: "Text/email/tel input: nativeInputValueSetter + input/change events",
      applies: function(el, type) {
        var EXCLUDED = [
          "select",
          "ng-dropdown",
          "mat-select",
          "mat-radio",
          "mat-checkbox",
          "radio",
          "checkbox",
          "radio-group",
          "radio-click",
          "checkbox-group",
          "checkbox-agreement"
        ];
        return EXCLUDED.indexOf(type) === -1;
      },
      verify: {
        method: "dom_value",
        check: function(el, expected) {
          return el.value === expected || el.value.includes(expected.slice(0, 8));
        },
        timeout: 200
      }
    },
    "radio-click": {
      name: "radio-click",
      description: "Click a specific radio option (resolved by planner)",
      applies: function(el, type) {
        return type === "radio-click" || type === "radio" || type === "radio-group" || el && el.type === "radio";
      },
      verify: {
        method: "dom_value",
        check: function(el) {
          return !!(el && (el.checked || el.querySelector && el.querySelector("input[type=radio]:checked")));
        },
        timeout: 200
      }
    }
  };
  function detectFillStrategy(el, type) {
    var keys = Object.keys(STRATEGY_REGISTRY);
    for (var i = 0; i < keys.length; i++) {
      try {
        if (STRATEGY_REGISTRY[keys[i]].applies(el, type)) return keys[i];
      } catch (e) {
      }
    }
    return type || "unknown";
  }
  root2.CcDetectFillStrategy = {
    detectFillStrategy,
    STRATEGY_REGISTRY
  };
})(typeof globalThis !== "undefined" ? globalThis : this);
if (typeof module !== "undefined") module.exports = root.CcDetectFillStrategy;

/* ==== post-fill-corrections.ts ==== */
(function(root2) {
  "use strict";
  function readFieldValue(el) {
    if (!el) return "";
    if (el.tagName === "SELECT") {
      var opt = el.options && el.options[el.selectedIndex];
      return (opt ? opt.text || opt.value : "") || "";
    }
    if (el.classList && el.classList.contains("ng-dropdown")) {
      var vEl = el.querySelector(".value-area .value,.select-type,.ng-value-label");
      return vEl && vEl.textContent.trim() || "";
    }
    return el.value || "";
  }
  function installCorrectionsObserver(opts) {
    opts = opts || {};
    var entries = opts.entries || [];
    var filledBySource = opts.filledBySource || {};
    var allFields = opts.allFields || [];
    var getEl = opts.getEl || function(s) {
      return document.querySelector(s);
    };
    var records = opts.records || [];
    var settleDelayMs = typeof opts.settleDelayMs === "number" ? opts.settleDelayMs : 1e4;
    setTimeout(function() {
      var _ccBackendUrl = document.body.getAttribute("data-cc-backend") || "";
      var _ccFormKey = document.body.getAttribute("data-cc-formkey") || "";
      var snapshot = {}, fieldMeta = {};
      for (var i = 0; i < entries.length; i++) {
        var sel = entries[i][0], fd = entries[i][1];
        var el = getEl(sel);
        if (!el) continue;
        snapshot[sel] = readFieldValue(el);
        var rec = records.find(function(r) {
          return r.selector === sel;
        });
        fieldMeta[sel] = {
          label: filledBySource[sel] && filledBySource[sel].label || sel,
          semanticKey: filledBySource[sel] && filledBySource[sel].semanticKey || "",
          profileKey: filledBySource[sel] && filledBySource[sel].profileKey || "",
          plugin: rec && rec.plugin || null,
          strategy: rec && rec.strategy || "",
          originalResult: rec && rec.result || "unknown",
          autofilledValue: fd.value
        };
      }
      if (Array.isArray(allFields)) {
        for (var j = 0; j < allFields.length; j++) {
          var f = allFields[j];
          if (snapshot[f.selector] !== void 0) continue;
          var el2 = getEl(f.selector);
          if (!el2) continue;
          snapshot[f.selector] = readFieldValue(el2);
          fieldMeta[f.selector] = {
            label: f.label || f.selector,
            semanticKey: "",
            profileKey: "",
            plugin: null,
            strategy: "unmapped",
            originalResult: "unmapped",
            autofilledValue: ""
          };
        }
      }
      function captureCorrections(trigger) {
        var out = [];
        Object.keys(snapshot).forEach(function(s) {
          var el3 = getEl(s);
          if (!el3) return;
          var cur = readFieldValue(el3);
          if (cur !== snapshot[s] && cur !== "") {
            var m = fieldMeta[s] || {};
            out.push({
              selector: s,
              field: m.label,
              semanticKey: m.semanticKey,
              profileKey: m.profileKey,
              autofilledValue: m.autofilledValue,
              snapshotValue: snapshot[s],
              finalOperatorValue: cur,
              correctionType: !snapshot[s] || snapshot[s] === "" ? "completion" : "override",
              originalResult: m.originalResult,
              plugin: m.plugin,
              strategy: m.strategy,
              trigger,
              ts: Date.now()
            });
          }
        });
        return out;
      }
      function postCorrections(trigger) {
        var corrections = captureCorrections(trigger);
        if (!corrections.length) return;
        try {
          document.body.setAttribute("data-cc-corrections", JSON.stringify(corrections));
        } catch (e) {
        }
        if (_ccBackendUrl) {
          var tok = document.body.getAttribute("data-cc-token") || "";
          var pid = document.body.getAttribute("data-cc-profile-id") || "";
          var hdrs = { "Content-Type": "application/json" };
          if (tok) hdrs["Authorization"] = "Bearer " + tok;
          fetch(_ccBackendUrl + "/corrections", {
            method: "POST",
            headers: hdrs,
            body: JSON.stringify({
              hostname: location.hostname,
              semanticFormKey: _ccFormKey,
              profileId: pid,
              trigger,
              corrections
            })
          }).catch(function() {
          });
        }
      }
      document.addEventListener("click", function(e) {
        var btn = e.target.closest('button,input[type="submit"],[type="submit"],.btn-submit,.submit-btn');
        if (!btn) return;
        var txt = (btn.textContent || btn.value || "").toLowerCase();
        if (/submit|save|next|continue|proceed|finalize/i.test(txt) || btn.type === "submit") {
          postCorrections("submit");
        }
      }, true);
      window.addEventListener("beforeunload", function() {
        postCorrections("unload");
      });
    }, settleDelayMs);
  }
  root2.CcPostFillCorrections = { installCorrectionsObserver };
})(typeof globalThis !== "undefined" ? globalThis : this);
if (typeof module !== "undefined") module.exports = root.CcPostFillCorrections;

/* ==== fill-one-ng.ts ==== */
(function(root2) {
  "use strict";
  function fillNg(el, selector, value, type, elType, ctx) {
    if (!(elType === "ng-dropdown" || type === "ng-dropdown")) return null;
    var portalAdapters = ctx.portalAdapters || {};
    var filledBySource = ctx.filledBySource || {};
    var _replayResults = ctx._replayResults || {};
    var _ccRecords = ctx._ccRecords || [];
    var RUNTIME_VERSION = ctx.RUNTIME_VERSION || "";
    var _flushRecords = ctx._flushRecords || function() {
    };
    var _nos = root2.CcNgOptionScorer || {};
    var _nsm = root2.CcNgSessionManager || {};
    var _bfr = root2.CcBuildFillRecord || {};
    var startedAtForJqueryUi = Date.now();
    var jqueryUi = root2.CcJQueryUiAdapter || {};
    if (jqueryUi.isSelectmenuButton && jqueryUi.isSelectmenuButton(el)) {
      if (!jqueryUi.selectmenu) return 0;
      return Promise.resolve(jqueryUi.selectmenu(el, value)).then(function(result) {
        var ok = !!(result && result.success && result.verified);
        var reason = ok ? null : result && result.reason || "jquery-ui-selection-not-confirmed";
        _replayResults[filledBySource[selector] && filledBySource[selector].label || selector] = ok ? "ok" : reason;
        var rec = _bfr.buildFillRecord ? _bfr.buildFillRecord(
          {
            selector,
            value,
            type: "ng-dropdown",
            result: ok ? "filled" : "skipped",
            failReason: reason,
            strategy: "jquery-ui-selectmenu",
            durationMs: Date.now() - startedAtForJqueryUi
          },
          { rv: RUNTIME_VERSION }
        ) : {
          selector,
          value,
          type: "ng-dropdown",
          result: ok ? "filled" : "skipped",
          failReason: reason,
          strategy: "jquery-ui-selectmenu",
          durationMs: Date.now() - startedAtForJqueryUi,
          ts: Date.now(),
          rv: RUNTIME_VERSION,
          fillMode: "sequential"
        };
        _ccRecords.push(rec);
        _flushRecords();
        return ok ? 1 : 0;
      }).catch(function() {
        return 0;
      });
    }
    var rootClass = el.className ? el.className.trim().split(/\s+/)[0] : "ng-dropdown";
    var adapter = portalAdapters[rootClass] || portalAdapters["ng-dropdown"];
    if (!adapter) {
      var _noAdapterLabel = filledBySource[selector] && filledBySource[selector].label || selector;
      _replayResults[_noAdapterLabel] = "no-adapter";
      try {
        sessionStorage.setItem("_cc_replay_results", JSON.stringify(_replayResults));
      } catch (e) {
      }
      return 0;
    }
    var _label = filledBySource[selector] && filledBySource[selector].label || selector;
    var trigger = el.querySelector(adapter.triggerSelector) || el;
    if (!window._ccReplaySessions) window._ccReplaySessions = /* @__PURE__ */ new Map();
    if (_nsm.cancelSession) _nsm.cancelSession(_label, window._ccReplaySessions);
    var session = _nsm.createSession ? _nsm.createSession(_label, window._ccReplaySessions) : {
      id: Math.random().toString(36).slice(2, 8),
      fieldKey: _label,
      resolved: false,
      cancelled: false,
      pollTimer: null,
      timeoutIds: [],
      observer: null,
      startedAt: Date.now()
    };
    if (!_nsm.createSession) window._ccReplaySessions.set(_label, session);
    function isVisible(node) {
      return window.ccDomUtils && window.ccDomUtils.isVisible ? window.ccDomUtils.isVisible(node) : !!(node && node.offsetParent !== null);
    }
    function cleanupAndRecord(result) {
      if (session.resolved && result !== session._result) return;
      session.resolved = true;
      session._result = result;
      if (_nsm.cleanupSession) {
        _nsm.cleanupSession(session, window._ccReplaySessions, _label);
      } else {
        try {
          clearInterval(session.pollTimer);
        } catch (e) {
        }
        (session.timeoutIds || []).forEach(function(id) {
          try {
            clearTimeout(id);
          } catch (e) {
          }
        });
        if (session.observer) {
          session.observer.disconnect();
          session.observer = null;
        }
        window._ccReplaySessions.delete(_label);
      }
      _replayResults[_label] = result;
      try {
        sessionStorage.setItem("_cc_replay_results", JSON.stringify(_replayResults));
      } catch (e) {
      }
      var _isOk = result === "ok";
      var rec = _bfr.buildFillRecord ? _bfr.buildFillRecord(
        {
          selector,
          value,
          type: "ng-dropdown",
          result: _isOk ? "filled" : "skipped",
          failReason: _isOk ? null : result,
          strategy: "ng-dropdown-click",
          durationMs: Date.now() - session.startedAt
        },
        { rv: RUNTIME_VERSION }
      ) : {
        selector,
        value,
        type: "ng-dropdown",
        result: _isOk ? "filled" : "skipped",
        failReason: _isOk ? null : result,
        strategy: "ng-dropdown-click",
        durationMs: Date.now() - session.startedAt,
        ts: Date.now(),
        rv: RUNTIME_VERSION,
        fillMode: "sequential"
      };
      _ccRecords.push(rec);
      _flushRecords();
    }
    var OVERLAY_TAGS = [
      "app-dropdown",
      "ul",
      "ng-dropdown-panel",
      "cdk-overlay-container",
      ".dropdown-options",
      ".options-list",
      ".dropdown-menu",
      ".ng-dropdown-panel"
    ];
    var addedNodes = [];
    var _trace = {
      triggerLabel: _label,
      overlayFound: false,
      overlayTag: "",
      mutationCount: 0,
      optionCount: 0,
      matchedOption: "",
      clicked: false,
      verifyStatus: "",
      durationMs: 0
    };
    trigger.click();
    var mo = new MutationObserver(function(mutations) {
      if (session.cancelled || session.resolved) return;
      mutations.forEach(function(m) {
        m.addedNodes.forEach(function(n) {
          if (n.nodeType === 1) addedNodes.push(n);
        });
      });
    });
    session.observer = mo;
    mo.observe(document.body, { childList: true, subtree: true });
    var _lastMutation = Date.now();
    var _stabilizeMo = new MutationObserver(function() {
      _lastMutation = Date.now();
    });
    _stabilizeMo.observe(document.body, { childList: true, subtree: true, attributes: true });
    function waitStable(cb) {
      var check = setInterval(function() {
        if (session.cancelled) {
          clearInterval(check);
          _stabilizeMo.disconnect();
          return;
        }
        if (Date.now() - _lastMutation >= 150) {
          clearInterval(check);
          _stabilizeMo.disconnect();
          cb();
        }
      }, 50);
      var capId = setTimeout(function() {
        clearInterval(check);
        _stabilizeMo.disconnect();
        if (!session.cancelled) cb();
      }, 1200);
      session.timeoutIds.push(capId);
    }
    waitStable(function() {
      if (session.cancelled || session.resolved) return;
      mo.disconnect();
      session.observer = null;
      _trace.mutationCount = addedNodes.length;
      var _optQ = adapter.optionSelector || "li,.ng-option,mat-option,.dropdown-item";
      var activeOverlayRoot = null;
      var trigRect = trigger.getBoundingClientRect();
      for (var i = 0; i < addedNodes.length; i++) {
        var node = addedNodes[i];
        if (!isVisible(node)) continue;
        var lis = Array.from(node.querySelectorAll(_optQ)).filter(function(o) {
          return isVisible(o);
        });
        if (lis.length > 0) {
          activeOverlayRoot = node;
          break;
        }
      }
      if (!activeOverlayRoot) {
        var bestDist = Infinity;
        OVERLAY_TAGS.forEach(function(sel) {
          try {
            document.querySelectorAll(sel).forEach(function(node2) {
              var lis2 = Array.from(node2.querySelectorAll(_optQ)).filter(function(o) {
                return isVisible(o);
              });
              if (lis2.length === 0) return;
              var r = node2.getBoundingClientRect();
              var dist = Math.abs(r.left - trigRect.left) + Math.abs(r.top - trigRect.bottom);
              if (dist < bestDist) {
                bestDist = dist;
                activeOverlayRoot = node2;
              }
            });
          } catch (e) {
          }
        });
      }
      if (!activeOverlayRoot && adapter.optionsContainer) {
        activeOverlayRoot = document.querySelector(adapter.optionsContainer) || null;
      }
      _trace.overlayFound = !!activeOverlayRoot;
      _trace.overlayTag = activeOverlayRoot ? activeOverlayRoot.tagName + "." + activeOverlayRoot.className.slice(0, 40) : "NONE";
      var attempts = 0;
      session.pollTimer = setInterval(function() {
        if (session.cancelled || session.resolved) {
          clearInterval(session.pollTimer);
          return;
        }
        attempts++;
        var searchRoot = activeOverlayRoot || document.body;
        var opts = Array.from(searchRoot.querySelectorAll(_optQ)).filter(function(o) {
          return isVisible(o);
        });
        if (opts.length === 0 && searchRoot !== document) {
          opts = Array.from(document.querySelectorAll(_optQ)).filter(function(o) {
            return isVisible(o) && !el.contains(o) && o.closest('[class*="dropdown"],[class*="options"],[class*="list"]');
          });
        }
        var v = value.toLowerCase().trim();
        _trace.optionCount = opts.length;
        var scoreOption = _nos.scoreOption || function(ot) {
          ot = String(ot || "").toLowerCase().trim();
          if (ot === v) return 100;
          if (ot.includes(v)) return 80;
          if (v.includes(ot) && ot.length > 3) return 70;
          return 0;
        };
        var bestOpt = null, bestScore = 0;
        opts.forEach(function(o) {
          var score = scoreOption(o.textContent.trim(), v);
          if (score > bestScore) {
            bestScore = score;
            bestOpt = o;
          }
        });
        var opt = bestScore >= 50 ? bestOpt : null;
        if (opt) {
          clearInterval(session.pollTimer);
          if (session.cancelled || session.resolved) return;
          _trace.matchedOption = opt.textContent.trim();
          _trace.clicked = true;
          ["pointerdown", "mousedown", "mouseup", "click"].forEach(function(ev) {
            opt.dispatchEvent(new MouseEvent(ev, { bubbles: true, cancelable: true }));
          });
          var verifyStart = Date.now();
          var triggerInitialText = trigger.textContent.trim();
          var verifyPoll = setInterval(function() {
            if (session.cancelled || session.resolved) {
              clearInterval(verifyPoll);
              return;
            }
            var verifyEl = adapter.verifySelector ? el.querySelector(adapter.verifySelector) : null;
            var displayed = verifyEl ? verifyEl.textContent.trim() : "";
            var overlayGone = activeOverlayRoot ? !isVisible(activeOverlayRoot) : false;
            var triggerChanged = trigger.textContent.trim() !== triggerInitialText;
            var ariaSelected = opt.getAttribute("aria-selected") === "true";
            var ok = displayed && !/^(select|choose|--)$/i.test(displayed) || overlayGone || triggerChanged || ariaSelected;
            if (ok || Date.now() - verifyStart >= 3e3) {
              clearInterval(verifyPoll);
              if (session.resolved) return;
              _trace.verifyStatus = ok ? "ok" : "verify-fail";
              _trace.durationMs = Date.now() - session.startedAt;
              cleanupAndRecord(_trace.verifyStatus);
            }
          }, 200);
        } else if (attempts >= 10) {
          clearInterval(session.pollTimer);
          if (session.resolved) return;
          document.body.click();
          _trace.durationMs = Date.now() - session.startedAt;
          cleanupAndRecord("no-option");
        }
      }, 300);
    });
    return 1;
  }
  root2.CcFillOneNg = {
    fillNg
  };
})(typeof globalThis !== "undefined" ? globalThis : this);
if (typeof module !== "undefined") module.exports = root.CcFillOneNg;

/* ==== fill-one-select.ts ==== */
(function(root2) {
  "use strict";
  function fillSelect(el, selector, value, mapping) {
    if ((el.tagName || "").toLowerCase() !== "select") return null;
    var norm = function(s) {
      return s.toLowerCase().replace(/[^a-z0-9\s]/g, " ").replace(/\s+/g, " ").trim();
    };
    var v = norm(value);
    var extraValues = [];
    var mapEntry = mapping && mapping[selector];
    if (mapEntry && mapEntry.monthNum) {
      extraValues.push(mapEntry.monthNum.toString());
      if (mapEntry.monthShort) extraValues.push(mapEntry.monthShort.toLowerCase());
    }
    function findOpt(options) {
      return window.ccMatchOption ? window.ccMatchOption(value, options, { extraValues }) : null;
    }
    function applySelect(el2, opt2) {
      el2.focus();
      el2.dispatchEvent(new Event("focus", { bubbles: true }));
      Array.from(el2.options).forEach(function(o) {
        o.selected = false;
      });
      opt2.selected = true;
      el2.selectedIndex = opt2.index;
      var nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, "value");
      if (nativeSetter) nativeSetter.set.call(el2, opt2.value);
      else el2.value = opt2.value;
      ["mousedown", "mouseup", "click", "input"].forEach(function(ev) {
        el2.dispatchEvent(new Event(ev, { bubbles: true, cancelable: true }));
      });
      var jqueryInteraction = root2.CcJQueryInteractionAdapter || {};
      if (jqueryInteraction.trigger) jqueryInteraction.trigger(el2, "change");
      else el2.dispatchEvent(new Event("change", { bubbles: true, cancelable: true }));
      try {
        el2.dispatchEvent(new Event("propertychange", { bubbles: true }));
      } catch (e) {
      }
      el2.dispatchEvent(new Event("blur", { bubbles: true }));
      var _rv = opt2.value, _ri = opt2.index;
      setTimeout(function() {
        if (el2.value !== _rv || el2.selectedIndex !== _ri) {
          opt2.selected = true;
          el2.selectedIndex = _ri;
          if (nativeSetter) nativeSetter.set.call(el2, _rv);
          else el2.value = _rv;
          el2.dispatchEvent(new Event("change", { bubbles: true }));
        }
      }, 300);
      setTimeout(function() {
        el2.dispatchEvent(new Event("change", { bubbles: true }));
      }, 700);
      setTimeout(function() {
        if (el2.value !== _rv) {
          el2.selectedIndex = _ri;
          el2.value = _rv;
          el2.dispatchEvent(new Event("change", { bubbles: true }));
        }
      }, 3500);
      return 1;
    }
    var allOptions = Array.from(el.options);
    var opt = findOpt(allOptions);
    if (opt) return applySelect(el, opt);
    var attempts = 0;
    var interval = setInterval(function() {
      var allOpts = Array.from(el.options);
      var realOpts = allOpts.filter(function(o) {
        if (!o.value || o.value === "0" || o.value === "-1" || o.value === "") return false;
        var txt = o.text.toLowerCase();
        return !txt.includes("select") && !txt.includes("choose") && !txt.includes("loading") && txt !== "--";
      });
      if (realOpts.length === 0 && attempts < 10) {
        attempts++;
        return;
      }
      var opt2 = findOpt(allOpts);
      if (opt2) {
        clearInterval(interval);
        applySelect(el, opt2);
        return;
      }
      if (++attempts >= 15) {
        clearInterval(interval);
        var llmKey = window._cc_llm_key || (document.body.getAttribute("data-cc-llm-key") || "");
        if (llmKey && realOpts.length > 0) {
          var optTexts = realOpts.map(function(o) {
            return o.text.trim();
          }).join("\n");
          window.ccLLM && window.ccLLM.call({
            apiKey: llmKey,
            baseUrl: document.body.getAttribute("data-cc-llm-url") || void 0,
            model: document.body.getAttribute("data-cc-llm-model") || void 0,
            userPrompt: 'From these dropdown options, which best matches "' + value + '"? Reply with ONLY the exact option text, nothing else.\n\nOptions:\n' + optTexts,
            maxTokens: 50
          }).then(function(result) {
            var aiText = (result.text || "").trim();
            if (aiText) {
              var aiOpt = realOpts.find(function(o) {
                return o.text.trim() === aiText;
              }) || realOpts.find(function(o) {
                return o.text.trim().toLowerCase().includes(aiText.toLowerCase());
              });
              if (aiOpt) applySelect(el, aiOpt);
            }
          }).catch(function() {
          });
        }
      }
    }, 200);
    return 1;
  }
  root2.CcFillOneSelect = {
    fillSelect
  };
})(typeof globalThis !== "undefined" ? globalThis : this);
if (typeof module !== "undefined") module.exports = root.CcFillOneSelect;

/* ==== fill-one-date.ts ==== */
(function(root2) {
  "use strict";
  function fillDate(el, selector, value) {
    var _pdv = root2.CcParseDateValue || {};
    var parseDateValue = _pdv.parseDateValue || function(v) {
      return { dateObj: new Date(v) };
    };
    if (el._flatpickr || el.classList.contains("flatpickr-input")) {
      var fp = el._flatpickr;
      var parsed = parseDateValue(value);
      var dateObj = parsed.dateObj;
      if (fp && !isNaN(dateObj)) {
        fp.setDate(dateObj, true);
      } else {
        var niv = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value");
        el.focus();
        if (niv) niv.set.call(el, value);
        else el.value = value;
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
        el.blur();
      }
      return el.value ? 1 : 0;
    }
    var _jqueryUi = root2.CcJQueryUiAdapter || {};
    if (_jqueryUi.isDatepickerInput && _jqueryUi.isDatepickerInput(el)) {
      return _jqueryUi.fillDatepicker ? _jqueryUi.fillDatepicker(el, value, parseDateValue) : 0;
    }
    if (el.getAttribute("matdatepicker") !== null || el.getAttribute("matInput") !== null && el.closest("mat-datepicker-toggle,mat-form-field") && (el.type === "text" || el.type === "date")) {
      var niv3 = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value");
      el.focus();
      if (niv3) niv3.set.call(el, value);
      else el.value = value;
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      el.dispatchEvent(new CustomEvent("dateChange", { bubbles: true, detail: { value } }));
      el.dispatchEvent(new CustomEvent("dateInput", { bubbles: true, detail: { value } }));
      el.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: value.slice(-1) || "Enter" }));
      el.blur();
      return 1;
    }
    if (el.type === "date" || el.type === "datetime-local" || el.type === "month" || el.type === "week") {
      var parsed3 = parseDateValue(value);
      var isoValue;
      if (el.type === "datetime-local" && String(value || "").includes("T")) {
        isoValue = String(value);
      } else if (parsed3 && parsed3.isoDate) {
        isoValue = el.type === "month" ? parsed3.isoMonth : parsed3.isoDate;
      } else {
        isoValue = value;
      }
      if (el.type === "datetime-local" && !isoValue.includes("T")) {
        isoValue += "T00:00";
      }
      var niv4 = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value");
      el.focus();
      if (niv4) niv4.set.call(el, isoValue);
      else el.value = isoValue;
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      el.blur();
      return el.value ? 1 : 0;
    }
    return null;
  }
  root2.CcFillOneDate = {
    fillDate
  };
})(typeof globalThis !== "undefined" ? globalThis : this);
if (typeof module !== "undefined") module.exports = root.CcFillOneDate;

/* ==== fill-one-radio.ts ==== */
(function(root2) {
  "use strict";
  var NORM = function(s) {
    return String(s || "").toLowerCase().replace(/[^a-z0-9]/g, "").trim();
  };
  function fillRadio(el, selector, value, type, elType, filledBySource) {
    if (type === "radio-click") {
      var target = el.type === "radio" ? el : el.querySelector && el.querySelector('input[type="radio"]') || el;
      target.focus();
      target.checked = true;
      ["click", "change"].forEach(function(ev) {
        target.dispatchEvent(new Event(ev, { bubbles: true, cancelable: true }));
      });
      return 1;
    }
    if (type === "radio-group" && elType === "radio" && el.name) {
      var vR0 = NORM(value);
      var radios = document.querySelectorAll('input[type="radio"][name="' + el.name + '"]');
      var match = Array.from(radios).find(function(r) {
        if (NORM(r.value) === vR0) return true;
        var lbl = r.id ? document.querySelector('label[for="' + r.id + '"]') : null;
        var lblText = lbl ? NORM(lbl.textContent) : "";
        if (lblText && (lblText === vR0 || lblText.startsWith(vR0) || vR0.startsWith(lblText))) return true;
        var wantFemale = /female|महिला|स्त्री/.test(String(value).toLowerCase());
        var wantMale = /male|पुरुष/.test(String(value).toLowerCase()) && !wantFemale;
        if (wantFemale && /female|महिला|स्त्री/.test(lbl && lbl.textContent || r.value)) return true;
        if (wantMale && /male|पुरुष/.test(lbl && lbl.textContent || r.value) && !/female/.test(lbl && lbl.textContent || "")) return true;
        return false;
      });
      if (match) {
        match.focus();
        match.checked = true;
        ["click", "change"].forEach(function(ev) {
          match.dispatchEvent(new Event(ev, { bubbles: true, cancelable: true }));
        });
        return 1;
      }
      return 0;
    }
    if (elType === "radio") {
      var vR = NORM(value);
      var radiosDOM = document.querySelectorAll('input[type="radio"][name="' + el.name + '"]');
      var matchDOM = Array.from(radiosDOM).find(function(r) {
        if (NORM(r.value) === vR) return true;
        var lbl = r.id ? document.querySelector('label[for="' + r.id + '"]') : null;
        var lblText = lbl ? NORM(lbl.textContent) : "";
        return lblText === vR || lblText.startsWith(vR) || vR.startsWith(lblText);
      });
      if (matchDOM) {
        matchDOM.focus();
        matchDOM.checked = true;
        ["click", "change"].forEach(function(ev) {
          matchDOM.dispatchEvent(new Event(ev, { bubbles: true, cancelable: true }));
        });
        matchDOM.dispatchEvent(new Event("blur", { bubbles: true }));
        return 1;
      }
      return null;
    }
    if (elType === "checkbox") {
      var booleanLike = ["yes", "true", "1", "checked", "on", "no", "false", "0", "off", "unchecked"];
      if (!booleanLike.includes(value.toLowerCase())) return 0;
      var truthy = ["yes", "true", "1", "checked", "on"].includes(value.toLowerCase());
      if (truthy !== el.checked) {
        el.checked = truthy;
        el.dispatchEvent(new Event("change", { bubbles: true }));
        return 1;
      }
      return 1;
    }
    if (el.type === "file") {
      if (!value) return 0;
      if (value.startsWith("data:")) {
        try {
          var parts = value.split(",");
          var meta = parts[0];
          var b64 = parts[1];
          var mime = (meta.match(/data:([^;]+)/) || [])[1] || "application/octet-stream";
          var ext = mime.split("/")[1] || "bin";
          var fBys = filledBySource || {};
          var label = fBys[selector] && fBys[selector].label || "file";
          var fileName = label.replace(/[^a-z0-9]/gi, "_") + "." + ext;
          var binary = atob(b64);
          var bytes = new Uint8Array(binary.length);
          for (var i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
          var file = new File([bytes], fileName, { type: mime, lastModified: Date.now() });
          var dt = new DataTransfer();
          dt.items.add(file);
          el.files = dt.files;
          el.dispatchEvent(new Event("change", { bubbles: true }));
          return 1;
        } catch (e) {
          return 0;
        }
      }
      if (value.startsWith("http://") || value.startsWith("https://")) return 0;
      return 0;
    }
    return null;
  }
  root2.CcFillOneRadio = {
    fillRadio
  };
})(typeof globalThis !== "undefined" ? globalThis : this);
if (typeof module !== "undefined") module.exports = root.CcFillOneRadio;

/* ==== fill-one-mat.ts ==== */
(function(root2) {
  "use strict";
  function fillMat(el, value, elType) {
    if (elType !== "mat-select" && elType !== "mat-checkbox" && elType !== "mat-radio") {
      return null;
    }
    if (elType === "mat-select") {
      var trigger = el.querySelector(".mat-select-trigger,.mat-mdc-select-trigger") || el;
      trigger.click();
      setTimeout(function() {
        var v = value.toLowerCase().trim();
        var opts = Array.from(document.querySelectorAll("mat-option,.mat-option,.mat-mdc-option"));
        var opt = opts.find(function(o) {
          return o.textContent.trim().toLowerCase() === v;
        }) || opts.find(function(o) {
          return o.textContent.trim().toLowerCase().startsWith(v);
        }) || opts.find(function(o) {
          return v.startsWith(o.textContent.trim().toLowerCase()) && o.textContent.trim().length > 2;
        }) || opts.find(function(o) {
          return o.textContent.trim().toLowerCase().includes(v);
        });
        if (opt) opt.click();
        else document.body.click();
      }, 400);
      return 1;
    }
    if (elType === "mat-checkbox") {
      var shouldCheck = /yes|true|1|on|checked/i.test(value);
      var input = el.querySelector('input[type="checkbox"]');
      var isChecked = input ? input.checked : el.classList.contains("mat-checkbox-checked");
      if (shouldCheck !== isChecked) {
        (input || el).click();
      }
      return 1;
    }
    if (elType === "mat-radio") {
      var v2 = value.toLowerCase().trim();
      var label = el.textContent.trim().toLowerCase();
      if (label === v2 || label.includes(v2) || v2.includes(label)) {
        var radioInput = el.querySelector('input[type="radio"]') || el;
        radioInput.click();
        return 1;
      }
      return 0;
    }
    return 0;
  }
  root2.CcFillOneMat = {
    fillMat
  };
})(typeof globalThis !== "undefined" ? globalThis : this);
if (typeof module !== "undefined") module.exports = root.CcFillOneMat;

/* ==== fill-one-text.ts ==== */
(function(root2) {
  "use strict";
  function fillText(el, value) {
    var ceAttr = el && el.getAttribute && el.getAttribute("contenteditable");
    var ce = !!(el && (el.isContentEditable === true || ceAttr != null && (String(ceAttr).toLowerCase().trim() === "true" || String(ceAttr).trim() === "")));
    if (ce) {
      try {
        el.focus();
      } catch (e0) {
      }
      var text = String(value == null ? "" : value);
      if (typeof el.innerText === "string") el.innerText = text;
      else el.textContent = text;
      try {
        el.dispatchEvent(new Event("input", { bubbles: true }));
      } catch (e1) {
      }
      try {
        el.dispatchEvent(new Event("change", { bubbles: true }));
      } catch (e2) {
      }
      return 1;
    }
    var t = String(el && el.type || "").toLowerCase();
    if (t === "range") {
      try {
        el.focus();
      } catch (eR) {
      }
      var min = Number(el.min);
      var max = Number(el.max);
      var n = Number(value);
      if (!isFinite(n)) return 0;
      if (isFinite(min) && n < min) n = min;
      if (isFinite(max) && n > max) n = max;
      var asStr = String(n);
      var rangeNiv = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value");
      if (rangeNiv && rangeNiv.set) rangeNiv.set.call(el, asStr);
      else el.value = asStr;
      try {
        el.dispatchEvent(new Event("input", { bubbles: true }));
      } catch (eI) {
      }
      try {
        el.dispatchEvent(new Event("change", { bubbles: true }));
      } catch (eC) {
      }
      return 1;
    }
    var isTextarea = el.tagName === "TEXTAREA";
    var niv = isTextarea ? Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value") : Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value");
    if (typeof window.keystrokeFillSync === "function") {
      var ok = window.keystrokeFillSync(el, value);
      if (el.getAttribute && el.getAttribute("data-type") === "fullName") {
        var allInputs = Array.from(document.querySelectorAll('input[type="text"]'));
        var idx = allInputs.indexOf(el);
        var next = allInputs[idx + 1];
        if (next && next.getAttribute("data-type") === "text") {
          setTimeout(function() {
            if (next.value && next.value.length > 0) return;
            var fillHindi = function(hindiVal) {
              if (typeof window.keystrokeFillSync === "function") window.keystrokeFillSync(next, hindiVal);
            };
            fetch("https://inputtools.google.com/request?text=" + encodeURIComponent(value) + "&itc=hi-t-i0-und&num=1&cp=0&cs=1&ie=utf-8&oe=utf-8").then(function(r) {
              return r.json();
            }).then(function(d) {
              var hindi = d && d[1] && d[1][0] && d[1][0][1] && d[1][0][1][0];
              fillHindi(hindi || value);
            }).catch(function() {
              fillHindi(value);
            });
          }, 500);
        }
      }
      return ok ? 1 : 0;
    }
    el.focus();
    var jqueryInteraction = root2.CcJQueryInteractionAdapter || {};
    if (jqueryInteraction.setValue) {
      var jquerySetResult = jqueryInteraction.setValue(el, value, { events: ["input", "change"] });
      if (!jquerySetResult || !jquerySetResult.verified) return 0;
    } else {
      if (niv) niv.set.call(el, value);
      else el.value = value;
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    }
    el.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, key: "a" }));
    el.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: "a" }));
    el.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: value.slice(-1) }));
    return 1;
  }
  root2.CcFillOneText = {
    fillText
  };
})(typeof globalThis !== "undefined" ? globalThis : this);
if (typeof module !== "undefined") module.exports = root.CcFillOneText;

/* ==== install-kernel-bind.ts ==== */
(function(root) {
  "use strict";
  root.CcExecParts = root.CcExecParts || {};
  root.CcExecParts.bindKernelLocals = function bindKernelLocals(k) {
    return {
      portalAdapters: k.portalAdapters,
      filledBySource: k.filledBySource,
      mapping: k.mapping,
      allFields: k.allFields,
      _replayResults: k.replayResults,
      _ccRecords: k.records,
      RUNTIME_VERSION: k.RUNTIME_VERSION,
      STRATEGY_VERSION: k.STRATEGY_VERSION,
      WAIT_ENGINE_VERSION: k.WAIT_ENGINE_VERSION,
      _CC_USE_PLUGINS: k.CC_USE_PLUGINS,
      _CC_LEGACY_COMPARE: k.CC_LEGACY_COMPARE,
      PRIORITY_KEYS: k.PRIORITY_KEYS,
      entries: k.entries,
      getEl: function() {
        return k.getEl.apply(k, arguments);
      },
      _emitFillDebug: function() {
        return k.emitFillDebug.apply(k, arguments);
      },
      _flushRecords: function() {
        return k.flushRecords();
      },
      _pushSelectRecord: function() {
        return k.pushSelectRecord.apply(k, arguments);
      },
      settleAfterAct: function() {
        if (typeof k.settleAfterAct !== "function") {
          return Promise.resolve({ idle: true, waitedMs: 0, kind: "text" });
        }
        return k.settleAfterAct.apply(k, arguments);
      },
      waitForSelectOptionsSequential: function() {
        if (typeof k.waitForSelectOptionsSequential !== "function") {
          return Promise.resolve(null);
        }
        return k.waitForSelectOptionsSequential.apply(k, arguments);
      },
      waitForOptions: function() {
        if (typeof k.waitForOptions !== "function") return Promise.resolve(null);
        return k.waitForOptions.apply(k, arguments);
      },
      waitForDOMQuiet: function(ms) {
        if (typeof k.waitForDOMQuiet === "function") {
          return k.waitForDOMQuiet.apply(k, arguments);
        }
        return new Promise(function(r) {
          setTimeout(r, ms || 300);
        });
      },
      waitForNetworkIdle: function(q, m) {
        if (typeof k.waitForNetworkIdle === "function") {
          return k.waitForNetworkIdle.apply(k, arguments);
        }
        if (typeof window !== "undefined" && window.ccWaitForNetworkIdle) {
          return window.ccWaitForNetworkIdle(q || 200, m || 8e3);
        }
        return Promise.resolve({ idle: true, waitedMs: 0 });
      },
      detectStrategy: function() {
        if (typeof k.detectStrategy !== "function") return "unknown";
        return k.detectStrategy.apply(k, arguments);
      },
      verifyValue: function() {
        if (typeof k.verifyValue !== "function") {
          return Promise.resolve({ ok: false, actualValue: "", reason: "no-verify" });
        }
        return k.verifyValue.apply(k, arguments);
      },
      _isPlaceholderOption: function() {
        return typeof k.isPlaceholderOption === "function" ? k.isPlaceholderOption.apply(k, arguments) : false;
      },
      _realOptions: function() {
        return typeof k.realOptions === "function" ? k.realOptions.apply(k, arguments) : [];
      },
      _sampleOptions: function() {
        return typeof k.sampleOptions === "function" ? k.sampleOptions.apply(k, arguments) : [];
      },
      _readSelectActual: function() {
        return typeof k.readSelectActual === "function" ? k.readSelectActual.apply(k, arguments) : { actualValue: null, actualOptionValue: null };
      },
      _selectLoadMode: function() {
        return typeof k.selectLoadMode === "function" ? k.selectLoadMode.apply(k, arguments) : "unknown";
      },
      _cascadeSemanticKey: function() {
        return typeof k.cascadeSemanticKey === "function" ? k.cascadeSemanticKey.apply(k, arguments) : "";
      },
      _CASCADE_PARENTS: k.CASCADE_PARENTS,
      _cascadeSettled: k.cascadeSettled,
      _isPlaceholderPlanned: function() {
        return typeof k.isPlaceholderPlanned === "function" ? k.isPlaceholderPlanned.apply(k, arguments) : false;
      },
      _selectIsActive: function() {
        return typeof k.selectIsActive === "function" ? k.selectIsActive.apply(k, arguments) : true;
      },
      fillOne: function() {
        if (typeof k.fillOne !== "function") return 0;
        return k.fillOne.apply(k, arguments);
      },
      k
    };
  };
})(typeof globalThis !== "undefined" ? globalThis : this);

/* ==== install-debug.ts ==== */
(function(root) {
  "use strict";
  root.CcExecParts = root.CcExecParts || {};
  root.CcExecParts.installDebug = function(k) {
    k._debugPort = null;
    k._debugQueue = [];
    k._debugFlushTimer = null;
    var _fde = root.CcFillDebugEmitter || {};
    function ensureDebugPort() {
      if (k._debugPort) return k._debugPort;
      try {
        if (typeof chrome === "undefined" || !chrome.runtime || !chrome.runtime.connect) return null;
        k._debugPort = chrome.runtime.connect({ name: "cc_fill_debug" });
        k._debugPort.onDisconnect.addListener(function() {
          k._debugPort = null;
        });
      } catch (e) {
        k._debugPort = null;
      }
      return k._debugPort;
    }
    function chromeSend(batch) {
      try {
        var port = ensureDebugPort();
        if (port) {
          port.postMessage({ type: "FILL_DEBUG_BATCH", events: batch });
          return;
        }
      } catch (e) {
        k._debugPort = null;
      }
      for (var i = 0; i < batch.length; i++) {
        try {
          chrome.runtime.sendMessage(Object.assign({ type: "FILL_DEBUG" }, batch[i]), function() {
            void chrome.runtime.lastError;
          });
        } catch (e2) {
        }
      }
    }
    var _emitter;
    if (_fde.createEmitter) {
      _emitter = _fde.createEmitter({
        getRunId: function() {
          return k.fillRunId || "";
        },
        getRv: function() {
          return k.RUNTIME_VERSION || "";
        },
        send: chromeSend
      });
    }
    function emitFillDebug(event, payload) {
      if (_emitter) {
        _emitter.emit(event, payload);
        return;
      }
      console.warn("[CC] fill-debug-emitter not loaded, event dropped:", event);
    }
    function flushDebugQueue() {
      if (_emitter) _emitter.flush();
    }
    k.emitFillDebug = emitFillDebug;
    k.flushDebugQueue = flushDebugQueue;
  };
})(typeof globalThis !== "undefined" ? globalThis : this);

/* ==== install-select-helpers.ts ==== */
(function(root) {
  "use strict";
  root.CcExecParts = root.CcExecParts || {};
  root.CcExecParts.installSelectHelpers = function(k) {
    var _sos = root.CcSelectOptionState || {};
    var isPlaceholderOption = _sos.isPlaceholderOption || function() {
      return true;
    };
    var realOptions = _sos.realOptions || function() {
      return [];
    };
    var sampleOptions = _sos.sampleOptions || function() {
      return [];
    };
    var readSelectActual = _sos.readSelectActual || function() {
      return { actualValue: null, actualOptionValue: null };
    };
    var selectLoadMode = _sos.selectLoadMode || function() {
      return "unknown";
    };
    var selectIsActive = _sos.selectIsActive || function() {
      return false;
    };
    var isPlaceholderPlanned = _sos.isPlaceholderPlanned || function() {
      return true;
    };
    var _bfr = root.CcBuildFillRecord || {};
    var _buildFillRecord = _bfr.buildFillRecord || function(base) {
      return Object.assign({ ts: Date.now(), rv: k.RUNTIME_VERSION, fillMode: "sequential" }, base);
    };
    var _cascadeGeo = root.CcCascadeFieldLevel;
    function cascadeSemanticKey(label, profileKey, selector) {
      return _cascadeGeo ? _cascadeGeo.cascadeFieldLevel(label, profileKey, selector) : "";
    }
    k.CASCADE_PARENTS = _cascadeGeo ? _cascadeGeo.CASCADE_PARENTS : {};
    function pushSelectRecord(base) {
      const rec = _buildFillRecord(base, { rv: k.RUNTIME_VERSION });
      k.records.push(rec);
      k.flushRecords();
      const result = String(rec.result || "");
      if (result === "filled" || result === "succeeded") {
        k.emitFillDebug("field.done", {
          selector: rec.selector,
          label: rec.label,
          type: rec.type,
          planned: rec.value,
          actual: rec.actualValue,
          strategy: rec.strategy
        });
      } else if (result === "skipped" || result === "failed" || result === "error" || result === "waiting_human") {
        k.emitFillDebug(result === "waiting_human" ? "field.wait" : "field.fail", {
          selector: rec.selector,
          label: rec.label,
          type: rec.type,
          planned: rec.value,
          actual: rec.actualValue,
          failReason: rec.failReason || rec.error || result,
          strategy: rec.strategy
        });
      }
      return rec;
    }
    k.buildFillRecord = _buildFillRecord;
    k.isPlaceholderOption = isPlaceholderOption;
    k.realOptions = realOptions;
    k.sampleOptions = sampleOptions;
    k.readSelectActual = readSelectActual;
    k.selectLoadMode = selectLoadMode;
    k.cascadeSemanticKey = cascadeSemanticKey;
    k.isPlaceholderPlanned = isPlaceholderPlanned;
    k.selectIsActive = selectIsActive;
    k.pushSelectRecord = pushSelectRecord;
  };
})(typeof globalThis !== "undefined" ? globalThis : this);

/* ==== install-settle.ts ==== */
(function(root) {
  "use strict";
  root.CcExecParts = root.CcExecParts || {};
  root.CcExecParts.installSettle = function(k) {
    var _saa = root.CcSettleAfterAct;
    var _wfo = root.CcWaitForOptions;
    function waitForNetworkIdle(quietMs, maxMs) {
      if (typeof window !== "undefined" && typeof window.ccWaitForNetworkIdle === "function") {
        return window.ccWaitForNetworkIdle(quietMs || 200, maxMs || 8e3);
      }
      return new Promise(function(r) {
        setTimeout(r, quietMs || 200, { idle: true, waitedMs: quietMs || 200 });
      });
    }
    function waitForOptions(selector, minCount, timeout) {
      return _wfo.waitForOptions(
        selector,
        minCount,
        timeout,
        document.querySelector.bind(document),
        document.body
      );
    }
    var _settleEngine = _saa.createSettleEngine({
      waitForNetworkIdle,
      waitForOptions,
      getBudget: function() {
        return k.ajaxWaitBudgetMs;
      },
      setBudget: function(n) {
        k.ajaxWaitBudgetMs = n;
      }
    });
    function waitForDOMQuiet(ms) {
      ms = ms || 300;
      return new Promise(function(resolve) {
        var last = Date.now();
        var mo = new MutationObserver(function() {
          last = Date.now();
        });
        mo.observe(document.body, { childList: true, subtree: true });
        var check = setInterval(function() {
          if (Date.now() - last >= ms) {
            clearInterval(check);
            mo.disconnect();
            resolve();
          }
        }, 50);
        setTimeout(function() {
          clearInterval(check);
          mo.disconnect();
          resolve();
        }, 5e3);
      });
    }
    k.settleAfterAct = function(kind, opts) {
      return _settleEngine.settleAfterAct(kind, opts);
    };
    k.waitForSelectOptionsSequential = function(sel, maxMs) {
      return _settleEngine.waitForSelectOptionsSequential(sel, maxMs);
    };
    k.waitForOptions = waitForOptions;
    k.waitForDOMQuiet = waitForDOMQuiet;
    k.waitForNetworkIdle = waitForNetworkIdle;
  };
})(typeof globalThis !== "undefined" ? globalThis : this);

/* ==== install-dom-order.ts ==== */
(function(root) {
  "use strict";
  root.CcExecParts = root.CcExecParts || {};
  root.CcExecParts.installDomOrder = function(k) {
    var _resolve = root.CcResolveCcSelector ? root.CcResolveCcSelector.resolveCcSelector : function(sel) {
      return document.querySelector(sel);
    };
    function getEl(sel) {
      return _resolve(sel);
    }
    k.getEl = getEl;
    k.PRIORITY_KEYS = [
      "state",
      "rajya",
      "\u0930\u093E\u091C\u094D\u092F",
      "district",
      "jila",
      "\u091C\u093F\u0932\u093E",
      "sub_division",
      "subdivision",
      "sub-division",
      "\u0905\u0928\u0941\u092E\u0902\u0921\u0932",
      "block",
      "prakhand",
      "\u092A\u094D\u0930\u0916\u0902\u0921",
      "panchayat",
      "village_panchayat",
      "\u092A\u0902\u091A\u093E\u092F\u0924",
      "village",
      "gram",
      "\u0917\u094D\u0930\u093E\u092E",
      "mohalla",
      "\u092E\u094B\u0939\u0932\u094D\u0932\u093E",
      "tehsil",
      "taluka",
      "\u0924\u0939\u0938\u0940\u0932",
      "police_station",
      "police-station",
      "thana",
      "\u0925\u093E\u0928\u093E",
      "post_office",
      "post-office",
      "\u0921\u093E\u0915 \u0918\u0930",
      "pin_code",
      "pincode",
      "\u092A\u093F\u0928",
      "municipal",
      "\u0928\u0917\u0930"
    ];
    k.entries = Object.entries(k.mapping || {});
    var _sort = root.CcSortFieldsByDomOrder;
    if (_sort) {
      _sort.sortFieldsByDomOrder(k.entries, _resolve);
    } else {
      console.warn("[CC] CcSortFieldsByDomOrder not loaded \u2014 skipping DOM order sort");
    }
  };
})(typeof globalThis !== "undefined" ? globalThis : this);

/* ==== install-strategy.ts ==== */
(function(root) {
  "use strict";
  root.CcExecParts = root.CcExecParts || {};
  root.CcExecParts.installStrategy = function(k) {
    const getEl = function() {
      return k.getEl.apply(k, arguments);
    };
    var _dfs = root.CcDetectFillStrategy || {};
    var STRATEGY_REGISTRY = _dfs.STRATEGY_REGISTRY || {};
    function detectStrategy(el, type) {
      if (_dfs.detectFillStrategy) return _dfs.detectFillStrategy(el, type);
      return type || "unknown";
    }
    var _vfv = root.CcVerifyFillValue || {};
    var _resolveEl = root.CcResolveCcSelector ? root.CcResolveCcSelector.resolveCcSelector : function(sel) {
      return document.querySelector(sel);
    };
    async function verifyValue(selector, expected, settleMs) {
      if (_vfv.verifyFillValue) return _vfv.verifyFillValue(selector, expected, _resolveEl, settleMs);
      return { ok: false, actualValue: "", normExpected: "", normActual: "", reason: "verifier-not-loaded" };
    }
    k.STRATEGY_REGISTRY = STRATEGY_REGISTRY;
    k.detectStrategy = detectStrategy;
    k.verifyValue = verifyValue;
  };
})(typeof globalThis !== "undefined" ? globalThis : this);

/* ==== install-fill-one-ng-helpers.ts ==== */
(function(root) {
  "use strict";
  root.CcExecParts = root.CcExecParts || {};
  root.CcExecParts.installFillOneNgHelpers = function(k) {
    const b = root.CcExecParts.bindKernelLocals(k);
    const {
      portalAdapters,
      filledBySource,
      mapping,
      _replayResults,
      _ccRecords,
      RUNTIME_VERSION,
      _CC_USE_PLUGINS,
      PRIORITY_KEYS,
      entries,
      getEl,
      _emitFillDebug,
      _flushRecords,
      _pushSelectRecord,
      settleAfterAct,
      waitForSelectOptionsSequential,
      waitForOptions,
      detectStrategy,
      verifyValue,
      _isPlaceholderOption,
      _realOptions,
      _sampleOptions,
      _readSelectActual,
      _selectLoadMode,
      _cascadeSemanticKey,
      _CASCADE_PARENTS,
      _cascadeSettled,
      _isPlaceholderPlanned,
      _selectIsActive,
      fillOne
    } = b;
    var _nos = root.CcNgOptionScorer;
    var _nsm = root.CcNgSessionManager;
    k._ngIsVisible = function(node) {
      return window.ccDomUtils && window.ccDomUtils.isVisible ? window.ccDomUtils.isVisible(node) : !!(node && node.offsetParent !== null);
    };
    k._ngScoreOption = function(optText, planned) {
      return _nos.scoreOption(optText, planned);
    };
    k._ngCancelSession = function(_label) {
      _nsm.cancelSession(_label, window._ccReplaySessions || null);
    };
    k._ngPickOption = function(opts, planned) {
      var wrapped = Array.from(opts).map(function(n) {
        return { text: (n.textContent || n.innerText || "").trim(), node: n };
      });
      var result = _nos.scoreAndPick(wrapped, planned, 30);
      return result ? result.node : null;
    };
  };
})(typeof globalThis !== "undefined" ? globalThis : this);

/* ==== install-fill-one-ng.ts ==== */
(function(root) {
  "use strict";
  root.CcExecParts = root.CcExecParts || {};
  root.CcExecParts.installFillOneNg = function(k) {
    root.CcExecParts.installFillOneNgHelpers(k);
    const b = root.CcExecParts.bindKernelLocals(k);
    const portalAdapters = b.portalAdapters, filledBySource = b.filledBySource;
    const _replayResults = b._replayResults, _ccRecords = b._ccRecords;
    const RUNTIME_VERSION = b.RUNTIME_VERSION, _flushRecords = b._flushRecords;
    k.fillOneHandlers = k.fillOneHandlers || [];
    var _fong = root.CcFillOneNg || {};
    k.fillOneHandlers.push({
      id: "ng-dropdown",
      try(el, selector, value, type, elType) {
        var _a, _b;
        if (_fong.fillNg) return _fong.fillNg(el, selector, value, type, elType, {
          portalAdapters,
          filledBySource,
          _replayResults,
          _ccRecords,
          RUNTIME_VERSION,
          _flushRecords
        });
        if (!(elType === "ng-dropdown" || type === "ng-dropdown")) return null;
        const rootClass = el.className ? el.className.trim().split(/\s+/)[0] : "ng-dropdown";
        const adapter = portalAdapters[rootClass] || portalAdapters["ng-dropdown"];
        if (adapter) {
          let isVisible = function(node) {
            return window.ccDomUtils.isVisible(node);
          }, cleanupSession = function(result) {
            if (session.resolved && result !== session._result) return;
            session.resolved = true;
            session._result = result;
            clearInterval(session.pollTimer);
            session.timeoutIds.forEach((id) => clearTimeout(id));
            if (session.observer) {
              session.observer.disconnect();
              session.observer = null;
            }
            window._ccReplaySessions.delete(_label);
            _replayResults[_label] = result;
            sessionStorage.setItem("_cc_replay_results", JSON.stringify(_replayResults));
            const _isOk = result === "ok";
            _ccRecords.push((root.CcBuildFillRecord ? root.CcBuildFillRecord.buildFillRecord : function(b2) {
              return Object.assign({ ts: Date.now(), rv: RUNTIME_VERSION, fillMode: "sequential" }, b2);
            })({ selector, value, type: "ng-dropdown", result: _isOk ? "filled" : "skipped", failReason: _isOk ? null : result, strategy: "ng-dropdown-click", durationMs: Date.now() - session.startedAt }, { rv: RUNTIME_VERSION }));
            _flushRecords();
          }, waitStable = function(cb) {
            const check = setInterval(() => {
              if (session.cancelled) {
                clearInterval(check);
                _stabilizeMo.disconnect();
                return;
              }
              if (Date.now() - _lastMutation >= 150) {
                clearInterval(check);
                _stabilizeMo.disconnect();
                cb();
              }
            }, 50);
            const capId = setTimeout(() => {
              clearInterval(check);
              _stabilizeMo.disconnect();
              if (!session.cancelled) cb();
            }, 1200);
            session.timeoutIds.push(capId);
          };
          const _label = ((_a = filledBySource[selector]) == null ? void 0 : _a.label) || selector;
          const trigger = el.querySelector(adapter.triggerSelector) || el;
          if (!window._ccReplaySessions) window._ccReplaySessions = /* @__PURE__ */ new Map();
          k._ngCancelSession && k._ngCancelSession(_label);
          const session = { id: Math.random().toString(36).slice(2, 8), fieldKey: _label, resolved: false, cancelled: false, pollTimer: null, timeoutIds: [], observer: null, startedAt: Date.now() };
          window._ccReplaySessions.set(_label, session);
          const OVERLAY_TAGS = [
            "app-dropdown",
            "ul",
            "ng-dropdown-panel",
            "cdk-overlay-container",
            ".dropdown-options",
            ".options-list",
            ".dropdown-menu",
            ".ng-dropdown-panel"
          ];
          const addedNodes = [];
          const _trace = { triggerLabel: _label, overlayFound: false, overlayTag: "", mutationCount: 0, optionCount: 0, matchedOption: "", clicked: false, verifyStatus: "", durationMs: 0 };
          trigger.click();
          const mo = new MutationObserver((mutations) => {
            if (session.cancelled || session.resolved) return;
            for (const m of mutations) {
              m.addedNodes.forEach((n) => {
                if (n.nodeType === 1) addedNodes.push(n);
              });
            }
          });
          session.observer = mo;
          mo.observe(document.body, { childList: true, subtree: true });
          let _lastMutation = Date.now();
          const _stabilizeMo = new MutationObserver(() => {
            _lastMutation = Date.now();
          });
          _stabilizeMo.observe(document.body, { childList: true, subtree: true, attributes: true });
          waitStable(() => {
            if (session.cancelled || session.resolved) return;
            mo.disconnect();
            session.observer = null;
            _trace.mutationCount = addedNodes.length;
            let activeOverlayRoot = null;
            const trigRect = trigger.getBoundingClientRect();
            for (const node of addedNodes) {
              if (!isVisible(node)) continue;
              const _optQ2 = adapter.optionSelector || "li,.ng-option,mat-option,.dropdown-item";
              const lis = Array.from(node.querySelectorAll(_optQ2)).filter((o) => isVisible(o));
              if (lis.length > 0) {
                activeOverlayRoot = node;
                break;
              }
            }
            if (!activeOverlayRoot) {
              let bestDist = Infinity;
              OVERLAY_TAGS.forEach((sel) => {
                try {
                  document.querySelectorAll(sel).forEach((node) => {
                    const lis = Array.from(node.querySelectorAll(_optQ)).filter((o) => isVisible(o));
                    if (lis.length === 0) return;
                    const r = node.getBoundingClientRect();
                    const dist = Math.abs(r.left - trigRect.left) + Math.abs(r.top - trigRect.bottom);
                    if (dist < bestDist) {
                      bestDist = dist;
                      activeOverlayRoot = node;
                    }
                  });
                } catch (e) {
                }
              });
            }
            if (!activeOverlayRoot && adapter.optionsContainer) {
              activeOverlayRoot = document.querySelector(adapter.optionsContainer) || null;
            }
            if (!activeOverlayRoot) {
              const rootLis = Array.from(root.querySelectorAll(_optQ)).filter((o) => isVisible(o));
              if (rootLis.length > 0) activeOverlayRoot = root;
            }
            _trace.overlayFound = !!activeOverlayRoot;
            _trace.overlayTag = activeOverlayRoot ? activeOverlayRoot.tagName + "." + activeOverlayRoot.className.slice(0, 40) : "NONE";
            let attempts = 0;
            session.pollTimer = setInterval(() => {
              if (session.cancelled || session.resolved) {
                clearInterval(session.pollTimer);
                return;
              }
              attempts++;
              const searchRoot = activeOverlayRoot || root;
              let opts = Array.from(searchRoot.querySelectorAll(_optQ)).filter((o) => isVisible(o));
              if (opts.length === 0 && searchRoot !== document) {
                opts = Array.from(document.querySelectorAll(_optQ)).filter((o) => isVisible(o) && root.contains(o) === false && o.closest('[class*="dropdown"],[class*="options"],[class*="list"]'));
              }
              const v = value.toLowerCase().trim();
              _trace.optionCount = opts.length;
              var _nos = root.CcNgOptionScorer;
              let bestOpt = null, bestScore = 0;
              for (const o of opts) {
                const score = _nos.scoreOption(o.textContent.trim(), v);
                if (score > bestScore) {
                  bestScore = score;
                  bestOpt = o;
                }
              }
              const opt = bestScore >= 50 ? bestOpt : null;
              if (opt) {
                clearInterval(session.pollTimer);
                if (session.cancelled || session.resolved) return;
                _trace.matchedOption = opt.textContent.trim();
                _trace.clicked = true;
                ["pointerdown", "mousedown", "mouseup", "click"].forEach(
                  (ev) => opt.dispatchEvent(new MouseEvent(ev, { bubbles: true, cancelable: true }))
                );
                const verifyStart = Date.now();
                const triggerInitialText = trigger.textContent.trim();
                const verifyPoll = setInterval(() => {
                  if (session.cancelled || session.resolved) {
                    clearInterval(verifyPoll);
                    return;
                  }
                  const verifyEl = adapter.verifySelector ? el.querySelector(adapter.verifySelector) : null;
                  const displayed = verifyEl ? verifyEl.textContent.trim() : "";
                  const overlayGone = activeOverlayRoot ? !isVisible(activeOverlayRoot) : false;
                  const triggerChanged = trigger.textContent.trim() !== triggerInitialText;
                  const ariaSelected = opt.getAttribute("aria-selected") === "true";
                  const ok = displayed && !/^(select|choose|--)$/i.test(displayed) || overlayGone || triggerChanged || ariaSelected;
                  if (ok || Date.now() - verifyStart >= 3e3) {
                    clearInterval(verifyPoll);
                    if (session.resolved) return;
                    _trace.verifyStatus = ok ? "ok" : "verify-fail";
                    _trace.durationMs = Date.now() - session.startedAt;
                    cleanupSession(_trace.verifyStatus);
                  }
                }, 200);
              } else if (attempts >= 10) {
                clearInterval(session.pollTimer);
                if (session.resolved) return;
                document.body.click();
                _trace.durationMs = Date.now() - session.startedAt;
                cleanupSession("no-option");
              }
            }, 300);
          });
          return 1;
        }
        const _noAdapterLabel = ((_b = filledBySource[selector]) == null ? void 0 : _b.label) || selector;
        _replayResults[_noAdapterLabel] = "no-adapter";
        sessionStorage.setItem("_cc_replay_results", JSON.stringify(_replayResults));
        return 0;
      }
    });
  };
})(typeof globalThis !== "undefined" ? globalThis : this);

/* ==== install-fill-one-mat.ts ==== */
(function(root) {
  "use strict";
  root.CcExecParts = root.CcExecParts || {};
  root.CcExecParts.installFillOneMat = function(k) {
    const b = root.CcExecParts.bindKernelLocals(k);
    const {
      portalAdapters,
      filledBySource,
      mapping,
      _replayResults,
      _ccRecords,
      RUNTIME_VERSION,
      _CC_USE_PLUGINS,
      PRIORITY_KEYS,
      entries,
      getEl,
      _emitFillDebug,
      _flushRecords,
      _pushSelectRecord,
      settleAfterAct,
      waitForSelectOptionsSequential,
      waitForOptions,
      detectStrategy,
      verifyValue,
      _isPlaceholderOption,
      _realOptions,
      _sampleOptions,
      _readSelectActual,
      _selectLoadMode,
      _cascadeSemanticKey,
      _CASCADE_PARENTS,
      _cascadeSettled,
      _isPlaceholderPlanned,
      _selectIsActive,
      fillOne
    } = b;
    k.fillOneHandlers = k.fillOneHandlers || [];
    var _fom = root.CcFillOneMat || {};
    k.fillOneHandlers.push({
      id: "mat",
      try(el, selector, value, type, elType) {
        if (_fom.fillMat) return _fom.fillMat(el, value, elType);
        if (elType !== "mat-select" && elType !== "mat-checkbox" && elType !== "mat-radio") return null;
        if (elType === "mat-select") {
          const trigger = el.querySelector(".mat-select-trigger,.mat-mdc-select-trigger") || el;
          trigger.click();
          setTimeout(() => {
            const v = value.toLowerCase().trim();
            const opts = Array.from(document.querySelectorAll("mat-option,.mat-option,.mat-mdc-option"));
            const opt = opts.find((o) => o.textContent.trim().toLowerCase() === v) || opts.find((o) => o.textContent.trim().toLowerCase().startsWith(v)) || opts.find((o) => v.startsWith(o.textContent.trim().toLowerCase()) && o.textContent.trim().length > 2) || opts.find((o) => o.textContent.trim().toLowerCase().includes(v));
            if (opt) opt.click();
            else document.body.click();
          }, 400);
          return 1;
        }
        if (elType === "mat-checkbox") {
          const shouldCheck = /yes|true|1|on|checked/i.test(value);
          const input = el.querySelector('input[type="checkbox"]');
          const isChecked = input ? input.checked : el.classList.contains("mat-checkbox-checked");
          if (shouldCheck !== isChecked) {
            (input || el).click();
          }
          return 1;
        }
        if (elType === "mat-radio") {
          const v = value.toLowerCase().trim();
          const label = el.textContent.trim().toLowerCase();
          if (label === v || label.includes(v) || v.includes(label)) {
            const input = el.querySelector('input[type="radio"]') || el;
            input.click();
            return 1;
          }
          return 0;
        }
        return 0;
      }
    });
  };
})(typeof globalThis !== "undefined" ? globalThis : this);

/* ==== install-fill-one-radio-planned.ts ==== */
(function(root) {
  "use strict";
  root.CcExecParts = root.CcExecParts || {};
  root.CcExecParts.installFillOneRadioPlanned = function(k) {
    const b = root.CcExecParts.bindKernelLocals(k);
    const {
      portalAdapters,
      filledBySource,
      mapping,
      _replayResults,
      _ccRecords,
      RUNTIME_VERSION,
      _CC_USE_PLUGINS,
      PRIORITY_KEYS,
      entries,
      getEl,
      _emitFillDebug,
      _flushRecords,
      _pushSelectRecord,
      settleAfterAct,
      waitForSelectOptionsSequential,
      waitForOptions,
      detectStrategy,
      verifyValue,
      _isPlaceholderOption,
      _realOptions,
      _sampleOptions,
      _readSelectActual,
      _selectLoadMode,
      _cascadeSemanticKey,
      _CASCADE_PARENTS,
      _cascadeSettled,
      _isPlaceholderPlanned,
      _selectIsActive,
      fillOne
    } = b;
    k.fillOneHandlers = k.fillOneHandlers || [];
    var _for2 = root.CcFillOneRadio || {};
    k.fillOneHandlers.push({
      id: "radio-planned",
      try(el, selector, value, type, elType) {
        if (_for2.fillRadio) return _for2.fillRadio(el, selector, value, type, elType, filledBySource);
        if (type === "radio-click") {
          const target = el.type === "radio" ? el : el.querySelector && el.querySelector('input[type="radio"]') || el;
          target.focus();
          target.checked = true;
          ["click", "change"].forEach((ev) => target.dispatchEvent(new Event(ev, { bubbles: true, cancelable: true })));
          return 1;
        }
        if (type === "radio-group" && elType === "radio" && el.name) {
          const normR0 = (s) => String(s || "").toLowerCase().replace(/[^a-z0-9]/g, "").trim();
          const vR0 = normR0(value);
          const radios0 = document.querySelectorAll('input[type="radio"][name="' + el.name + '"]');
          const match0 = Array.from(radios0).find((r) => {
            if (normR0(r.value) === vR0) return true;
            const lbl = r.id ? document.querySelector('label[for="' + r.id + '"]') : null;
            const lblText = lbl ? normR0(lbl.textContent) : "";
            if (lblText && (lblText === vR0 || lblText.startsWith(vR0) || vR0.startsWith(lblText))) return true;
            const wantFemale = /female|महिला|स्त्री/.test(String(value).toLowerCase());
            const wantMale = /male|पुरुष/.test(String(value).toLowerCase()) && !wantFemale;
            if (wantFemale && /female|महिला|स्त्री/.test(lbl && lbl.textContent || r.value)) return true;
            if (wantMale && /male|पुरुष/.test(lbl && lbl.textContent || r.value) && !/female/.test(lbl && lbl.textContent || "")) return true;
            return false;
          });
          if (match0) {
            match0.focus();
            match0.checked = true;
            ["click", "change"].forEach((ev) => match0.dispatchEvent(new Event(ev, { bubbles: true, cancelable: true })));
            return 1;
          }
          console.debug("[CC] radio-group no option match:", selector, value);
          return 0;
        }
        return null;
      }
    });
  };
})(typeof globalThis !== "undefined" ? globalThis : this);

/* ==== install-fill-one-select.ts ==== */
(function(root) {
  "use strict";
  root.CcExecParts = root.CcExecParts || {};
  root.CcExecParts.installFillOneSelect = function(k) {
    const b = root.CcExecParts.bindKernelLocals(k);
    const {
      portalAdapters,
      filledBySource,
      mapping,
      _replayResults,
      _ccRecords,
      RUNTIME_VERSION,
      _CC_USE_PLUGINS,
      PRIORITY_KEYS,
      entries,
      getEl,
      _emitFillDebug,
      _flushRecords,
      _pushSelectRecord,
      settleAfterAct,
      waitForSelectOptionsSequential,
      waitForOptions,
      detectStrategy,
      verifyValue,
      _isPlaceholderOption,
      _realOptions,
      _sampleOptions,
      _readSelectActual,
      _selectLoadMode,
      _cascadeSemanticKey,
      _CASCADE_PARENTS,
      _cascadeSettled,
      _isPlaceholderPlanned,
      _selectIsActive,
      fillOne
    } = b;
    k.fillOneHandlers = k.fillOneHandlers || [];
    var _fos = root.CcFillOneSelect || {};
    k.fillOneHandlers.push({
      id: "select",
      try(el, selector, value, type, elType) {
        var _a;
        if (elType !== "select") return null;
        if (_fos.fillSelect) return _fos.fillSelect(el, selector, value, mapping);
        if (elType === "select") {
          let findOpt = function(options) {
            return window.ccMatchOption(value, options, { extraValues });
          }, applySelect = function(el2, opt2) {
            el2.focus();
            el2.dispatchEvent(new Event("focus", { bubbles: true }));
            Array.from(el2.options).forEach((o) => {
              o.selected = false;
            });
            opt2.selected = true;
            el2.selectedIndex = opt2.index;
            const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, "value");
            if (nativeSetter) nativeSetter.set.call(el2, opt2.value);
            else el2.value = opt2.value;
            ["mousedown", "mouseup", "click", "input", "change"].forEach(
              (ev) => el2.dispatchEvent(new Event(ev, { bubbles: true, cancelable: true }))
            );
            if (typeof el2.onchange === "function") {
              try {
                el2.onchange.call(el2, new Event("change"));
              } catch (e) {
                console.debug("[CC] onchange handler error:", e.message);
              }
            }
            if (typeof $ !== "undefined") {
              try {
                $(el2).trigger("change");
              } catch (e) {
              }
            }
            try {
              el2.dispatchEvent(new Event("propertychange", { bubbles: true }));
            } catch (e) {
            }
            el2.dispatchEvent(new Event("blur", { bubbles: true }));
            setTimeout(() => {
              if (el2.value !== opt2.value || el2.selectedIndex !== opt2.index) {
                console.debug("[CC] select reset by framework, re-applying:", selector, opt2.value);
                opt2.selected = true;
                el2.selectedIndex = opt2.index;
                if (nativeSetter) nativeSetter.set.call(el2, opt2.value);
                else el2.value = opt2.value;
                el2.dispatchEvent(new Event("change", { bubbles: true }));
              }
              console.debug("[CC] select verify:", selector, "value:", el2.value, "selectedIndex:", el2.selectedIndex, "expected:", opt2.value, opt2.index);
            }, 300);
            setTimeout(() => el2.dispatchEvent(new Event("change", { bubbles: true })), 700);
            const _reapplyVal = opt2.value;
            const _reapplyIdx = opt2.index;
            setTimeout(() => {
              if (el2.value !== _reapplyVal) {
                el2.selectedIndex = _reapplyIdx;
                el2.value = _reapplyVal;
                el2.dispatchEvent(new Event("change", { bubbles: true }));
                console.debug("[CC] re-applied after DWR reset:", selector, _reapplyVal);
              }
            }, 3500);
            console.debug("[CC] select applied:", selector, "->", opt2.text.trim(), "(value:", opt2.value, "index:", opt2.index, ")");
            return 1;
          };
          const norm = (s) => s.toLowerCase().replace(/[^a-z0-9\s]/g, " ").replace(/\s+/g, " ").trim();
          const v = norm(value);
          const vWords = v.split(" ").filter((w) => w.length > 1);
          const extraValues = [];
          if ((_a = mapping[selector]) == null ? void 0 : _a.monthNum) {
            extraValues.push(mapping[selector].monthNum.toString());
            if (mapping[selector].monthShort) extraValues.push(mapping[selector].monthShort.toLowerCase());
          }
          const allOptions = Array.from(el.options);
          const opt = findOpt(allOptions);
          console.debug("[CC] select attempt:", selector, "value:", value, "total opts:", allOptions.length, "matched:", opt ? opt.text.trim() : "NONE", "sample:", allOptions.slice(0, 3).map((o) => o.value + "=" + o.text.trim()));
          if (opt) return applySelect(el, opt);
          let attempts = 0;
          const interval = setInterval(() => {
            const allOpts = Array.from(el.options);
            const realOpts = allOpts.filter((o) => {
              if (!o.value || o.value === "0" || o.value === "-1" || o.value === "") return false;
              const txt = o.text.toLowerCase();
              return !txt.includes("select") && !txt.includes("choose") && !txt.includes("loading") && txt !== "--";
            });
            if (realOpts.length === 0 && attempts < 10) {
              attempts++;
              return;
            }
            const opt2 = findOpt(allOpts);
            if (opt2) {
              clearInterval(interval);
              applySelect(el, opt2);
              return;
            }
            if (++attempts >= 15) {
              clearInterval(interval);
              const llmKey = window._cc_llm_key || (document.body.getAttribute("data-cc-llm-key") || "");
              if (llmKey && realOpts.length > 0) {
                const optTexts = realOpts.map((o) => o.text.trim()).join("\n");
                window.ccLLM.call({
                  apiKey: llmKey,
                  baseUrl: document.body.getAttribute("data-cc-llm-url") || void 0,
                  model: document.body.getAttribute("data-cc-llm-model") || void 0,
                  userPrompt: 'From these dropdown options, which best matches "' + value + '"? Reply with ONLY the exact option text, nothing else.\n\nOptions:\n' + optTexts,
                  maxTokens: 50
                }).then((result) => {
                  const aiText = (result.text || "").trim();
                  if (aiText) {
                    const aiOpt = realOpts.find((o) => o.text.trim() === aiText) || realOpts.find((o) => o.text.trim().toLowerCase().includes(aiText.toLowerCase()));
                    if (aiOpt) {
                      console.debug("[CC] AI matched:", aiText, "->", aiOpt.text);
                      applySelect(el, aiOpt);
                    }
                  }
                }).catch(() => {
                });
              }
              console.debug("[CC] select no match after wait:", selector, "value:", value, "opts:", realOpts.slice(0, 5).map((o) => o.text.trim()));
            }
          }, 200);
          return 1;
        }
        return null;
      }
    });
  };
})(typeof globalThis !== "undefined" ? globalThis : this);

/* ==== install-fill-one-choice-dom.ts ==== */
(function(root) {
  "use strict";
  root.CcExecParts = root.CcExecParts || {};
  root.CcExecParts.installFillOneChoiceDom = function(k) {
    const b = root.CcExecParts.bindKernelLocals(k);
    const {
      portalAdapters,
      filledBySource,
      mapping,
      _replayResults,
      _ccRecords,
      RUNTIME_VERSION,
      _CC_USE_PLUGINS,
      PRIORITY_KEYS,
      entries,
      getEl,
      _emitFillDebug,
      _flushRecords,
      _pushSelectRecord,
      settleAfterAct,
      waitForSelectOptionsSequential,
      waitForOptions,
      detectStrategy,
      verifyValue,
      _isPlaceholderOption,
      _realOptions,
      _sampleOptions,
      _readSelectActual,
      _selectLoadMode,
      _cascadeSemanticKey,
      _CASCADE_PARENTS,
      _cascadeSettled,
      _isPlaceholderPlanned,
      _selectIsActive,
      fillOne
    } = b;
    k.fillOneHandlers = k.fillOneHandlers || [];
    var _for = root.CcFillOneRadio || {};
    k.fillOneHandlers.push({
      id: "choice-dom",
      try(el, selector, value, type, elType) {
        var _a, _b;
        if (_for.fillRadio) return _for.fillRadio(el, selector, value, type, elType, filledBySource);
        if (elType === "radio") {
          const normR = (s) => s.toLowerCase().replace(/[^a-z0-9]/g, "").trim();
          const vR = normR(value);
          const radios = document.querySelectorAll('input[type="radio"][name="' + el.name + '"]');
          const match = Array.from(radios).find((r) => {
            if (normR(r.value) === vR) return true;
            const lbl = r.id ? document.querySelector('label[for="' + r.id + '"]') : null;
            const lblText = lbl ? normR(lbl.textContent) : "";
            return lblText === vR || lblText.startsWith(vR) || vR.startsWith(lblText);
          });
          if (match) {
            match.focus();
            match.checked = true;
            ["click", "change"].forEach((ev) => match.dispatchEvent(new Event(ev, { bubbles: true, cancelable: true })));
            match.dispatchEvent(new Event("blur", { bubbles: true }));
            return 1;
          }
        } else if (elType === "checkbox") {
          const booleanLike = ["yes", "true", "1", "checked", "on", "no", "false", "0", "off", "unchecked"];
          if (!booleanLike.includes(value.toLowerCase())) {
            console.debug("[CC] skipped checkbox with non-boolean value:", value);
            return 0;
          }
          const truthy = ["yes", "true", "1", "checked", "on"].includes(value.toLowerCase());
          if (truthy !== el.checked) {
            el.checked = truthy;
            el.dispatchEvent(new Event("change", { bubbles: true }));
            return 1;
          }
        } else if (el.type === "file") {
          if (!value) {
            console.debug("[CC] file: no value \u2014 waiting_human (no dialog):", selector);
            return 0;
          }
          if (value.startsWith("data:")) {
            try {
              const [meta, b64] = value.split(",");
              const mime = ((_a = meta.match(/data:([^;]+)/)) == null ? void 0 : _a[1]) || "application/octet-stream";
              const ext = mime.split("/")[1] || "bin";
              const fileName = (((_b = filledBySource[selector]) == null ? void 0 : _b.label) || "file").replace(/[^a-z0-9]/gi, "_") + "." + ext;
              const binary = atob(b64);
              const bytes = new Uint8Array(binary.length);
              for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
              const file = new File([bytes], fileName, { type: mime, lastModified: Date.now() });
              const dt = new DataTransfer();
              dt.items.add(file);
              el.files = dt.files;
              el.dispatchEvent(new Event("change", { bubbles: true }));
              console.debug("[CC] file assigned (base64):", selector, fileName, file.size, "bytes");
              return 1;
            } catch (e) {
              console.debug("[CC] file base64 error:", e.message, "\u2014 waiting_human (no dialog)");
              return 0;
            }
          }
          if (value.startsWith("http://") || value.startsWith("https://")) {
            console.debug("[CC] file URL deferred to sequential loop:", selector);
            return 0;
          }
          console.debug("[CC] file: filename hint only \u2014 waiting_human (no dialog):", selector, value);
          return 0;
        }
        return null;
      }
    });
  };
})(typeof globalThis !== "undefined" ? globalThis : this);

/* ==== install-fill-one-date.ts ==== */
(function(root) {
  "use strict";
  root.CcExecParts = root.CcExecParts || {};
  root.CcExecParts.installFillOneDate = function(k) {
    const b = root.CcExecParts.bindKernelLocals(k);
    const {
      portalAdapters,
      filledBySource,
      mapping,
      _replayResults,
      _ccRecords,
      RUNTIME_VERSION,
      _CC_USE_PLUGINS,
      PRIORITY_KEYS,
      entries,
      getEl,
      _emitFillDebug,
      _flushRecords,
      _pushSelectRecord,
      settleAfterAct,
      waitForSelectOptionsSequential,
      waitForOptions,
      detectStrategy,
      verifyValue,
      _isPlaceholderOption,
      _realOptions,
      _sampleOptions,
      _readSelectActual,
      _selectLoadMode,
      _cascadeSemanticKey,
      _CASCADE_PARENTS,
      _cascadeSettled,
      _isPlaceholderPlanned,
      _selectIsActive,
      fillOne
    } = b;
    k.fillOneHandlers = k.fillOneHandlers || [];
    var _fod = root.CcFillOneDate || {};
    k.fillOneHandlers.push({
      id: "date",
      try(el, selector, value, type, elType) {
        if (_fod.fillDate) return _fod.fillDate(el, selector, value);
        if (el._flatpickr || el.classList.contains("flatpickr-input")) {
          const fp = el._flatpickr;
          var _parsed = (root.CcParseDateValue || {}).parseDateValue ? root.CcParseDateValue.parseDateValue(value) : { dateObj: new Date(value) };
          var dateObj = _parsed.dateObj;
          if (fp && !isNaN(dateObj)) {
            fp.setDate(dateObj, true);
          } else {
            const niv = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value");
            el.focus();
            if (niv) niv.set.call(el, value);
            else el.value = value;
            el.dispatchEvent(new Event("input", { bubbles: true }));
            el.dispatchEvent(new Event("change", { bubbles: true }));
            el.blur();
          }
          console.debug("[CC] flatpickr fill:", selector, "value:", value, "result:", el.value);
          return el.value ? 1 : 0;
        } else if (el.classList.contains("hasDatepicker") || typeof $ !== "undefined" && typeof $.fn !== "undefined" && typeof $.fn.datepicker !== "undefined" && $(el).data("datepicker")) {
          var _parsed = (root.CcParseDateValue || {}).parseDateValue ? root.CcParseDateValue.parseDateValue(value) : { dateObj: new Date(value) };
          var dateObj = _parsed.dateObj;
          if (!isNaN(dateObj)) {
            $(el).datepicker("setDate", dateObj);
          } else {
            const niv = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value");
            el.focus();
            if (niv) niv.set.call(el, value);
            else el.value = value;
            el.dispatchEvent(new Event("change", { bubbles: true }));
          }
          console.debug("[CC] jQuery datepicker fill:", selector, "value:", value, "result:", el.value);
          return el.value ? 1 : 0;
        } else if (el.getAttribute("matdatepicker") !== null || el.getAttribute("matInput") !== null && el.closest("mat-datepicker-toggle,mat-form-field") && (el.type === "text" || el.type === "date")) {
          const niv = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value");
          el.focus();
          if (niv) niv.set.call(el, value);
          else el.value = value;
          el.dispatchEvent(new Event("input", { bubbles: true }));
          el.dispatchEvent(new Event("change", { bubbles: true }));
          el.dispatchEvent(new CustomEvent("dateChange", { bubbles: true, detail: { value } }));
          el.dispatchEvent(new CustomEvent("dateInput", { bubbles: true, detail: { value } }));
          el.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: value.slice(-1) || "Enter" }));
          el.blur();
          return 1;
        } else if (el.type === "date" || el.type === "datetime-local" || el.type === "month" || el.type === "week") {
          var _parsed2 = (root.CcParseDateValue || {}).parseDateValue ? root.CcParseDateValue.parseDateValue(value) : null;
          var isoValue;
          if (el.type === "datetime-local" && String(value || "").includes("T")) {
            isoValue = String(value);
          } else if (_parsed2 && _parsed2.isoDate) {
            isoValue = el.type === "month" ? _parsed2.isoMonth : _parsed2.isoDate;
          } else {
            isoValue = value;
          }
          if (el.type === "datetime-local" && !isoValue.includes("T")) {
            isoValue += "T00:00";
          }
          const niv = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value");
          el.focus();
          if (niv) niv.set.call(el, isoValue);
          else el.value = isoValue;
          el.dispatchEvent(new Event("input", { bubbles: true }));
          el.dispatchEvent(new Event("change", { bubbles: true }));
          el.blur();
          console.debug("[CC] date fill:", selector, "original:", value, "iso:", isoValue, "result:", el.value);
          return el.value ? 1 : 0;
        }
        return null;
      }
    });
  };
})(typeof globalThis !== "undefined" ? globalThis : this);

/* ==== install-fill-one-text.ts ==== */
(function(root) {
  "use strict";
  root.CcExecParts = root.CcExecParts || {};
  root.CcExecParts.installFillOneText = function(k) {
    const b = root.CcExecParts.bindKernelLocals(k);
    const {
      portalAdapters,
      filledBySource,
      mapping,
      _replayResults,
      _ccRecords,
      RUNTIME_VERSION,
      _CC_USE_PLUGINS,
      PRIORITY_KEYS,
      entries,
      getEl,
      _emitFillDebug,
      _flushRecords,
      _pushSelectRecord,
      settleAfterAct,
      waitForSelectOptionsSequential,
      waitForOptions,
      detectStrategy,
      verifyValue,
      _isPlaceholderOption,
      _realOptions,
      _sampleOptions,
      _readSelectActual,
      _selectLoadMode,
      _cascadeSemanticKey,
      _CASCADE_PARENTS,
      _cascadeSettled,
      _isPlaceholderPlanned,
      _selectIsActive,
      fillOne
    } = b;
    k.fillOneHandlers = k.fillOneHandlers || [];
    var _fot = root.CcFillOneText || {};
    k.fillOneHandlers.push({
      id: "text",
      try(el, selector, value, type, elType) {
        if (_fot.fillText) return _fot.fillText(el, value);
        const isTextarea = el.tagName === "TEXTAREA";
        const niv = isTextarea ? Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value") : Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value");
        if (typeof window.keystrokeFillSync === "function") {
          const ok = window.keystrokeFillSync(el, value);
          if (el.getAttribute && el.getAttribute("data-type") === "fullName") {
            const allInputs = Array.from(document.querySelectorAll('input[type="text"]'));
            const idx = allInputs.indexOf(el);
            const next = allInputs[idx + 1];
            if (next && next.getAttribute("data-type") === "text") {
              setTimeout(() => {
                if (next.value && next.value.length > 0) return;
                const fillHindi = (hindiVal) => {
                  if (typeof window.keystrokeFillSync === "function") window.keystrokeFillSync(next, hindiVal);
                };
                fetch("https://inputtools.google.com/request?text=" + encodeURIComponent(value) + "&itc=hi-t-i0-und&num=1&cp=0&cs=1&ie=utf-8&oe=utf-8").then((r) => r.json()).then((d) => {
                  var _a, _b, _c;
                  const hindi = (_c = (_b = (_a = d == null ? void 0 : d[1]) == null ? void 0 : _a[0]) == null ? void 0 : _b[1]) == null ? void 0 : _c[0];
                  fillHindi(hindi || value);
                }).catch(() => fillHindi(value));
              }, 500);
            }
          }
          return ok ? 1 : 0;
        }
        el.focus();
        if (niv) niv.set.call(el, value);
        else el.value = value;
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
        el.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, key: "a" }));
        el.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: "a" }));
        el.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: value.slice(-1) }));
        return 1;
        return 0;
      }
    });
  };
})(typeof globalThis !== "undefined" ? globalThis : this);

/* ==== install-fill-one.ts ==== */
(function(root) {
  "use strict";
  root.CcExecParts = root.CcExecParts || {};
  root.CcExecParts.installFillOne = function(k) {
    k.fillOneHandlers = k.fillOneHandlers || [];
    var _resolve = root.CcResolveCcSelector ? root.CcResolveCcSelector.resolveCcSelector : function(sel) {
      return document.querySelector(sel);
    };
    function resolveEl(selector) {
      return _resolve(selector);
    }
    function detectElType(el, type) {
      const tagName = el.tagName.toLowerCase();
      if (tagName === "select") return "select";
      if (tagName === "ng-select") return "ng-dropdown";
      if (tagName === "mat-select") return "mat-select";
      if (tagName === "mat-checkbox") return "mat-checkbox";
      if (tagName === "mat-radio-button") return "mat-radio";
      if (el.classList && (el.classList.contains("ng-dropdown") || el.classList.contains("ng-select"))) return "ng-dropdown";
      if (tagName !== "input" && (el.getAttribute("role") === "combobox" || el.getAttribute("role") === "listbox")) return "ng-dropdown";
      return el.type || type || "text";
    }
    k.fillOne = function fillOne(selector, value, type) {
      try {
        const el = resolveEl(selector);
        if (!el) return 0;
        const elType = detectElType(el, type);
        console.log("[CC] fillOne:", selector, "elType:", elType, "value:", value);
        const handlers = k.fillOneHandlers || [];
        for (let i = 0; i < handlers.length; i++) {
          const r = handlers[i].try(el, selector, value, type, elType);
          if (r !== null && r !== void 0) return r;
        }
        return 0;
      } catch (e) {
        return 0;
      }
    };
  };
})(typeof globalThis !== "undefined" ? globalThis : this);

/* ==== install-sequential.ts ==== */
(function(root) {
  "use strict";
  root.CcExecParts = root.CcExecParts || {};
  root.CcExecParts.installSequential = function(k) {
    const b = root.CcExecParts.bindKernelLocals(k);
    const portalAdapters = b.portalAdapters;
    const filledBySource = b.filledBySource;
    const mapping = b.mapping;
    const _replayResults = b._replayResults;
    const _ccRecords = b._ccRecords;
    const RUNTIME_VERSION = b.RUNTIME_VERSION;
    const _CC_USE_PLUGINS = b._CC_USE_PLUGINS;
    const PRIORITY_KEYS = b.PRIORITY_KEYS;
    const entries = b.entries;
    const getEl = b.getEl;
    const _emitFillDebug = b._emitFillDebug;
    const _flushRecords = b._flushRecords;
    const _pushSelectRecord = b._pushSelectRecord;
    const settleAfterAct = b.settleAfterAct;
    const waitForSelectOptionsSequential = b.waitForSelectOptionsSequential;
    const waitForOptions = b.waitForOptions;
    const waitForDOMQuiet = b.waitForDOMQuiet || function(ms) {
      return new Promise(function(r) {
        setTimeout(r, ms || 300);
      });
    };
    const waitForNetworkIdle = b.waitForNetworkIdle || function(q, m) {
      return window.ccWaitForNetworkIdle ? window.ccWaitForNetworkIdle(q || 200, m || 8e3) : Promise.resolve({ idle: true, waitedMs: 0 });
    };
    const _buildFillRecord = root.CcBuildFillRecord && root.CcBuildFillRecord.buildFillRecord || function(base) {
      return Object.assign({ ts: Date.now(), rv: RUNTIME_VERSION, fillMode: "sequential" }, base);
    };
    const detectStrategy = b.detectStrategy;
    const verifyValue = b.verifyValue;
    const _isPlaceholderOption = b._isPlaceholderOption;
    const _realOptions = b._realOptions;
    const _sampleOptions = b._sampleOptions;
    const _readSelectActual = b._readSelectActual;
    const _selectLoadMode = b._selectLoadMode;
    const _cascadeSemanticKey = b._cascadeSemanticKey;
    const _CASCADE_PARENTS = b._CASCADE_PARENTS;
    const _cascadeSettled = b._cascadeSettled;
    const _isPlaceholderPlanned = b._isPlaceholderPlanned;
    const _selectIsActive = b._selectIsActive;
    const fillOne = b.fillOne;
    k._seqChunks = k._seqChunks || ["baked-solid"];
    k.fillSequential = async function fillSequential() {
      var _a, _b, _c, _d, _e;
      for (const [selector, fieldData] of entries) {
        const { value, type } = fieldData;
        let isNgDropdown = type === "ng-dropdown" || selector.startsWith("ng-dropdown-");
        const fieldLabel = (((_a = filledBySource[selector]) == null ? void 0 : _a.label) || selector).toLowerCase();
        const _fieldCtxEarly = filledBySource[selector] || {};
        _emitFillDebug("field.start", {
          selector,
          label: _fieldCtxEarly.label || fieldLabel,
          type,
          planned: value,
          profileKey: _fieldCtxEarly.profileKey || fieldData.profileKey || null
        });
        const _selectLike = /^(select|dropdown|ng-dropdown|mat-select)$/.test(type || "");
        const isDependent = _selectLike && PRIORITY_KEYS.some((pk) => fieldLabel.includes(pk) || selector.toLowerCase().includes(pk));
        let el = typeof root !== "undefined" && root.CcResolveCcSelector ? root.CcResolveCcSelector.resolveCcSelector(selector) : document.querySelector(selector);
        if (!isNgDropdown && el) {
          const _tag = el.tagName.toLowerCase();
          if (_tag === "ng-select" || el.classList && (el.classList.contains("ng-select") || el.classList.contains("ng-dropdown"))) {
            isNgDropdown = true;
          }
          if (!isNgDropdown && _tag !== "select" && _tag !== "input" && _tag !== "mat-select") {
            const _role = el.getAttribute("role");
            if (_role === "combobox" || _role === "listbox") isNgDropdown = true;
          }
        }
        if (el) {
          const plannedVisual = fieldData.visualLabel || ((_b = filledBySource == null ? void 0 : filledBySource[selector]) == null ? void 0 : _b.visualLabel) || "";
          if (plannedVisual && root.CcLabelStillMatches && typeof root.CcLabelStillMatches.matches === "function" && !root.CcLabelStillMatches.matches(el, plannedVisual)) {
            const liveVisual = typeof root.CcLabelStillMatches.read === "function" ? root.CcLabelStillMatches.read(el) : "";
            _ccRecords.push(_buildFillRecord({
              selector,
              value,
              type,
              label: plannedVisual,
              actualValue: liveVisual,
              result: "skipped",
              failReason: "label_drift",
              strategy: "label-guard"
            }, { rv: RUNTIME_VERSION }));
            _flushRecords();
            continue;
          }
          el.scrollIntoView({ behavior: "smooth", block: "center" });
          await new Promise((r) => setTimeout(r, 300));
        }
        const _t0 = Date.now();
        const _fieldCtx = {
          type,
          label: fieldData.label || ((_c = filledBySource[selector]) == null ? void 0 : _c.label) || selector,
          profileKey: fieldData.profileKey || ((_d = filledBySource[selector]) == null ? void 0 : _d.profileKey) || "",
          selector,
          matchBy: fieldData.matchBy || ((_e = filledBySource[selector]) == null ? void 0 : _e.matchBy) || "label"
        };
        const _selectLike2 = /^(select|dropdown|ng-dropdown|mat-select)$/.test(type || "");
        if (_selectLike2) console.log("[CC] route:", selector, "type:", type, "isNgDropdown:", isNgDropdown, "isDependent:", isDependent, "filled:", k.filled, "elTag:", el == null ? void 0 : el.tagName, "elType:", el == null ? void 0 : el.type);
        if (fieldData.type === "button") {
          const _btnPlugin = _CC_USE_PLUGINS && typeof findPlugin === "function" ? findPlugin(el, _fieldCtx) : null;
          if (_btnPlugin) {
            const _pResult = _btnPlugin.fill(el, value, { attempt: 1 });
            const _preCount = document.querySelectorAll("input,select,textarea,div.ng-dropdown").length;
            await waitForDOMQuiet(800);
            const newFields = document.querySelectorAll('input[type="text"],input[type="email"],input[type="tel"],input[type="number"],input[type="date"],input[type="radio"],input[type="checkbox"],input:not([type]),textarea,select,div.ng-dropdown');
            const newFieldCount = newFields.length;
            _ccRecords.push(_buildFillRecord({ selector, value, type: "button", result: "filled", strategy: "plugin:button-click", plugin: "button-click", role: fieldData.role || "navigation", newFieldCount, transitionOutcome: newFieldCount > _preCount ? "transition_success" : newFieldCount === _preCount ? "transition_no_change" : "transition_partial", durationMs: Date.now() - _t0 }, { rv: RUNTIME_VERSION }));
            _flushRecords();
            console.debug("[CC][plugin] button-click", selector, "newFields:", newFieldCount);
          } else {
            if (el) el.click();
            await waitForDOMQuiet(800);
          }
          await settleAfterAct("button");
        } else if (isNgDropdown) {
          if (!el) {
            _ccRecords.push(_buildFillRecord({ selector, value, type, result: "skipped", failReason: "no-element", strategy: "ng-dropdown" }, { rv: RUNTIME_VERSION }));
            _flushRecords();
            continue;
          }
          if (_realOptions(el).length === 0 && el.tagName === "SELECT") {
            el = await waitForSelectOptionsSequential(selector, 5e3) || el;
          }
          const _ngPlugin = _CC_USE_PLUGINS && typeof findPlugin === "function" ? findPlugin(el, _fieldCtx) : null;
          if (_ngPlugin) {
            try {
              const _ctx = { profileKey: _fieldCtx.profileKey, portalAdapters: portalAdapters || {}, attempt: 1 };
              const _pResult = await _ngPlugin.fill(el, value, _ctx);
              const _r = _pResult.success ? 1 : 0;
              k.filled += _r;
              _ccRecords.push(_buildFillRecord({ selector, value, type, result: _r ? "filled" : "skipped", failReason: _r ? null : _pResult.reason, strategy: "plugin:" + _ngPlugin.id, plugin: _ngPlugin.id, durationMs: Date.now() - _t0 }, { rv: RUNTIME_VERSION }));
              _flushRecords();
            } catch (e) {
              await fillOne(selector, value, type);
            }
          } else {
            await fillOne(selector, value, type);
          }
          await settleAfterAct("select");
        } else if (_selectLike && el && el.tagName === "SELECT") {
          const semKey = _cascadeSemanticKey(_fieldCtx.label, _fieldCtx.profileKey, selector);
          let liveEl = el;
          let loadMode = _selectLoadMode(liveEl);
          let optionCountBefore = _realOptions(liveEl).length;
          let sampleBefore = _sampleOptions(liveEl);
          let settleMeta = { idle: true, waitedMs: 0 };
          if (_isPlaceholderPlanned(value)) {
            _pushSelectRecord({
              selector,
              value,
              type,
              label: _fieldCtx.label,
              profileKey: _fieldCtx.profileKey || null,
              result: "skipped",
              failReason: "placeholder_planned_value",
              strategy: "sequential",
              loadMode,
              actualValue: _readSelectActual(el).actualValue,
              durationMs: Date.now() - _t0
            });
            continue;
          }
          if (!_selectIsActive(el) && loadMode === "ajax") {
            _pushSelectRecord({
              selector,
              value,
              type,
              label: _fieldCtx.label,
              profileKey: _fieldCtx.profileKey || null,
              result: "skipped",
              failReason: "ajax_control_inactive",
              strategy: "sequential",
              loadMode: "ajax",
              actualValue: "",
              durationMs: Date.now() - _t0
            });
            continue;
          }
          if (_realOptions(liveEl).length === 0) {
            const exhausted = k.ajaxWaitBudgetMs <= 0 || k.ajaxNotLoadedCount >= 5;
            const cap = exhausted ? 500 : Math.min(6e3, Math.max(500, k.ajaxWaitBudgetMs));
            console.log("[CC] sequential-wait-options:", selector, "budget=", k.ajaxWaitBudgetMs, "cap=", cap);
            const waitedEl = await waitForSelectOptionsSequential(selector, cap);
            liveEl = waitedEl || document.querySelector(selector) || el;
            loadMode = _selectLoadMode(liveEl);
            if (_realOptions(liveEl).length === 0) {
              k.ajaxNotLoadedCount += 1;
              _pushSelectRecord({
                selector,
                value,
                type,
                label: _fieldCtx.label,
                profileKey: _fieldCtx.profileKey || null,
                result: "skipped",
                failReason: exhausted ? "ajax_wait_budget_exhausted" : "strategy_options_not_ready",
                strategy: "sequential",
                loadMode: "ajax",
                optionCount: 0,
                optionSample: _sampleOptions(liveEl, 8),
                actualValue: _readSelectActual(liveEl).actualValue,
                durationMs: Date.now() - _t0
              });
              continue;
            }
          }
          optionCountBefore = _realOptions(liveEl).length;
          sampleBefore = _sampleOptions(liveEl, 10);
          let strategy = "native-select";
          let attempt = 1;
          async function tryApply(attemptNo) {
            const _plugin = _CC_USE_PLUGINS && typeof findPlugin === "function" ? findPlugin(liveEl, _fieldCtx) : null;
            if (_plugin) {
              const _pResult = _plugin.fill(liveEl, value, {
                profileKey: _fieldCtx.profileKey,
                attempt: attemptNo
              });
              strategy = "plugin:" + _plugin.id;
              if (_pResult && _pResult.success) return { ok: true, reason: null };
              return {
                ok: false,
                reason: _pResult && _pResult.reason || "strategy_option_mismatch",
                optionCount: _pResult && _pResult.optionCount
              };
            }
            const _r = fillOne(selector, value, type) || 0;
            strategy = "native-select";
            if (_r) return { ok: true, reason: null };
            const real = _realOptions(liveEl);
            if (!real.length) return { ok: false, reason: "strategy_options_not_ready" };
            return { ok: false, reason: "strategy_option_mismatch", optionCount: real.length };
          }
          let applyRes = await tryApply(1);
          if (!applyRes.ok && k.ajaxWaitBudgetMs > 2e3 && k.ajaxNotLoadedCount < 3) {
            attempt = 2;
            await settleAfterAct("select", { budgetMs: 2500 });
            liveEl = document.querySelector(selector) || liveEl;
            if (_realOptions(liveEl).length > 0) applyRes = await tryApply(2);
          }
          settleMeta = await settleAfterAct("select");
          liveEl = document.querySelector(selector) || liveEl;
          const actual = _readSelectActual(liveEl);
          let matchOk = applyRes.ok;
          if (!matchOk && actual.actualValue && value) {
            const np = String(value).toLowerCase().replace(/[^a-z0-9]/g, "");
            const na = String(actual.actualValue).toLowerCase().replace(/[^a-z0-9]/g, "");
            if (np && na && (np === na || na.includes(np) || np.includes(na))) matchOk = true;
          }
          if (matchOk) {
            k.filled += 1;
            if (semKey) {
              _cascadeSettled[semKey] = {
                key: semKey,
                selector,
                value,
                actualValue: actual.actualValue
              };
            }
          } else if (applyRes.reason === "strategy_options_not_ready" || applyRes.reason === "ajax_options_not_loaded") {
            k.ajaxNotLoadedCount += 1;
          }
          _pushSelectRecord({
            selector,
            value,
            type,
            label: _fieldCtx.label,
            profileKey: _fieldCtx.profileKey || null,
            result: matchOk ? "filled" : "skipped",
            failReason: matchOk ? null : applyRes.reason || "strategy_failed",
            strategy,
            loadMode,
            optionCount: _realOptions(liveEl).length,
            optionSample: _sampleOptions(liveEl, 10),
            optionSampleBefore: sampleBefore,
            optionCountBefore,
            actualValue: actual.actualValue,
            actualOptionValue: actual.actualOptionValue,
            verified: matchOk,
            attempt,
            waitedMs: settleMeta.waitedMs,
            networkIdle: settleMeta.idle,
            durationMs: Date.now() - _t0
          });
        } else if (el && el.type === "file") {
          if (value && (value.startsWith("http://") || value.startsWith("https://"))) {
            try {
              const resp = await fetch(value);
              if (resp.ok) {
                const blob = await resp.blob();
                const fileName = value.split("/").pop().split("?")[0] || "document";
                const file = new File([blob], fileName, {
                  type: blob.type || "application/octet-stream",
                  lastModified: Date.now()
                });
                const dt = new DataTransfer();
                dt.items.add(file);
                el.files = dt.files;
                el.dispatchEvent(new Event("change", { bubbles: true }));
                k.filled += 1;
                console.debug("[CC] file URL assigned:", selector, fileName, file.size, "bytes");
                _ccRecords.push(_buildFillRecord({
                  selector,
                  value,
                  type: "file",
                  label: _fieldCtx.label,
                  result: "filled",
                  strategy: "file-url-fetch",
                  fileName,
                  fileSize: file.size,
                  durationMs: Date.now() - _t0
                }, { rv: RUNTIME_VERSION }));
                _flushRecords();
              } else {
                _ccRecords.push(_buildFillRecord({
                  selector,
                  value,
                  type: "file",
                  label: _fieldCtx.label,
                  result: "waiting_human",
                  failReason: "fetch-" + resp.status,
                  strategy: "file-needs-human",
                  durationMs: Date.now() - _t0
                }, { rv: RUNTIME_VERSION }));
                _flushRecords();
              }
            } catch (e) {
              _ccRecords.push(_buildFillRecord({
                selector,
                value,
                type: "file",
                label: _fieldCtx.label,
                result: "waiting_human",
                failReason: e.message || "fetch-error",
                strategy: "file-needs-human",
                durationMs: Date.now() - _t0
              }, { rv: RUNTIME_VERSION }));
              _flushRecords();
            }
          } else {
            _ccRecords.push(_buildFillRecord({
              selector,
              value: value || null,
              type: "file",
              label: _fieldCtx.label,
              result: "waiting_human",
              failReason: value ? "filename_only_no_url" : "no_file_value",
              strategy: "file-needs-human",
              durationMs: Date.now() - _t0
            }, { rv: RUNTIME_VERSION }));
            _flushRecords();
          }
          await settleAfterAct("text");
        } else {
          const isChoice = type === "radio-click" || type === "radio" || type === "radio-group" || type === "checkbox" || type === "mat-checkbox" || type === "mat-radio" || el && (el.type === "radio" || el.type === "checkbox");
          try {
            const _r = fillOne(selector, value, type) || 0;
            if (isChoice) await settleAfterAct("choice");
            else await settleAfterAct("text");
            const _el2 = el || document.querySelector(selector);
            const _strategy = detectStrategy(_el2, type);
            const _ver = await verifyValue(selector, value, isChoice ? 80 : 100);
            let _trulyFilled = false;
            if (isChoice && _r === 1) {
              if (_el2 && (_el2.type === "radio" || _el2.type === "checkbox")) {
                _trulyFilled = !!_el2.checked;
              } else {
                _trulyFilled = _ver.ok || _r === 1;
              }
              if (!_trulyFilled && _ver.actualValue === "true") _trulyFilled = true;
            } else {
              _trulyFilled = _r === 1 && _ver.ok;
            }
            if (_trulyFilled) k.filled += 1;
            const _recChoice = _buildFillRecord({
              selector,
              value,
              type,
              label: _fieldCtx.label,
              profileKey: _fieldCtx.profileKey || null,
              result: _trulyFilled ? "filled" : "skipped",
              failReason: _trulyFilled ? null : _r ? _ver.reason || "strategy_failed" : _el2 ? "strategy_failed" : "no-element",
              actualValue: _ver.actualValue,
              verified: _trulyFilled,
              strategy: _strategy,
              matchBy: _fieldCtx.matchBy,
              durationMs: Date.now() - _t0
            }, { rv: RUNTIME_VERSION });
            _ccRecords.push(_recChoice);
            _flushRecords();
            _emitFillDebug(_trulyFilled ? "field.done" : "field.fail", {
              selector,
              label: _fieldCtx.label,
              type,
              planned: value,
              actual: _ver.actualValue,
              failReason: _recChoice.failReason,
              strategy: _strategy
            });
          } catch (e) {
            _ccRecords.push(_buildFillRecord({
              selector,
              value,
              type,
              result: "error",
              error: e.message
            }, { rv: RUNTIME_VERSION }));
            _flushRecords();
            _emitFillDebug("field.fail", {
              selector,
              type,
              planned: value,
              failReason: e.message || "error"
            });
          }
        }
      }
    };
  };
})(typeof globalThis !== "undefined" ? globalThis : this);

/* ==== install-post-fill-corrections.ts ==== */
(function(root) {
  "use strict";
  root.CcExecParts = root.CcExecParts || {};
  root.CcExecParts.installPostFillCorrections = function(k) {
    const b = root.CcExecParts.bindKernelLocals(k);
    const {
      portalAdapters,
      filledBySource,
      mapping,
      allFields,
      _replayResults,
      _ccRecords,
      RUNTIME_VERSION,
      _CC_USE_PLUGINS,
      PRIORITY_KEYS,
      entries,
      getEl,
      _emitFillDebug,
      _flushRecords,
      _pushSelectRecord,
      settleAfterAct,
      waitForSelectOptionsSequential,
      waitForOptions,
      detectStrategy,
      verifyValue,
      _isPlaceholderOption,
      _realOptions,
      _sampleOptions,
      _readSelectActual,
      _selectLoadMode,
      _cascadeSemanticKey,
      _CASCADE_PARENTS,
      _cascadeSettled,
      _isPlaceholderPlanned,
      _selectIsActive,
      fillOne
    } = b;
    var _pfc = root.CcPostFillCorrections || {};
    if (_pfc.installCorrectionsObserver) {
      _pfc.installCorrectionsObserver({
        entries: Array.from(entries),
        filledBySource,
        allFields,
        getEl,
        records: k.records || [],
        RUNTIME_VERSION
      });
      return;
    }
    setTimeout(() => {
      var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k;
      const _ccBackendUrl = document.body.getAttribute("data-cc-backend") || "";
      const _ccFormKey = document.body.getAttribute("data-cc-formkey") || "";
      const snapshot = {};
      const fieldMeta = {};
      for (const [selector, fieldData] of entries) {
        let el = getEl(selector);
        if (!el) continue;
        const val = el.tagName === "SELECT" ? ((_a = el.options[el.selectedIndex]) == null ? void 0 : _a.text) || el.value : ((_b = el.classList) == null ? void 0 : _b.contains("ng-dropdown")) ? ((_d = (_c = el.querySelector(".value-area .value,.select-type,.ng-value-label")) == null ? void 0 : _c.textContent) == null ? void 0 : _d.trim()) || "" : el.value || "";
        snapshot[selector] = val;
        const rec = _ccRecords.find((r) => r.selector === selector);
        fieldMeta[selector] = {
          label: ((_e = filledBySource[selector]) == null ? void 0 : _e.label) || selector,
          semanticKey: ((_f = filledBySource[selector]) == null ? void 0 : _f.semanticKey) || "",
          profileKey: ((_g = filledBySource[selector]) == null ? void 0 : _g.profileKey) || "",
          plugin: (rec == null ? void 0 : rec.plugin) || null,
          strategy: (rec == null ? void 0 : rec.strategy) || "",
          originalResult: (rec == null ? void 0 : rec.result) || "unknown",
          autofilledValue: fieldData.value
        };
      }
      if (Array.isArray(allFields)) {
        for (const f of allFields) {
          if (snapshot[f.selector] !== void 0) continue;
          const el = getEl(f.selector);
          if (!el) continue;
          const val = el.tagName === "SELECT" ? ((_h = el.options[el.selectedIndex]) == null ? void 0 : _h.text) || el.value : ((_i = el.classList) == null ? void 0 : _i.contains("ng-dropdown")) ? ((_k = (_j = el.querySelector(".value-area .value,.select-type,.ng-value-label")) == null ? void 0 : _j.textContent) == null ? void 0 : _k.trim()) || "" : el.value || "";
          snapshot[f.selector] = val;
          fieldMeta[f.selector] = {
            label: f.label || f.selector,
            semanticKey: "",
            profileKey: "",
            plugin: null,
            strategy: "unmapped",
            originalResult: "unmapped",
            autofilledValue: ""
          };
        }
      }
      function captureCorrections(trigger) {
        var _a2, _b2, _c2, _d2;
        const corrections = [];
        for (const [selector, originalVal] of Object.entries(snapshot)) {
          let el = getEl(selector);
          if (!el) continue;
          const currentVal = el.tagName === "SELECT" ? ((_a2 = el.options[el.selectedIndex]) == null ? void 0 : _a2.text) || el.value : ((_b2 = el.classList) == null ? void 0 : _b2.contains("ng-dropdown")) ? ((_d2 = (_c2 = el.querySelector(".value-area .value,.select-type,.ng-value-label")) == null ? void 0 : _c2.textContent) == null ? void 0 : _d2.trim()) || "" : el.value || "";
          if (currentVal !== originalVal && currentVal !== "") {
            const meta = fieldMeta[selector] || {};
            corrections.push({
              selector,
              field: meta.label,
              semanticKey: meta.semanticKey,
              profileKey: meta.profileKey,
              autofilledValue: meta.autofilledValue,
              snapshotValue: originalVal,
              finalOperatorValue: currentVal,
              correctionType: !originalVal || originalVal === "" ? "completion" : "override",
              originalResult: meta.originalResult,
              plugin: meta.plugin,
              strategy: meta.strategy,
              trigger,
              ts: Date.now()
            });
          }
        }
        return corrections;
      }
      function postCorrections(trigger) {
        const corrections = captureCorrections(trigger);
        if (corrections.length === 0) return;
        document.body.setAttribute("data-cc-corrections", JSON.stringify(corrections));
        if (_ccBackendUrl) {
          const _ccToken = document.body.getAttribute("data-cc-token") || "";
          const _ccProfileId = document.body.getAttribute("data-cc-profile-id") || "";
          const headers = { "Content-Type": "application/json" };
          if (_ccToken) headers["Authorization"] = "Bearer " + _ccToken;
          fetch(_ccBackendUrl + "/corrections", {
            method: "POST",
            headers,
            body: JSON.stringify({ hostname: location.hostname, semanticFormKey: _ccFormKey, profileId: _ccProfileId, trigger, corrections })
          }).catch(() => {
          });
        }
      }
      document.addEventListener("click", (e) => {
        const btn = e.target.closest('button,input[type="submit"],[type="submit"],.btn-submit,.submit-btn');
        if (!btn) return;
        const txt = (btn.textContent || btn.value || "").toLowerCase();
        if (/submit|save|next|continue|proceed|finalize/i.test(txt) || btn.type === "submit") {
          postCorrections("submit");
        }
      }, true);
      window.addEventListener("beforeunload", () => postCorrections("unload"));
    }, 1e4);
  };
})(typeof globalThis !== "undefined" ? globalThis : this);

/* ==== install-post-fill-confirm.ts ==== */
(function(root) {
  "use strict";
  root.CcExecParts = root.CcExecParts || {};
  root.CcExecParts.installPostFillConfirm = function(k) {
    const b = root.CcExecParts.bindKernelLocals(k);
    const {
      portalAdapters,
      filledBySource,
      mapping,
      _replayResults,
      _ccRecords,
      RUNTIME_VERSION,
      _CC_USE_PLUGINS,
      PRIORITY_KEYS,
      entries,
      getEl,
      _emitFillDebug,
      _flushRecords,
      _pushSelectRecord,
      settleAfterAct,
      waitForSelectOptionsSequential,
      waitForOptions,
      detectStrategy,
      verifyValue,
      _isPlaceholderOption,
      _realOptions,
      _sampleOptions,
      _readSelectActual,
      _selectLoadMode,
      _cascadeSemanticKey,
      _CASCADE_PARENTS,
      _cascadeSettled,
      _isPlaceholderPlanned,
      _selectIsActive,
      fillOne
    } = b;
    setTimeout(function() {
      var _cfp = root.CcConfirmFieldPattern || {};
      var _isConfirmField = _cfp.isConfirmField || function() {
        return false;
      };
      var _getBaseId = _cfp.getBaseId || function(id) {
        return id;
      };
      var allInputs = Array.from(document.querySelectorAll("input[type=text],input[type=email],input[type=tel],input[type=number]"));
      allInputs.forEach(function(el) {
        if (!el.id && !el.name) return;
        var id = (el.id || el.name || "").toLowerCase();
        var label = (function() {
          if (el.id) {
            var l = document.querySelector('label[for="' + el.id + '"]');
            if (l) return l.textContent.toLowerCase();
          }
          return "";
        })();
        var isConfirm = _isConfirmField(id, label);
        if (!isConfirm) return;
        if (el.value) return;
        var baseId = _getBaseId(id);
        var primary = document.getElementById(baseId) || document.querySelector('[id$="' + baseId + '"]') || document.querySelector('[name="' + baseId + '"]');
        if (!primary || !primary.value) {
          var ph = (el.placeholder || "").toLowerCase();
          if (ph.includes("dd/mm") || ph.includes("dd-mm")) {
            var allFilled = Array.from(document.querySelectorAll("input[type=text]")).filter(function(inp) {
              return inp !== el && inp.value && (inp.placeholder || "").toLowerCase().match(/dd.mm/);
            });
            if (allFilled.length > 0) primary = allFilled[0];
          }
        }
        if (!primary || !primary.value) return;
        var niv = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value");
        if (niv) niv.set.call(el, primary.value);
        else el.value = primary.value;
        ["input", "change", "blur"].forEach(function(ev) {
          el.dispatchEvent(new Event(ev, { bubbles: true }));
        });
        _ccRecords.push((root.CcBuildFillRecord ? root.CcBuildFillRecord.buildFillRecord : function(b2) {
          return Object.assign({ ts: Date.now(), rv: RUNTIME_VERSION, fillMode: "sequential" }, b2);
        })({ selector: "#" + (el.id || el.name), value: primary.value, type: "text", result: "filled", strategy: "confirm-mirror", durationMs: 0 }, { rv: RUNTIME_VERSION }));
        _flushRecords();
      });
    }, 4e3);
  };
})(typeof globalThis !== "undefined" ? globalThis : this);

/* ==== install-post-fill-mirror.ts ==== */
(function(root) {
  "use strict";
  root.CcExecParts = root.CcExecParts || {};
  root.CcExecParts.installPostFillMirror = function(k) {
    const b = root.CcExecParts.bindKernelLocals(k);
    const {
      portalAdapters,
      filledBySource,
      mapping,
      _replayResults,
      _ccRecords,
      RUNTIME_VERSION,
      _CC_USE_PLUGINS,
      PRIORITY_KEYS,
      entries,
      getEl,
      _emitFillDebug,
      _flushRecords,
      _pushSelectRecord,
      settleAfterAct,
      waitForSelectOptionsSequential,
      waitForOptions,
      detectStrategy,
      verifyValue,
      _isPlaceholderOption,
      _realOptions,
      _sampleOptions,
      _readSelectActual,
      _selectLoadMode,
      _cascadeSemanticKey,
      _CASCADE_PARENTS,
      _cascadeSettled,
      _isPlaceholderPlanned,
      _selectIsActive,
      fillOne
    } = b;
    setTimeout(function() {
      var _cfp = root.CcConfirmFieldPattern || {};
      var _isConfirmField = _cfp.isConfirmField || function() {
        return false;
      };
      var _getBaseId = _cfp.getBaseId || function(id) {
        return id;
      };
      var allInputs = Array.from(document.querySelectorAll("input[type=text],input[type=email],input[type=tel]"));
      allInputs.forEach(function(el) {
        if (!el.id) return;
        if (el.value) return;
        var id = el.id.toLowerCase();
        var confirmId = null;
        allInputs.forEach(function(other) {
          if (!other.id || other === el) return;
          var oid = other.id.toLowerCase();
          if (_isConfirmField(oid)) {
            var baseId = _getBaseId(oid);
            if (baseId === id || id.includes(baseId) || baseId.includes(id)) confirmId = other.id;
          }
        });
        if (!confirmId) return;
        var _mirrorTarget = document.getElementById(confirmId);
        var _mirroring = false;
        el.addEventListener("input", function() {
          if (_mirroring) return;
          _mirroring = true;
          var niv = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value");
          if (niv) niv.set.call(_mirrorTarget, el.value);
          else _mirrorTarget.value = el.value;
          ["input", "change"].forEach(function(ev) {
            _mirrorTarget.dispatchEvent(new Event(ev, { bubbles: true }));
          });
          _mirroring = false;
        });
      });
    }, 3e3);
    try {
      document.body.setAttribute("data-cc-records", JSON.stringify(_ccRecords));
    } catch (e) {
    }
  };
})(typeof globalThis !== "undefined" ? globalThis : this);

/* ==== install-post-fill.ts ==== */
(function(root) {
  "use strict";
  root.CcExecParts = root.CcExecParts || {};
  root.CcExecParts.installPostFill = function(k) {
    root.CcExecParts.installPostFillCorrections(k);
    root.CcExecParts.installPostFillConfirm(k);
    root.CcExecParts.installPostFillMirror(k);
  };
})(typeof globalThis !== "undefined" ? globalThis : this);

/* ==== fill-form-fields-sequential.ts ==== */
globalThis.fillFormFieldsSequential = async function fillFormFieldsSequential(mapping, filledBySource, portalAdapters, allFields) {
  portalAdapters = portalAdapters || {};
  const parts = typeof globalThis !== "undefined" && globalThis.CcExecParts || {};
  const need = [
    "bindKernelLocals",
    "installDebug",
    "installSelectHelpers",
    "installSettle",
    "installDomOrder",
    "installStrategy",
    "installFillOne",
    "installSequential"
  ];
  const soft = [
    "installFillOneNgHelpers",
    "installFillOneNg",
    "installFillOneMat",
    "installFillOneRadioPlanned",
    "installFillOneSelect",
    "installFillOneChoiceDom",
    "installFillOneDate",
    "installFillOneText",
    "installPostFill"
  ];
  const missingHard = need.filter((n) => typeof parts[n] !== "function");
  if (missingHard.length) {
    const ver = typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.getManifest ? chrome.runtime.getManifest().version : "?";
    const present = Object.keys(parts).filter((k2) => k2 === "bindKernelLocals" || k2.indexOf("install") === 0).sort().join("|");
    console.error("[CC] executor hard parts missing:", missingHard.join(","), "present=", present, "ver=", ver);
    throw new Error("executor_parts_not_loaded:" + missingHard[0] + " @" + ver);
  }
  const missingSoft = soft.filter((n) => typeof parts[n] !== "function");
  if (missingSoft.length) {
    console.warn("[CC] executor soft parts missing (inject incomplete?):", missingSoft.join(","));
  }
  const RUNTIME_VERSION = typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.getManifest ? chrome.runtime.getManifest().version : "inj";
  console.log(
    "[CC] fillFormFieldsSequential started v" + RUNTIME_VERSION + ", fields:",
    Object.keys(mapping || {}).length
  );
  const k = {
    mapping: mapping || {},
    filledBySource: filledBySource || {},
    portalAdapters,
    allFields: allFields || null,
    records: [],
    replayResults: {},
    RUNTIME_VERSION,
    STRATEGY_VERSION: "1.0",
    WAIT_ENGINE_VERSION: "1.2",
    CC_USE_PLUGINS: true,
    CC_LEGACY_COMPARE: true,
    fillRunId: "fill:" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
    ajaxWaitBudgetMs: 45e3,
    ajaxNotLoadedCount: 0,
    cascadeSettled: /* @__PURE__ */ Object.create(null),
    filled: 0,
    entries: [],
    PRIORITY_KEYS: null,
    CASCADE_PARENTS: null,
    fillOneHandlers: [],
    _seqChunks: []
  };
  k.flushRecords = function flushRecords() {
    try {
      document.body.setAttribute("data-cc-records", JSON.stringify(k.records));
    } catch (e) {
    }
  };
  function install(name) {
    if (typeof parts[name] === "function") parts[name](k);
  }
  install("installDebug");
  install("installSelectHelpers");
  install("installSettle");
  install("installDomOrder");
  install("installStrategy");
  install("installFillOneNgHelpers");
  install("installFillOneNg");
  install("installFillOneMat");
  install("installFillOneRadioPlanned");
  install("installFillOneSelect");
  install("installFillOneChoiceDom");
  install("installFillOneDate");
  install("installFillOneText");
  install("installFillOne");
  install("installSequential");
  if (typeof k.fillSequential !== "function") {
    throw new Error(
      "executor_parts_not_loaded:fillSequential @" + (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.getManifest ? chrome.runtime.getManifest().version : "?")
    );
  }
  k.emitFillDebug("fill.start", {
    fieldCount: Object.keys(k.mapping).length,
    waitEngine: k.WAIT_ENGINE_VERSION
  });
  await k.fillSequential();
  k.emitFillDebug("fill.end", {
    filled: k.filled,
    records: k.records.length,
    ajaxBudgetLeftMs: k.ajaxWaitBudgetMs
  });
  parts.installPostFill(k);
  try {
    document.body.setAttribute("data-cc-records", JSON.stringify(k.records));
  } catch (e) {
  }
  return k.filled;
};
