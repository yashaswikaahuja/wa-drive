/**
 * AUTO-GENERATED — do not edit.
 * Source: @cc/orchestrator
 * Rebuild: pnpm --filter cybercontrol-extension build
 */

/* ==== script-manifests.ts ==== */
(function(root) {
  "use strict";
  var SEQUENTIAL_KERNEL_SCRIPTS = Object.freeze([
    "shared-bundle.js",
    // @cc/shared — dom-utils, option-match, network-idle
    "autofill/plugins-bundle.js",
    // @cc/plugins — interface, cascade-select, ng-dropdown, keystroke
    "drivers-bundle.js",
    // @cc/drivers — dispatch, dom, input, select, interaction
    "autofill/extractor-bundle.js",
    // @cc/extractor
    "autofill/mapper-bundle.js",
    // @cc/mapper
    "autofill/executor-bundle.js"
    // @cc/executor
  ]);
  var PRODUCT_PATH_SCRIPTS = Object.freeze([
    "runtime/gateway/interaction.js",
    "runtime/dom-gateway.js",
    "runtime/dom-settle.js",
    "runtime/dom-evidence.js",
    "runtime/errors.js",
    "runtime/navigation-contract.js",
    "perception/binding-registry.js",
    "perception/revision-manager.js",
    "perception/canonical-hash.js",
    "perception/privacy-filter.js",
    "perception/widget-classifier.js",
    "perception/adapters/index.js",
    "perception/node-factory.js",
    "perception/edge-factory.js",
    "perception/graph-invariants.js",
    "perception/delta-apply.js",
    "perception/context-discovery.js",
    "perception/snapshot-builder.js",
    "perception/validator.js",
    "perception/visual-context.js",
    "perception/index.js",
    "runtime/action-plan-executor.js"
  ]);
  root.CcScriptManifests = {
    SEQUENTIAL_KERNEL_SCRIPTS,
    PRODUCT_PATH_SCRIPTS
  };
})(typeof globalThis !== "undefined" ? globalThis : this);
if (typeof module !== "undefined" && typeof globalThis !== "undefined") {
  module.exports = globalThis.CcScriptManifests;
}

/* ==== flatten-profile.ts ==== */
(function(root2) {
  "use strict";
  function flattenProfile(profile) {
    var flat = {};
    var raw = profile && (profile.data || profile) || {};
    for (var k in raw) {
      var v = raw[k];
      flat[k] = v && typeof v === "object" && "value" in v ? v.value : v;
    }
    if (profile && profile.name) flat.name = flat.name || profile.name;
    function copyIfEmpty(fromKey, toKey) {
      if (flat[fromKey] != null && String(flat[fromKey]).trim() !== "" && (flat[toKey] == null || String(flat[toKey]).trim() === "")) {
        flat[toKey] = flat[fromKey];
      }
    }
    var keys = Object.keys(flat);
    for (var i = 0; i < keys.length; i++) {
      var src = keys[i];
      copyIfEmpty(src, src.replace(/-/g, "_"));
      copyIfEmpty(src, src.replace(/_/g, "-"));
    }
    copyIfEmpty("email-id", "email");
    copyIfEmpty("email_id", "email");
    copyIfEmpty("email", "email_id");
    copyIfEmpty("phone", "mobile");
    copyIfEmpty("mobile", "phone");
    copyIfEmpty("sub-division", "sub_division");
    copyIfEmpty("sub_division", "sub-division");
    return flat;
  }
  root2.CcFlattenProfile = { flattenProfile };
})(typeof globalThis !== "undefined" ? globalThis : this);
if (typeof module !== "undefined") module.exports = root.CcFlattenProfile;

/* ==== mapping-relation.ts ==== */
(function(root) {
  "use strict";
  var MONTH_NAMES = ["", "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  function parseDobParts(dob) {
    if (dob == null) return null;
    var dobStr = String(dob).trim();
    if (!dobStr) return null;
    var m1 = dobStr.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})$/);
    var m2 = dobStr.match(/^(\d{4})[\/\-.](\d{1,2})[\/\-.](\d{1,2})$/);
    if (m1) return { day: m1[1].padStart(2, "0"), month: m1[2].padStart(2, "0"), year: m1[3] };
    if (m2) return { day: m2[3].padStart(2, "0"), month: m2[2].padStart(2, "0"), year: m2[1] };
    return null;
  }
  function profileAtom(profile, key) {
    if (!profile || key == null) return null;
    var entry = profile[key];
    if (entry == null) return null;
    var v = typeof entry === "object" && entry && "value" in entry ? entry.value : entry;
    if (v == null) return null;
    var s = String(v).trim();
    return s === "" ? null : s;
  }
  function normLoose(s) {
    return String(s || "").toLowerCase().replace(/[^a-z0-9]/g, "");
  }
  function fieldBlob(field) {
    if (!field || typeof field !== "object") return "";
    return (field.label || "") + " " + (field.name || "") + " " + (field.id || "") + " " + (field.placeholder || "");
  }
  function isCompoundAtom(profileKey) {
    return /^(dob|date_of_birth|phone|mobile|email|email_id|name|full_name|aadhaar_number|aadhaar|pan_number)$/i.test(String(profileKey || ""));
  }
  function looksLikePartField(field) {
    var blob = fieldBlob(field).toLowerCase();
    var label = String(field && field.label || "").trim();
    if (/^dd$|^day$|^mm$|^month$|^yyyy$|^yyy$|^year$/i.test(label)) return true;
    if (/\b(dob_?day|birth_?day|day_of_birth|ddl_?day)\b/.test(blob)) return true;
    if (/\b(dob_?month|birth_?month|month_of_birth|ddl_?month)\b/.test(blob)) return true;
    if (/\b(dob_?year|birth_?year|year_of_birth|ddl_?year)\b/.test(blob)) return true;
    if (/last\s*4|last\s*four|last\s*6|first\s*4|first\s*3|last\s*digits|otp|suffix/i.test(blob)) return true;
    if (/email\s*(user|id|name)|username|local.?part/i.test(blob)) return true;
    return false;
  }
  function shapeCompatible(field, value) {
    if (value == null) return false;
    var s = String(value);
    var maxLen = Number(field && (field.maxLength || field.maxlength) || 0);
    if (maxLen > 0 && s.length > maxLen) return false;
    return true;
  }
  function isPerApplicationField(field) {
    if (!field) return false;
    if (field.relationHint === "per_application") return true;
    var ck = String(field.canonicalKey || "");
    return ck === "purpose" || ck === "apply_to_office";
  }
  function normalizeRelation(entry, field) {
    if (entry && entry.relation && entry.relation.kind) return Object.assign({}, entry.relation);
    if (isPerApplicationField(field)) return { kind: "per_application" };
    var pk = entry && entry.profileKey;
    if (!pk) return { kind: "unknown" };
    if (looksLikePartField(field) && isCompoundAtom(pk)) return { kind: "unknown" };
    return { kind: "identity" };
  }
  function applyDatePart(atom, part, field) {
    var dp = parseDobParts(atom);
    if (!dp) return null;
    var monthNum = parseInt(dp.month, 10) || 0;
    if (part === "day") {
      var preferPadded = /^dd$/i.test(String(field && field.label || "")) || /^dd$/i.test(String(field && field.placeholder || "")) || (field && field.type || "") === "text";
      return preferPadded ? dp.day : String(parseInt(dp.day, 10));
    }
    if (part === "month") {
      var t = String(field && field.type || "").toLowerCase();
      if (t === "select" || t === "dropdown" || t === "mat-select" || t === "ng-dropdown") return MONTH_NAMES[monthNum] || dp.month;
      return dp.month;
    }
    if (part === "year") return dp.year;
    return null;
  }
  function applyRelation(relation, profile, profileKey, field) {
    var kind = relation && relation.kind || "unknown";
    if (kind === "unknown" || kind === "per_application") return null;
    var atom = profileAtom(profile, profileKey);
    if (atom == null) return null;
    var value = null;
    if (kind === "identity") value = atom;
    else if (kind === "last_n") {
      var n1 = Math.max(1, Number(relation.n) || 0);
      if (!n1 || atom.length < n1) return null;
      value = atom.slice(-n1);
    } else if (kind === "first_n") {
      var n2 = Math.max(1, Number(relation.n) || 0);
      if (!n2 || atom.length < n2) return null;
      value = atom.slice(0, n2);
    } else if (kind === "date_part") value = applyDatePart(atom, relation.part, field);
    else if (kind === "email_local") {
      var at = atom.indexOf("@");
      if (at <= 0) return null;
      value = atom.slice(0, at);
    } else if (kind === "name_part") {
      var parts = atom.split(/\s+/).filter(Boolean);
      if (!parts.length) return null;
      if (relation.part === "first") value = parts[0];
      else if (relation.part === "last") value = parts[parts.length - 1];
      else if (relation.part === "middle") value = parts.length >= 3 ? parts.slice(1, -1).join(" ") : "";
      else return null;
    } else return null;
    if (value == null || String(value).trim() === "") return null;
    if (!shapeCompatible(field, value)) return null;
    return String(value);
  }
  function induceRelation(profile, profileKey, actualOrPlanned, field) {
    if (isPerApplicationField(field)) return { kind: "per_application" };
    if (!profileKey) return { kind: "unknown" };
    var atom = profileAtom(profile, profileKey);
    var sample = actualOrPlanned == null ? "" : String(actualOrPlanned).trim();
    if (!atom || !sample) {
      if (looksLikePartField(field) && isCompoundAtom(profileKey)) return { kind: "unknown" };
      return profileKey ? { kind: "identity" } : { kind: "unknown" };
    }
    if (normLoose(sample) === normLoose(atom) && shapeCompatible(field, atom)) return { kind: "identity" };
    var blob = fieldBlob(field).replace(/\b(?:ng-dd-|mat-select-|mat-input-|combobox-)\d+\b/gi, " ");
    var partish = looksLikePartField(field);
    var ck = String(field && field.canonicalKey || "");
    var notDob = ck && ck !== "dob" && ck !== "date_of_birth";
    if (!notDob) {
      notDob = /\b(gender|sex|education board|matriculation|qualification|year of passing|highest level|nationality|country of nationality)\b/i.test(blob) && !/\b(date of birth|dob|birth date|datebirth)\b/i.test(blob) && !/\bdd[\s_\-\/.]*mm[\s_\-\/.]*(?:yyyy|yyy)\b/i.test(blob);
    }
    var labFull = String(field && field.label || "").trim();
    var ckFull = String(field && field.canonicalKey || "");
    var fullDate = (ckFull === "dob" || ckFull === "date_of_birth") && !/^dd$|^day$|^mm$|^month$|^yyyy$|^year$/i.test(labFull) || /\bdd[\s_\-\/.]*mm[\s_\-\/.]*(?:yyyy|yyy)\b/i.test(labFull + " " + String(field && field.placeholder || "")) || /date of birth|\bbirth date\b/i.test(labFull) || /dateBirth|effectiveDate|jquerryEffectiveDate/i.test(String(field && field.id || "") + " " + String(field && field.name || ""));
    var dateish = partish || /\b(date|dob|birth|day|month|year|dd|mm|yyyy)\b/i.test(blob) && !notDob;
    var nameish = partish || /\b(name|first|middle|last|surname|fname|lname)\b/i.test(blob);
    var sliceish = partish || /last\s*\d|first\s*\d|last\s*digit|suffix|prefix/i.test(blob);
    var dp = parseDobParts(atom);
    if (dp && dateish && !fullDate) {
      var sn = normLoose(sample);
      var dayN = String(parseInt(dp.day, 10));
      var monthN = String(parseInt(dp.month, 10));
      if (sn === normLoose(dp.day) || sn === normLoose(dayN)) return { kind: "date_part", part: "day", pad: dp.day.indexOf("0") === 0 ? 2 : void 0 };
      if (sn === normLoose(dp.month) || sn === normLoose(monthN) || sn === normLoose(MONTH_NAMES[parseInt(dp.month, 10)] || "")) return { kind: "date_part", part: "month" };
      if (sn === normLoose(dp.year)) return { kind: "date_part", part: "year" };
    }
    if (atom.indexOf("@") > 0 && (partish || /email|user|local/i.test(blob))) {
      var local = atom.slice(0, atom.indexOf("@"));
      if (normLoose(sample) === normLoose(local)) return { kind: "email_local" };
    }
    if (sliceish) {
      if (atom.lastIndexOf(sample) === atom.length - sample.length && sample.length < atom.length && sample.length <= 8) return { kind: "last_n", n: sample.length };
      if (atom.indexOf(sample) === 0 && sample.length < atom.length && sample.length <= 8) return { kind: "first_n", n: sample.length };
    }
    if (nameish) {
      var nameParts = atom.split(/\s+/).filter(Boolean);
      if (nameParts.length >= 2) {
        if (normLoose(sample) === normLoose(nameParts[0])) return { kind: "name_part", part: "first" };
        if (normLoose(sample) === normLoose(nameParts[nameParts.length - 1])) return { kind: "name_part", part: "last" };
      }
    }
    return { kind: "unknown" };
  }
  function gsk(l) {
    return String(l || "").toLowerCase().replace(/[^a-z0-9\s]/g, "").replace(/\s+/g, " ").trim();
  }
  function labelKeys(label) {
    var raw = String(label || "").toLowerCase().trim();
    if (!raw) return [];
    var stripped = raw.replace(/[^a-z0-9\s]/g, "").replace(/\s+/g, " ").trim();
    var spaced = raw.replace(/[^a-z0-9]/g, " ").replace(/\s+/g, " ").trim();
    var out = [];
    if (stripped) out.push(stripped);
    if (spaced && spaced !== stripped) out.push(spaced);
    return out;
  }
  function lookupSavedEntry(savedMap, field) {
    if (!savedMap || !field) return null;
    if (field.catalogKey && savedMap[field.catalogKey]) return savedMap[field.catalogKey];
    if (field.section && field.canonicalKey && savedMap[field.section + "." + field.canonicalKey]) {
      return savedMap[field.section + "." + field.canonicalKey];
    }
    if (field.canonicalKey && savedMap[field.canonicalKey]) return savedMap[field.canonicalKey];
    var keys = labelKeys(field.label).concat(labelKeys(field.name));
    var i;
    for (i = 0; i < keys.length; i++) {
      if (savedMap[keys[i]] && savedMap[keys[i]].profileKey) return savedMap[keys[i]];
    }
    for (i = 0; i < keys.length; i++) {
      if (savedMap[keys[i]]) return savedMap[keys[i]];
    }
    return null;
  }
  function isTravelJourneyField(field) {
    var raw = [field && field.label, field && field.name, field && field.id, field && field.placeholder, field && field.selector].filter(Boolean).join(" ").toLowerCase();
    if (!raw.trim()) return false;
    if (/police[_\s-]?station|\bthana\b/.test(raw)) return false;
    return /\b(from|to|destination|origin|boarding|departure|arrival|journey|train|flight|airport|pnr|berth|quota)\b/.test(raw) || /\b(from|to)[_\s-]?station\b/.test(raw) || /\bstation\b/.test(raw);
  }
  var IDENTITY_PROFILE_KEYS = {
    dob: 1,
    date_of_birth: 1,
    dob__day: 1,
    dob__month: 1,
    dob__year: 1,
    name: 1,
    first_name: 1,
    last_name: 1,
    middle_name: 1,
    full_name: 1,
    father_name: 1,
    mother_name: 1,
    aadhaar: 1,
    aadhaar_number: 1,
    aadhar: 1,
    pan: 1,
    pan_number: 1,
    gender: 1,
    sex: 1,
    email: 1,
    phone: 1,
    mobile: 1,
    mobile_number: 1
  };
  function profileKeyAgreesWithField(field, profileKey) {
    var pk = String(profileKey || "").toLowerCase().trim();
    if (!pk || !field) return !pk ? false : true;
    var lab = String(field.label || "").toLowerCase();
    var typ = String(field.type || "").toLowerCase();
    var blob = [field.label, field.id, field.name, field.placeholder, field.type, field.canonicalKey].filter(Boolean).join(" ").toLowerCase();
    if (field.humanGate === "otp" || field.humanGate === "captcha") return false;
    if (/otp/i.test(blob) && !/slide[-_]?dot/i.test(blob)) return false;
    if (pk === "dob" || pk === "date_of_birth" || pk.indexOf("dob__") === 0) {
      if (/(mobile|phone|sampark)/i.test(lab) && !/otp/i.test(lab)) return false;
      if (typ === "tel") return false;
      if (/e-?mail/i.test(lab) || /\bgender\b|\bsex\b/i.test(lab)) return false;
    }
    if ((pk === "mobile" || pk === "phone" || pk === "mobile_number" || pk === "phone_number") && /otp/i.test(blob) && !/slide[-_]?dot/i.test(blob)) return false;
    return true;
  }
  function materializeSavedRelations(fields, profile, savedMap, mapping, filledBySource, sourceTag) {
    if (!savedMap || typeof savedMap !== "object") return 0;
    var added = 0;
    var map = mapping || {};
    var fbs = filledBySource || {};
    for (var i = 0; i < (fields || []).length; i++) {
      var f = fields[i];
      if (!f || !f.selector || map[f.selector]) continue;
      if (f.fillMode === "auto" || f.fillMode === "skip") continue;
      if (f.humanGate === "captcha" || f.humanGate === "otp" || f.humanGate === "submit" || f.humanGate === "upload") continue;
      if (isPerApplicationField(f)) continue;
      if (/radio|checkbox/i.test(String(f.type || ""))) continue;
      var entry = lookupSavedEntry(savedMap, f);
      if (!entry || !entry.profileKey) continue;
      if (entry.relation && entry.relation.kind === "per_application") continue;
      if (isTravelJourneyField(f) && IDENTITY_PROFILE_KEYS[String(entry.profileKey)]) continue;
      if (!profileKeyAgreesWithField(f, entry.profileKey)) continue;
      var relation = normalizeRelation(entry, f);
      var value = applyRelation(relation, profile, entry.profileKey, f);
      if (value == null) continue;
      map[f.selector] = { value, type: f.type, label: f.label, profileKey: entry.profileKey, relation, matchBy: sourceTag || "saved-relation" };
      fbs[f.selector] = { label: f.label || "", profileKey: entry.profileKey, relation, source: sourceTag || "saved-relation" };
      added++;
    }
    return added;
  }
  root.CcMappingRelation = {
    profileAtom,
    normalizeRelation,
    applyRelation,
    induceRelation,
    looksLikePartField,
    isCompoundAtom,
    materializeSavedRelations,
    profileKeyAgreesWithField
  };
})(typeof globalThis !== "undefined" ? globalThis : this);
if (typeof module !== "undefined") module.exports = (typeof globalThis !== "undefined" ? globalThis : this).CcMappingRelation;

/* ==== sequential-kernel-fill.ts ==== */
(function(root2) {
  "use strict";
  async function run(ctx) {
    var tabId = ctx.tabId;
    var profile = ctx.profile;
    var backendUrl = ctx.backendUrl;
    var accessToken = ctx.accessToken;
    var runtimeVersion = ctx.runtimeVersion;
    var onProgress = ctx.onProgress;
    var progress = function(t, p) {
      if (typeof onProgress === "function") onProgress(t, p);
    };
    var errors = typeof globalThis !== "undefined" && globalThis.CcRuntimeErrors || null;
    var opMsg = function(code, detail) {
      return errors && errors.operatorMessageFor ? errors.operatorMessageFor(code, detail) : detail || code || "Something went wrong";
    };
    if (!tabId) {
      return { ok: false, filled: 0, failed: 0, skipped: 0, records: [], observationError: null, operatorMessage: opMsg("gateway_error", "No active tab"), error: "no_tab" };
    }
    var manifests = root2.CcScriptManifests || {};
    var SCRIPTS = manifests.SEQUENTIAL_KERNEL_SCRIPTS || [];
    var _fp = root2.CcFlattenProfile || {};
    var flat = _fp.flattenProfile ? _fp.flattenProfile(profile) : profile && (profile.data || profile) || {};
    progress("Loading sequential fill kernel...", 25);
    await chrome.scripting.executeScript({ target: { tabId }, files: SCRIPTS.slice() });
    progress("Extracting fields...", 35);
    var extractResults = await chrome.scripting.executeScript({
      target: { tabId },
      args: [flat],
      func: function(prof) {
        if (typeof extractFormFieldsWithFingerprint !== "function") return { ok: false, error: "extractor_not_loaded" };
        if (typeof ccDeriveProfile === "function") {
          try {
            var d = ccDeriveProfile(prof);
            if (d && typeof d === "object") Object.assign(prof, d);
          } catch (e) {
          }
        }
        var extracted2 = extractFormFieldsWithFingerprint();
        var formFields = extracted2.formFields, formKey = extracted2.formKey, semanticFormKey = extracted2.semanticFormKey;
        if (!formFields.length) return { ok: false, error: "no fields detected" };
        var snapshotId = extracted2.snapshotId || formFields[0] && formFields[0].snapshotId || "";
        var fields = formFields.map(function(f2) {
          return {
            selector: f2.selector,
            id: f2.id || "",
            name: f2.name || "",
            label: f2.label || "",
            visualLabel: f2.visualLabel || f2.label || "",
            fieldId: f2.fieldId || "",
            snapshotId: f2.snapshotId || snapshotId,
            type: f2.type || "text",
            options: f2.options || null,
            optionSelectors: f2.optionSelectors || null,
            placeholder: f2.placeholder || "",
            locators: f2.locators || null,
            lastLocator: f2.lastLocator || null,
            index: f2.index,
            canonicalKey: f2.canonicalKey || null,
            catalogKey: f2.catalogKey || null,
            section: f2.section || null,
            dependsOn: f2.dependsOn || null,
            fillMode: f2.fillMode || null,
            humanGate: f2.humanGate || null,
            rules: f2.rules || null,
            needsReview: !!f2.needsReview,
            optionsDynamic: !!f2.optionsDynamic,
            optionDetails: f2.optionDetails || null,
            constantValue: f2.constantValue || null,
            transliterate: !!f2.transliterate,
            hidden: !!f2.hidden,
            showWhen: f2.showWhen || null,
            relationHint: f2.relationHint || null
          };
        });
        return { ok: true, fields, profile: prof, formKey, semanticFormKey: semanticFormKey || formKey, hostname: location.hostname, url: location.href, snapshotId, meta: extracted2.meta || null };
      }
    });
    var extracted = extractResults && extractResults[0] && extractResults[0].result;
    if (!extracted || !extracted.ok) {
      return { ok: false, filled: 0, failed: 1, skipped: 0, records: [], observationError: null, operatorMessage: opMsg("gateway_error", extracted && extracted.error || "Extract failed"), error: extracted && extracted.error || "extract_failed" };
    }
    function requestWssPlan(fields, snapshotId) {
      return new Promise(function(resolve) {
        var timer = setTimeout(function() {
          resolve({ ok: false, error: "wss_plan_timeout" });
        }, 3e4);
        chrome.runtime.sendMessage(
          {
            type: "WSS_FILL_REQUEST",
            formKey: extracted.semanticFormKey || extracted.formKey,
            semanticFormKey: extracted.semanticFormKey || extracted.formKey,
            hostname: extracted.hostname,
            fields,
            profile: extracted.profile,
            profileId: profile && profile.id || null,
            snapshotId: snapshotId || extracted.snapshotId || ""
          },
          function(resp) {
            clearTimeout(timer);
            if (chrome.runtime.lastError) resolve({ ok: false, error: chrome.runtime.lastError.message });
            else resolve(resp || { ok: false, error: "no_response" });
          }
        );
      });
    }
    progress("Planning over WSS...", 50);
    var transport = "wss";
    var wssPlan = null;
    try {
      var planResp = await requestWssPlan(extracted.fields, extracted.snapshotId);
      if (planResp && planResp.ok && planResp.plan) {
        wssPlan = planResp.plan;
        transport = "wss";
      } else {
        throw new Error(planResp && planResp.error || "wss_plan_failed");
      }
    } catch (e) {
      console.warn("[CC] WSS fill plan failed, HTTPS fallback:", e.message);
      transport = "https-fallback";
      progress("WSS unavailable \u2014 HTTPS fallback...", 52);
      try {
        var headers = { Authorization: "Bearer " + accessToken };
        var pk = extracted.semanticFormKey || extracted.formKey;
        var saved = {};
        var mr = await fetch(backendUrl + "/mappings/" + encodeURIComponent(pk), { headers });
        if (mr.ok) saved = await mr.json();
        var adapters = {};
        try {
          var ar = await fetch(backendUrl + "/adapters/" + encodeURIComponent(extracted.hostname), { headers });
          if (ar.ok) adapters = await ar.json();
        } catch (e2) {
        }
        wssPlan = { mapping: {}, filledBySource: {}, adapters, savedMappings: saved, transport: "https-fallback" };
      } catch (e3) {
        return { ok: false, filled: 0, failed: 1, skipped: 0, records: [], observationError: null, operatorMessage: opMsg("gateway_error", "Plan failed: " + (e3.message || e.message)), error: "plan_failed" };
      }
    }
    try {
      await new Promise(function(resolve) {
        chrome.runtime.sendMessage({ type: "ENSURE_WSS" }, function() {
          resolve();
        });
        setTimeout(resolve, 1500);
      });
    } catch (e) {
    }
    var relApi = root2.CcMappingRelation || {};
    try {
      if (!wssPlan.mapping) wssPlan.mapping = {};
      if (!wssPlan.filledBySource) wssPlan.filledBySource = {};
      if (typeof relApi.materializeSavedRelations === "function") {
        relApi.materializeSavedRelations(
          extracted.fields,
          extracted.profile,
          wssPlan.savedMappings || {},
          wssPlan.mapping,
          wssPlan.filledBySource,
          "client-saved-relation"
        );
      }
    } catch (relErr) {
      console.warn("[CC] saved-relation materialize skipped:", relErr && relErr.message ? relErr.message : relErr);
    }
    try {
      let labelKeys = function(label) {
        var raw = String(label || "").toLowerCase().trim();
        if (!raw) return [];
        var gsk = raw.replace(/[^a-z0-9\s]/g, "").replace(/\s+/g, " ").trim();
        var spaced = raw.replace(/[^a-z0-9]/g, " ").replace(/\s+/g, " ").trim();
        var out = [];
        if (gsk) out.push(gsk);
        if (spaced && spaced !== gsk) out.push(spaced);
        return out;
      }, hasTaughtMapping = function(f2) {
        if (f2 && f2.canonicalKey && savedMaps[f2.canonicalKey] && savedMaps[f2.canonicalKey].profileKey) return true;
        var keys = labelKeys(f2 && f2.label).concat(labelKeys(f2 && f2.name));
        for (var i2 = 0; i2 < keys.length; i2++) {
          var entry = savedMaps[keys[i2]];
          if (entry && entry.profileKey) return true;
        }
        return false;
      };
      var planned = wssPlan.mapping || {};
      var covered = {};
      Object.keys(planned).forEach(function(sel) {
        covered[sel] = true;
      });
      var savedMaps = wssPlan.savedMappings || {};
      var exactTaughtCount = typeof wssPlan.exactTaughtCount === "number" ? wssPlan.exactTaughtCount : 0;
      var preferMapsOnly = wssPlan.preferMapsOnly === true || wssPlan.mappingSource === "exact" && exactTaughtCount > 0;
      if (preferMapsOnly) {
        var residual = extracted.fields.filter(function(f2) {
          return !covered[f2.selector];
        }).length;
        console.log("[CC] prefer taught mappings: exact form trained (", exactTaughtCount || "n", "keys); skipping AI (", residual, "residual \u2192 fuzzy/skip)");
        progress("Using taught mappings\u2026", 58);
      } else {
        var aiCandidates = extracted.fields.filter(function(f2) {
          if (covered[f2.selector]) return false;
          if (hasTaughtMapping(f2)) return false;
          return true;
        });
        var taughtSkipped = extracted.fields.filter(function(f2) {
          return !covered[f2.selector] && hasTaughtMapping(f2);
        }).length;
        if (taughtSkipped > 0) {
          console.log("[CC] prefer taught mappings: skipping AI for", taughtSkipped, "already-mapped field(s)");
        }
        if (aiCandidates.length > 0 && backendUrl && accessToken) {
          progress("AI mapping " + aiCandidates.length + " unknown fields...", 58);
          var aiRes = await fetch(backendUrl + "/semantic-map", {
            method: "POST",
            headers: {
              "Authorization": "Bearer " + accessToken,
              "Content-Type": "application/json"
            },
            body: JSON.stringify({
              fields: aiCandidates,
              hostname: extracted.hostname,
              formKey: extracted.semanticFormKey || extracted.formKey,
              pageContext: {
                page_url: extracted.url || "",
                page_title: "",
                portal_id: extracted.hostname,
                form_key: extracted.semanticFormKey || extracted.formKey
              }
            })
          });
          if (aiRes.ok) {
            var aiData = await aiRes.json();
            var aiMaps = aiData && aiData.mappings || [];
            var flatProf = extracted.profile || {};
            if (!wssPlan.mapping) wssPlan.mapping = {};
            if (!wssPlan.filledBySource) wssPlan.filledBySource = {};
            var travelRe = /\b(from|to|destination|origin|boarding|departure|arrival|journey|train|flight|airport|pnr|berth|quota|station)\b/i;
            var policeRe = /police[_\s-]?station|\bthana\b/i;
            var identityKeys = {
              dob: 1,
              date_of_birth: 1,
              dob__day: 1,
              dob__month: 1,
              dob__year: 1,
              name: 1,
              first_name: 1,
              last_name: 1,
              middle_name: 1,
              full_name: 1,
              father_name: 1,
              mother_name: 1,
              aadhaar: 1,
              aadhaar_number: 1,
              aadhar: 1,
              pan: 1,
              pan_number: 1,
              gender: 1,
              sex: 1,
              email: 1,
              phone: 1,
              mobile: 1,
              mobile_number: 1
            };
            for (var ai = 0; ai < aiMaps.length; ai++) {
              var am = aiMaps[ai];
              if (!am || !am.selector || !am.profile_key) continue;
              if (am.disposition === "reject") continue;
              if (wssPlan.mapping[am.selector]) continue;
              var fieldMeta = aiCandidates.find(function(f2) {
                return f2.selector === am.selector;
              }) || {};
              var travelBlob = [fieldMeta.label, fieldMeta.name, fieldMeta.id, fieldMeta.placeholder].filter(Boolean).join(" ");
              if (travelRe.test(travelBlob) && !policeRe.test(travelBlob) && identityKeys[String(am.profile_key)]) continue;
              var aiKey = am.profile_key;
              var aiRelation = { kind: "identity" };
              var pval = null;
              if (aiKey === "dob__day" || aiKey === "dob__month" || aiKey === "dob__year") {
                aiRelation = { kind: "date_part", part: aiKey.split("__")[1] };
                aiKey = "dob";
                pval = typeof relApi.applyRelation === "function" ? relApi.applyRelation(aiRelation, flatProf, aiKey, fieldMeta) : null;
              } else if (typeof relApi.looksLikePartField === "function" && typeof relApi.isCompoundAtom === "function" && relApi.looksLikePartField(fieldMeta) && relApi.isCompoundAtom(aiKey)) {
                var lbl = String(fieldMeta.label || "").trim();
                var guessed = null;
                if (/^(dob|date_of_birth)$/i.test(aiKey)) {
                  if (/^dd$|^day$/i.test(lbl) || /dob_?day|birth_?day/i.test(lbl)) guessed = { kind: "date_part", part: "day" };
                  else if (/^mm$|^month$/i.test(lbl) || /dob_?month|birth_?month/i.test(lbl)) guessed = { kind: "date_part", part: "month" };
                  else if (/^yyyy$|^year$/i.test(lbl) || /dob_?year|birth_?year/i.test(lbl)) guessed = { kind: "date_part", part: "year" };
                }
                if (guessed && typeof relApi.applyRelation === "function") {
                  aiRelation = guessed;
                  pval = relApi.applyRelation(guessed, flatProf, aiKey === "date_of_birth" ? "dob" : aiKey, fieldMeta);
                  if (aiKey === "date_of_birth") aiKey = "dob";
                } else {
                  continue;
                }
              } else {
                pval = flatProf[aiKey];
                if (pval != null && typeof pval === "object" && "value" in pval) pval = pval.value;
                if (pval == null || String(pval).trim() === "") continue;
                if (typeof relApi.applyRelation === "function") {
                  var shaped = relApi.applyRelation(aiRelation, flatProf, aiKey, fieldMeta);
                  if (shaped == null) continue;
                  pval = shaped;
                }
              }
              if (pval == null || String(pval).trim() === "") continue;
              wssPlan.mapping[am.selector] = {
                value: pval,
                type: fieldMeta.type || "text",
                label: fieldMeta.label || "",
                visualLabel: fieldMeta.visualLabel || fieldMeta.label || "",
                fieldId: fieldMeta.fieldId || "",
                snapshotId: fieldMeta.snapshotId || extracted.snapshotId || "",
                profileKey: aiKey,
                relation: aiRelation
              };
              wssPlan.filledBySource[am.selector] = {
                label: fieldMeta.label || "",
                visualLabel: fieldMeta.visualLabel || fieldMeta.label || "",
                fieldId: fieldMeta.fieldId || "",
                profileKey: aiKey,
                relation: aiRelation,
                source: "server-ai"
              };
            }
            console.log("[CC] semantic-map strategy=", aiData.strategy, "applied=", Object.keys(wssPlan.filledBySource).filter(function(k) {
              return wssPlan.filledBySource[k].source === "server-ai";
            }).length);
          } else {
            console.warn("[CC] semantic-map HTTP", aiRes.status);
          }
        }
      }
    } catch (aiErr) {
      console.warn("[CC] semantic-map skipped:", aiErr && aiErr.message ? aiErr.message : aiErr);
    }
    async function executeFill(prof, fields, wssMapping, wssFbs, adapters2, profileId, fillTransport, replanOnly) {
      if (typeof fillFormFieldsSequential !== "function") return { ok: false, error: "sequential_kernel_not_loaded" };
      try {
        window._ccProfileId = profileId;
      } catch (e) {
      }
      var mapping = Object.assign({}, wssMapping || {});
      var fbs = Object.assign({}, wssFbs || {});
      function choiceCovered(f2) {
        if (mapping[f2.selector]) return true;
        if (f2.optionSelectors) {
          for (var i2 = 0; i2 < f2.optionSelectors.length; i2++) {
            if (mapping[f2.optionSelectors[i2]]) return true;
          }
        }
        return false;
      }
      function isFullDateish(f2) {
        if (!f2) return false;
        var lab = String(f2.label || "").trim();
        var ck = String(f2.canonicalKey || "");
        var ph = String(f2.placeholder || "");
        var blob = lab + " " + ph + " " + (f2.id || "") + " " + (f2.name || "");
        if ((ck === "dob" || ck === "date_of_birth") && !/^dd$|^day$|^mm$|^month$|^yyyy$|^year$/i.test(lab)) return true;
        if (/\bdd[\s_\-\/.]*mm[\s_\-\/.]*(?:yyyy|yyy)\b/i.test(lab + " " + ph)) return true;
        if (/date of birth|\bbirth date\b/i.test(lab) && !/^dd$|^day$/i.test(lab)) return true;
        if (/dateBirth|effectiveDate|jquerryEffectiveDate/i.test(blob)) return true;
        return false;
      }
      if (!replanOnly) {
        let profileKeyAgrees = function(f2, pk2) {
          pk2 = String(pk2 || "").toLowerCase();
          if (!pk2 || !f2) return !pk2 ? false : true;
          var lab = String(f2.label || "").toLowerCase();
          var typ = String(f2.type || "").toLowerCase();
          var blob = [f2.label, f2.id, f2.name, f2.placeholder, f2.type, f2.canonicalKey].filter(Boolean).join(" ").toLowerCase();
          if (f2.humanGate === "otp" || f2.humanGate === "captcha") return false;
          if (/otp/i.test(blob) && !/slide[-_]?dot/i.test(blob)) return false;
          if (pk2 === "dob" || pk2 === "date_of_birth" || pk2.indexOf("dob__") === 0) {
            if (/(mobile|phone|sampark)/i.test(lab) && !/otp/i.test(lab)) return false;
            if (typ === "tel") return false;
            if (/e-?mail/i.test(lab) || /\bgender\b|\bsex\b/i.test(lab)) return false;
          }
          if ((pk2 === "mobile" || pk2 === "phone" || pk2 === "mobile_number") && /otp/i.test(blob) && !/slide[-_]?dot/i.test(blob)) return false;
          return true;
        };
        for (var si2 = 0; si2 < (fields || []).length; si2++) {
          var sf = fields[si2];
          if (!sf || !sf.selector || !mapping[sf.selector]) continue;
          var sent = mapping[sf.selector];
          var planned2 = String(sent && sent.value || "");
          var splitDay = sent && sent.matchBy === "split-dob" && /^\d{1,2}$/.test(planned2);
          if (isFullDateish(sf) && (splitDay || /^\d{1,2}$/.test(planned2))) {
            delete mapping[sf.selector];
            delete fbs[sf.selector];
          }
        }
        for (var ci2 = 0; ci2 < (fields || []).length; ci2++) {
          var cf2 = fields[ci2];
          if (!cf2 || !cf2.selector || !mapping[cf2.selector]) continue;
          var cpk = mapping[cf2.selector].profileKey || fbs[cf2.selector] && fbs[cf2.selector].profileKey;
          if (!profileKeyAgrees(cf2, cpk)) {
            delete mapping[cf2.selector];
            delete fbs[cf2.selector];
          }
        }
      }
      var unmapped = replanOnly ? [] : fields.filter(function(f2) {
        return !choiceCovered(f2);
      });
      if (unmapped.length > 0 && typeof fuzzyMatch === "function") {
        var fz = fuzzyMatch(unmapped, prof);
        for (var sel in fz || {}) {
          if (mapping[sel]) continue;
          mapping[sel] = fz[sel];
          fbs[sel] = { label: fz[sel] && fz[sel].label || "", source: "label-primary", profileKey: fz[sel] && fz[sel].profileKey || null };
        }
      }
      for (var fi = 0; fi < (fields || []).length; fi++) {
        var bf = fields[fi];
        if (!bf || !bf.selector || !mapping[bf.selector]) continue;
        var bent = mapping[bf.selector];
        if (!bent.visualLabel) bent.visualLabel = bf.visualLabel || bf.label || bent.label || "";
        if (!bent.fieldId) bent.fieldId = bf.fieldId || "";
        if (!bent.snapshotId) bent.snapshotId = bf.snapshotId || "";
        if (fbs[bf.selector]) {
          if (!fbs[bf.selector].visualLabel) fbs[bf.selector].visualLabel = bent.visualLabel;
          if (!fbs[bf.selector].fieldId) fbs[bf.selector].fieldId = bent.fieldId;
        }
      }
      for (var di2 = 0; di2 < (fields || []).length; di2++) {
        var df = fields[di2];
        if (!df || !df.selector) continue;
        var gate = df.humanGate;
        if (df.fillMode === "skip" || gate === "captcha" || gate === "otp" || gate === "upload" || gate === "submit") {
          delete mapping[df.selector];
          if (df.optionSelectors) {
            for (var oi = 0; oi < df.optionSelectors.length; oi++) delete mapping[df.optionSelectors[oi]];
          }
        }
      }
      var filledCount = await fillFormFieldsSequential(mapping, fbs, adapters2 || {}, fields);
      var records = [];
      try {
        var raw = document.body.getAttribute("data-cc-records");
        if (raw) records = JSON.parse(raw);
      } catch (e) {
      }
      if (!records.length && Array.isArray(window.__ccFillRecords)) records = window.__ccFillRecords;
      var failed = records.filter(function(rec) {
        return rec.result === "failed" || rec.result === "error" || rec.failReason && rec.result !== "skipped" && rec.result !== "waiting_human" && rec.result !== "filled";
      }).length;
      var skipped = records.filter(function(rec) {
        return rec.result === "skipped" || rec.result === "waiting_human";
      }).length;
      var filled = records.filter(function(rec) {
        return rec.result === "filled";
      }).length || filledCount || 0;
      records = records.map(function(rec) {
        return Object.assign({}, rec, { hostname: rec.hostname || location.hostname, plannedValue: rec.plannedValue != null ? rec.plannedValue : rec.value, actualValue: rec.actualValue != null ? rec.actualValue : rec.actual, transport: fillTransport });
      });
      return { ok: true, filled, failed, skipped, fields: Object.keys(mapping).length, records, hostname: location.hostname, url: location.href, _mapping: mapping, _fbs: fbs, _fields: fields };
    }
    progress("Filling form (sequential)...", 70);
    var execResults = await chrome.scripting.executeScript({
      target: { tabId },
      args: [extracted.profile, extracted.fields, wssPlan.mapping || {}, wssPlan.filledBySource || {}, wssPlan.adapters || {}, profile && profile.id || null, transport, false],
      func: executeFill
    });
    var r = execResults && execResults[0] && execResults[0].result || { ok: false, error: "no_result" };
    if (!r.ok) {
      return { ok: false, filled: 0, failed: 1, skipped: 0, records: [], observationError: null, operatorMessage: opMsg("gateway_error", r.error || "Sequential fill failed"), error: r.error || "sequential_failed" };
    }
    if (transport === "wss") {
      var firstRecords = r.records || [];
      var driftSelectors = {};
      for (var di = 0; di < firstRecords.length; di++) {
        var drec = firstRecords[di];
        if (drec && drec.failReason === "label_drift" && drec.selector) driftSelectors[drec.selector] = true;
      }
      var seenSelectors = {};
      var firstFields = extracted.fields || [];
      for (var si = 0; si < firstFields.length; si++) {
        if (firstFields[si] && firstFields[si].selector) seenSelectors[firstFields[si].selector] = true;
      }
      try {
        var reextract = await chrome.scripting.executeScript({
          target: { tabId },
          func: function() {
            if (typeof extractFormFieldsWithFingerprint !== "function") return { ok: false, error: "extractor_not_loaded" };
            var extracted2 = extractFormFieldsWithFingerprint();
            var formFields = extracted2 && extracted2.formFields || [];
            var visible = formFields.filter(function(f2) {
              return f2 && f2.visible === true;
            });
            var snapshotId = extracted2 && extracted2.snapshotId || visible[0] && visible[0].snapshotId || "";
            var fields = visible.map(function(f2) {
              return {
                selector: f2.selector,
                id: f2.id || "",
                name: f2.name || "",
                label: f2.label || "",
                visualLabel: f2.visualLabel || f2.label || "",
                fieldId: f2.fieldId || "",
                snapshotId: f2.snapshotId || snapshotId,
                type: f2.type || "text",
                options: f2.options || null,
                optionSelectors: f2.optionSelectors || null,
                placeholder: f2.placeholder || ""
              };
            });
            return { ok: true, fields, snapshotId };
          }
        });
        var secondSnap = reextract && reextract[0] && reextract[0].result;
        var candidates = [];
        if (secondSnap && secondSnap.ok && secondSnap.fields) {
          for (var ci = 0; ci < secondSnap.fields.length; ci++) {
            var cf = secondSnap.fields[ci];
            if (!cf || !cf.selector) continue;
            if (driftSelectors[cf.selector] || !seenSelectors[cf.selector]) candidates.push(cf);
          }
        }
        if (candidates.length) {
          progress("Re-planning changed fields...", 78);
          var replanResp = await requestWssPlan(candidates, secondSnap.snapshotId);
          if (replanResp && replanResp.ok && replanResp.plan) {
            var replanExec = await chrome.scripting.executeScript({
              target: { tabId },
              args: [extracted.profile, candidates, replanResp.plan.mapping || {}, replanResp.plan.filledBySource || {}, replanResp.plan.adapters || {}, profile && profile.id || null, "wss", true],
              func: executeFill
            });
            var second = replanExec && replanExec[0] && replanExec[0].result;
            if (second && second.ok) {
              var secondSelectors = {};
              var secondRecords = second.records || [];
              for (var ri = 0; ri < secondRecords.length; ri++) {
                if (secondRecords[ri] && secondRecords[ri].selector) secondSelectors[secondRecords[ri].selector] = true;
              }
              var secondMap = second._mapping || {};
              for (var mk in secondMap) {
                if (Object.prototype.hasOwnProperty.call(secondMap, mk)) secondSelectors[mk] = true;
              }
              var kept = firstRecords.filter(function(rec) {
                return rec && !secondSelectors[rec.selector];
              });
              r.records = kept.concat(secondRecords);
              r.filled = r.records.filter(function(rec) {
                return rec && rec.result === "filled";
              }).length;
              r.failed = r.records.filter(function(rec) {
                return rec && (rec.result === "failed" || rec.result === "error" || rec.failReason && rec.result !== "skipped" && rec.result !== "waiting_human" && rec.result !== "filled");
              }).length;
              r.skipped = r.records.filter(function(rec) {
                return rec && (rec.result === "skipped" || rec.result === "waiting_human");
              }).length;
              r._mapping = Object.assign({}, r._mapping || {}, second._mapping || {});
              r._fbs = Object.assign({}, r._fbs || {}, second._fbs || {});
              var fieldBySel = {};
              var mergedFields = [];
              var fieldLists = [candidates, r._fields || []];
              for (var li = 0; li < fieldLists.length; li++) {
                for (var mfi = 0; mfi < fieldLists[li].length; mfi++) {
                  var mf = fieldLists[li][mfi];
                  if (!mf || !mf.selector || fieldBySel[mf.selector]) continue;
                  fieldBySel[mf.selector] = true;
                  mergedFields.push(mf);
                }
              }
              r._fields = mergedFields;
            }
          } else {
            console.warn("[CC] re-plan failed:", replanResp && replanResp.error || "no_plan");
          }
        }
      } catch (replanErr) {
        console.warn("[CC] re-plan skipped:", replanErr && replanErr.message ? replanErr.message : replanErr);
      }
    }
    try {
      let mappingProfileKey = function(field) {
        var info2 = syncFbs[field.selector];
        var mapEntry2 = syncMapping[field.selector];
        if (info2 && info2.profileKey) return info2.profileKey;
        if (mapEntry2 && mapEntry2.profileKey) return mapEntry2.profileKey;
        var sels = field.optionSelectors || [];
        for (var si2 = 0; si2 < sels.length; si2++) {
          var optInfo = syncFbs[sels[si2]];
          var optMap = syncMapping[sels[si2]];
          if (optInfo && optInfo.profileKey) return optInfo.profileKey;
          if (optMap && optMap.profileKey) return optMap.profileKey;
        }
        if (field.relationHint === "per_application" || field.canonicalKey === "purpose" || field.canonicalKey === "apply_to_office") return null;
        if (field.canonicalKey) return field.canonicalKey;
        return null;
      };
      var pk = extracted.semanticFormKey || extracted.formKey;
      var syncMapping = r._mapping || {};
      var syncFbs = r._fbs || {};
      var syncFields = r._fields || [];
      var syncRecords = r.records || [];
      var syncProfile = extracted.profile || {};
      var updates = {};
      var gsk2 = function(l) {
        return (l || "").toLowerCase().replace(/[^a-z0-9\s]/g, "").replace(/\s+/g, " ").trim();
      };
      for (var i = 0; i < syncFields.length; i++) {
        var f = syncFields[i];
        var sk = f.catalogKey || (f.section && f.canonicalKey ? f.section + "." + f.canonicalKey : "") || f.canonicalKey || gsk2(f.label);
        if (!sk || sk.length < 2) sk = gsk2(f.name);
        if (!sk || sk.length < 2) sk = gsk2(f.id);
        if (!sk || sk.length < 2) continue;
        if (updates[sk]) {
          var extra = gsk2(f.id) || gsk2(f.selector) || String(i);
          if (extra) sk = sk + "." + extra;
        }
        if (updates[sk]) continue;
        var info = syncFbs[f.selector];
        var mapEntry = syncMapping[f.selector];
        var profileKey = mappingProfileKey(f);
        if (profileKey && typeof relApi.profileKeyAgreesWithField === "function" && !relApi.profileKeyAgreesWithField(f, profileKey)) {
          profileKey = f.canonicalKey && relApi.profileKeyAgreesWithField(f, f.canonicalKey) ? f.canonicalKey : null;
        }
        var filledRec = syncRecords.find(function(rec) {
          return rec.selector === f.selector && rec.result === "filled";
        });
        var wasFilled = !!filledRec;
        var evidence = null;
        if (filledRec) {
          evidence = filledRec.actualValue != null ? filledRec.actualValue : filledRec.actual != null ? filledRec.actual : filledRec.plannedValue != null ? filledRec.plannedValue : filledRec.value;
        } else if (mapEntry && mapEntry.value != null) {
          evidence = mapEntry.value;
        }
        var relation = info && info.relation || mapEntry && mapEntry.relation || null;
        if (f.relationHint === "per_application" || f.canonicalKey === "purpose" || f.canonicalKey === "apply_to_office") {
          relation = { kind: "per_application" };
        } else if ((!relation || !relation.kind || relation.kind === "unknown") && profileKey && typeof relApi.induceRelation === "function") {
          var induced = relApi.induceRelation(syncProfile, profileKey, evidence, f);
          if (induced && induced.kind && induced.kind !== "unknown") relation = induced;
          else if (!relation || !relation.kind) relation = induced || { kind: "unknown" };
        }
        if (!relation || !relation.kind) {
          relation = { kind: "unknown" };
        }
        updates[sk] = {
          profileKey,
          relation,
          label: f.label || f.name || f.id || sk,
          type: f.type,
          order: typeof f.index === "number" ? f.index : i,
          options: f.optionsDynamic ? "dynamic" : f.optionDetails || f.options || null,
          locators: f.locators || null,
          lastLocator: f.lastLocator || null,
          canonicalKey: f.canonicalKey || null,
          catalogKey: f.catalogKey || sk,
          section: f.section || null,
          dependsOn: f.dependsOn || null,
          fillMode: f.fillMode || null,
          humanGate: f.humanGate || null,
          rules: f.rules || null,
          needsReview: !profileKey || !!f.needsReview,
          constantValue: f.constantValue || null,
          selector: f.selector || null,
          transliterate: !!f.transliterate,
          hidden: !!f.hidden,
          showWhen: f.showWhen || null,
          delta: { fills: wasFilled ? 1 : 0, corrections: 0 }
        };
      }
      if (Object.keys(updates).length > 0 && backendUrl && accessToken && pk) {
        await fetch(backendUrl + "/mappings/" + encodeURIComponent(pk), {
          method: "POST",
          headers: { "Content-Type": "application/json", "Authorization": "Bearer " + accessToken },
          body: JSON.stringify({ updates, meta: { hostname: r.hostname || extracted.hostname, title: extracted.meta && extracted.meta.title || "", serviceId: extracted.meta && extracted.meta.serviceId || "", structuralFingerprint: extracted.meta && extracted.meta.structuralFingerprint || "", lastSeen: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10), syncVersion: 3 } })
        });
      }
    } catch (e) {
      console.warn("[CC] mapping sync failed:", e.message);
    }
    progress("Saving session over WSS...", 92);
    var sessionId = null;
    var sessionPayload = {
      hostname: r.hostname || extracted.hostname,
      url: r.url || extracted.url,
      semanticFormKey: extracted.semanticFormKey || extracted.formKey,
      formKey: extracted.formKey,
      runtimeVersion: runtimeVersion || "",
      totalFilled: r.filled || 0,
      totalFailed: r.failed || 0,
      totalSkipped: r.skipped || 0,
      records: r.records || []
    };
    try {
      var sessResp = await new Promise(function(resolve) {
        chrome.runtime.sendMessage(Object.assign({ type: "WSS_FILL_SESSION" }, sessionPayload), function(resp) {
          if (chrome.runtime.lastError) resolve({ ok: false, error: chrome.runtime.lastError.message });
          else resolve(resp || { ok: false });
        });
      });
      if (sessResp && sessResp.ok) {
        sessionId = sessResp.id || null;
      } else {
        throw new Error(sessResp && sessResp.error || "wss_session_failed");
      }
    } catch (e) {
      console.warn("[CC] WSS session failed, HTTPS fallback:", e.message);
      try {
        var sRes = await fetch(backendUrl + "/sessions", {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: "Bearer " + accessToken },
          body: JSON.stringify(sessionPayload)
        });
        if (sRes.ok) {
          var body = await sRes.json().catch(function() {
            return {};
          });
          sessionId = body.id || null;
        }
        transport = "https-fallback";
      } catch (e2) {
      }
    }
    progress("Fill done (" + transport + "): " + (r.filled || 0) + " filled", 100);
    return {
      ok: (r.failed || 0) === 0,
      filled: r.filled || 0,
      failed: r.failed || 0,
      skipped: r.skipped || 0,
      records: r.records || [],
      observationError: null,
      operatorMessage: "Fill complete: " + (r.filled || 0) + " ok, " + (r.failed || 0) + " failed, " + (r.skipped || 0) + " skipped (" + transport + ")",
      sessionId,
      hostname: r.hostname || extracted.hostname || "",
      path: "sequential-kernel",
      transport
    };
  }
  root2.CcSequentialKernelFill = { run };
})(typeof globalThis !== "undefined" ? globalThis : this);
if (typeof module !== "undefined") module.exports = root.CcSequentialKernelFill;

/* ==== action-plan-fill.ts ==== */
(function(root2) {
  "use strict";
  async function run(ctx) {
    var tabId = ctx.tabId;
    var profile = ctx.profile;
    var backendUrl = ctx.backendUrl;
    var accessToken = ctx.accessToken;
    var runtimeVersion = ctx.runtimeVersion;
    var executionPreference = ctx.executionPreference;
    var onProgress = ctx.onProgress;
    var progress = function(t, p) {
      if (typeof onProgress === "function") onProgress(t, p);
    };
    var errors = typeof globalThis !== "undefined" && globalThis.CcRuntimeErrors || null;
    var opMsg = function(code, detail) {
      return errors && errors.operatorMessageFor ? errors.operatorMessageFor(code, detail) : detail || code || "Something went wrong";
    };
    if (!tabId) {
      return { ok: false, filled: 0, failed: 0, skipped: 0, records: [], observationError: null, operatorMessage: opMsg("gateway_error", "No active tab"), error: "no_tab" };
    }
    var manifests = root2.CcScriptManifests || {};
    var PRODUCT_SCRIPTS = manifests.PRODUCT_PATH_SCRIPTS || [];
    var _fp = root2.CcFlattenProfile || {};
    var flatProfile = _fp.flattenProfile ? _fp.flattenProfile(profile) : profile && (profile.data || profile) || {};
    progress("Perceiving page structure...", 30);
    var loadedCheck = await chrome.scripting.executeScript({
      target: { tabId },
      func: function() {
        return !!(globalThis.CcDomGateway && globalThis.CcBindingRegistry && globalThis.CcPerception && globalThis.CcActionPlanExecutor);
      }
    });
    if (!loadedCheck[0].result) {
      await chrome.scripting.executeScript({ target: { tabId }, files: PRODUCT_SCRIPTS.slice() });
    }
    try {
      var allowStore = await chrome.storage.local.get("navigationOriginAllowlist");
      var originAllowlist = Array.isArray(allowStore.navigationOriginAllowlist) ? allowStore.navigationOriginAllowlist.filter(function(x) {
        return typeof x === "string" && x.length > 0;
      }) : [];
      await chrome.scripting.executeScript({
        target: { tabId },
        func: function(list) {
          if (globalThis.CcNavigationContract && globalThis.CcNavigationContract.setOriginAllowlist) {
            globalThis.CcNavigationContract.setOriginAllowlist(list);
          } else {
            globalThis.__ccNavigationOriginAllowlist = Array.isArray(list) ? list : [];
          }
        },
        args: [originAllowlist]
      });
    } catch (e) {
      console.warn("[CC] navigation origin allowlist seed failed:", e.message);
    }
    var percResults = await chrome.scripting.executeScript({
      target: { tabId },
      func: async function() {
        try {
          if (typeof CcPerception === "undefined") return { error: "CcPerception not loaded" };
          if (typeof CcDomGateway === "undefined") return { error: "CcDomGateway not loaded" };
          if (typeof CcContextDiscovery !== "undefined" && CcContextDiscovery.resetContextCounter) CcContextDiscovery.resetContextCounter();
          if (typeof CcNodeFactory !== "undefined" && CcNodeFactory.resetNodeCounter) CcNodeFactory.resetNodeCounter();
          await CcPerception.initPerception({
            gateway: CcDomGateway,
            bindingRegistry: new CcBindingRegistry(),
            revisionManager: new CcRevisionManager(),
            privacyFilter: CcPrivacyFilter,
            widgetClassifier: CcWidgetClassifier,
            contextDiscovery: CcContextDiscovery,
            nodeFactory: CcNodeFactory,
            edgeFactory: CcEdgeFactory,
            canonicalHash: CcCanonicalHash,
            snapshotBuilder: CcSnapshotBuilder,
            validator: CcValidator,
            validatorOptions: { schema: null }
          });
          if (CcValidator && !CcValidator.isInitialized()) await CcValidator.initValidator({ schema: null });
          return await CcPerception.perceivePage({ mode: "snapshot", includeGeometry: true });
        } catch (err) {
          return { error: err.message, stack: (err.stack || "").slice(0, 300) };
        }
      }
    });
    var pageSnapshot = percResults && percResults[0] && percResults[0].result;
    if (!pageSnapshot || pageSnapshot.kind !== "page_snapshot") {
      return { ok: false, filled: 0, failed: 0, skipped: 0, records: [], observationError: null, operatorMessage: opMsg("gateway_error", "Perception failed"), error: String(pageSnapshot && pageSnapshot.error || "perception_failed").slice(0, 120) };
    }
    progress("Server planning fill...", 55);
    var planResponse = await fetch(backendUrl + "/fill-plan", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: "Bearer " + accessToken },
      body: JSON.stringify({ snapshot: pageSnapshot, profileId: profile.id, operator_execution_preference: executionPreference || "AUTO", profile: flatProfile })
    });
    if (!planResponse.ok) {
      return { ok: false, filled: 0, failed: 0, skipped: 0, records: [], observationError: null, operatorMessage: opMsg("gateway_error", "Server plan failed"), error: "plan_http_" + planResponse.status, pageSnapshot };
    }
    var planBody = await planResponse.json();
    var plan = planBody.plan || planBody.action_plan || planBody;
    if (!plan || !plan.steps || plan.steps.length === 0) {
      return { ok: false, filled: 0, failed: 0, skipped: 0, records: [], observationError: null, operatorMessage: "No fields could be mapped for this form.", error: "empty_plan", pageSnapshot };
    }
    progress("Executing " + plan.steps.length + " steps...", 70);
    var execResults = await chrome.scripting.executeScript({
      target: { tabId },
      func: async function(actionPlan) {
        if (!globalThis.CcActionPlanExecutor || !globalThis.CcActionPlanExecutor.execute) throw new Error("ActionPlan executor not loaded");
        if (typeof globalThis.ccExecutor === "function" || globalThis.__ccLegacyFillActive) throw new Error("Legacy fill path must not run with ActionPlan v3");
        if (globalThis.CcDomEvidence && globalThis.CcDomEvidence.startObserving) {
          var registry = globalThis.CcPerception && globalThis.CcPerception.getBindingRegistry && globalThis.CcPerception.getBindingRegistry();
          globalThis.CcDomEvidence.startObserving(actionPlan, registry);
        }
        var observation;
        try {
          observation = await globalThis.CcActionPlanExecutor.execute(actionPlan);
        } finally {
          if (globalThis.CcDomEvidence && globalThis.CcDomEvidence.stopObserving) {
            globalThis.CcDomEvidence.stopObserving();
            var evidence = globalThis.CcDomEvidence.getEvidence && globalThis.CcDomEvidence.getEvidence() || [];
            if (evidence.length > 0 && observation) observation.dom_evidence = evidence;
          }
        }
        return observation;
      },
      args: [plan]
    });
    var executionObservation = execResults && execResults[0] && execResults[0].result;
    if (!executionObservation || executionObservation.kind !== "execution_observation") {
      return { ok: false, filled: 0, failed: 0, skipped: 0, records: [], observationError: null, operatorMessage: opMsg("gateway_error", "Execution failed"), error: "invalid_observation", pageSnapshot, plan };
    }
    var observationError = null;
    try {
      var query = new URLSearchParams({ plan_id: plan.plan_id || "", correlation_id: plan.correlation_id || "", runtimeVersion: runtimeVersion || "" });
      var reportResponse = await fetch(backendUrl + "/fill-observation?" + query.toString(), {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: "Bearer " + accessToken },
        body: JSON.stringify(executionObservation)
      });
      if (!reportResponse.ok) observationError = "HTTP " + reportResponse.status;
    } catch (e) {
      observationError = e.message;
    }
    var stepResults = executionObservation.steps || [];
    var filled = stepResults.filter(function(r) {
      return r.status === "succeeded";
    }).length;
    var failed = stepResults.filter(function(r) {
      return r.status === "failed";
    }).length;
    var skipped = stepResults.filter(function(r) {
      return r.status === "skipped";
    }).length;
    var resultByStep = new Map(stepResults.map(function(r) {
      return [r.step_id, r];
    }));
    var hostFromSnap = (function() {
      try {
        var origin = pageSnapshot.page && pageSnapshot.page.origin || pageSnapshot.page && pageSnapshot.page.url || "";
        return origin ? new URL(origin).hostname : "";
      } catch (e) {
        return "";
      }
    })();
    var nodesById = pageSnapshot && pageSnapshot.nodes || {};
    var humanLabelFor = function(step) {
      var target = step && step.target || {};
      var nodeId = target.node_id || null;
      var node = nodeId && nodesById[nodeId] || null;
      var observed = node && node.observed || {};
      var label = target.label || observed.accessible_name || node && (node.semantic_label || node.label) || target.semantic_key || null;
      if (label && label !== nodeId && label !== (step && step.step_id)) return label;
      if (target.semantic_key) return target.semantic_key;
      return label || "Field";
    };
    var records = (plan.steps || []).map(function(step) {
      var result = resultByStep.get(step.step_id);
      var planned = step.action && step.action.value != null ? step.action.value : step.action && step.action.text != null ? step.action.text : "";
      var actual = result && result.observed_value_state || result && result.actual_value || result && result.actualValue || null;
      var target = step && step.target || {};
      return {
        label: humanLabelFor(step),
        selector: target.node_id || null,
        nodeId: target.node_id || null,
        semanticKey: target.semantic_key || null,
        result: result && result.status === "succeeded" ? "filled" : result && result.status || "skipped",
        value: planned,
        plannedValue: planned,
        actualValue: actual,
        failReason: result && result.failure_code || null,
        source: "server-plan",
        fillMode: "sequential-ape",
        hostname: hostFromSnap,
        verified: result && result.postcondition_met === true
      };
    });
    var sessionId = null;
    try {
      var sessRes = await fetch(backendUrl + "/sessions", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: "Bearer " + accessToken },
        body: JSON.stringify({ hostname: hostFromSnap, url: pageSnapshot.page && pageSnapshot.page.url || pageSnapshot.page && pageSnapshot.page.origin || "", semanticFormKey: pageSnapshot.page && pageSnapshot.page.route_key || null, runtimeVersion: runtimeVersion || "", totalFilled: filled, totalFailed: failed, totalSkipped: skipped, records })
      });
      if (sessRes.ok) {
        var sb = await sessRes.json().catch(function() {
          return {};
        });
        sessionId = sb.id || null;
      }
    } catch (e) {
      console.warn("[CC] session post failed:", e.message);
    }
    var operatorMessage = null;
    if (executionObservation.outcome === "rejected" || executionObservation.outcome === "aborted") {
      operatorMessage = opMsg(executionObservation.rejection_reason || "plan rejected", null);
    } else if (observationError) {
      operatorMessage = "Fields changed, but session evidence was not saved.";
    } else {
      operatorMessage = "Fill complete: " + filled + " ok, " + failed + " failed, " + skipped + " skipped";
    }
    return {
      ok: failed === 0 && executionObservation.outcome !== "aborted" && executionObservation.outcome !== "rejected",
      pageSnapshot,
      plan,
      executionObservation,
      filled,
      failed,
      skipped,
      records,
      observationError,
      operatorMessage,
      sessionId,
      hostname: hostFromSnap
    };
  }
  root2.CcActionPlanFill = { run };
})(typeof globalThis !== "undefined" ? globalThis : this);
if (typeof module !== "undefined") module.exports = root.CcActionPlanFill;
