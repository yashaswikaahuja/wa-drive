// Generated from popup.ts — edit popup.ts, then pnpm build.
var _a, _b;
const VERSION = chrome.runtime.getManifest().version;
let allProfiles = [];
let selectedProfile = null;
let allowLegacyClientFill = false;
let _extBuildInfo = null;
let _lastFillTabId = null;
let _lastFillHost = null;
const profilesEl = document.getElementById("profiles");
const searchEl = document.getElementById("search");
const fillBtn = document.getElementById("fill-btn");
const modeSelect = document.getElementById("mode-select");
const agentBtn = document.getElementById("agent-btn");
const agentPanel = document.getElementById("agent-panel");
const agentActionsEl = document.getElementById("agent-actions");
const agentExecuteBtn = document.getElementById("agent-execute");
const agentCancelBtn = document.getElementById("agent-cancel");
const statusEl = document.getElementById("status");
const connDot = document.getElementById("conn-dot");
const connText = document.getElementById("conn-text");
const progressEl = document.getElementById("progress");
const progressText = document.getElementById("progress-text");
const progressInner = document.getElementById("progress-inner");
const resultsEl = document.getElementById("results");
const versionEl = document.getElementById("ver");
const searchClear = document.getElementById("search-clear");
const listCountEl = document.getElementById("list-count");
const listHintEl = document.getElementById("list-hint");
const fillHintEl = document.getElementById("fill-hint");
const FILL_BTN_LABEL = "Fill this form";
versionEl.textContent = "v" + VERSION;
const HUB_FALLBACK = "https://app.cybercontrol.fun";
const HUB_APP_PATH = "/app";
const THEME_KEY = "cc-theme";
function hubOrigin(backendUrl) {
  if (!backendUrl) return HUB_FALLBACK;
  const raw = String(backendUrl);
  if (/localhost:3000|127\.0\.0\.1:3000/.test(raw)) return "http://localhost:5173";
  try {
    const u = new URL(raw);
    if (u.hostname.startsWith("api.")) u.hostname = "app." + u.hostname.slice(4);
    return u.origin;
  } catch (e) {
    return HUB_FALLBACK;
  }
}
function resolveThemePref(pref) {
  if (pref === "light" || pref === "dark") return pref;
  try {
    return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  } catch (e) {
    return "light";
  }
}
function applyPopupTheme(pref) {
  const resolved = resolveThemePref(pref || "system");
  document.documentElement.dataset.theme = resolved;
  document.documentElement.style.colorScheme = resolved;
  return resolved;
}
async function readAndApplyPopupTheme() {
  try {
    const data = await chrome.storage.local.get(THEME_KEY);
    applyPopupTheme(data[THEME_KEY]);
  } catch (e) {
    applyPopupTheme("system");
  }
}
async function initPopupTheme() {
  await readAndApplyPopupTheme();
  try {
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const onChange = async () => {
      const data = await chrome.storage.local.get(THEME_KEY);
      if ((data[THEME_KEY] || "system") === "system") applyPopupTheme("system");
    };
    if (typeof mq.addEventListener === "function") mq.addEventListener("change", onChange);
    else if (typeof mq.addListener === "function") mq.addListener(onChange);
  } catch (e) {
  }
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") void readAndApplyPopupTheme();
  });
  window.addEventListener("focus", () => {
    void readAndApplyPopupTheme();
  });
}
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local" || !changes[THEME_KEY]) return;
  applyPopupTheme(changes[THEME_KEY].newValue);
});
function escapeHtml(value) {
  return String(value != null ? value : "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}
function initialsFor(name) {
  return String(name || "?").split(/\s+/).filter(Boolean).map((w) => w[0]).join("").slice(0, 2).toUpperCase() || "?";
}
function updateFillHint() {
  if (!fillHintEl || !fillBtn) return;
  if (selectedProfile) {
    const name = selectedProfile.name || "customer";
    fillHintEl.textContent = `Ready to fill for ${name}`;
    fillHintEl.classList.add("ready");
    fillBtn.title = `Fill the open form for ${name}`;
  } else {
    fillHintEl.textContent = "Select a customer to fill the open form";
    fillHintEl.classList.remove("ready");
    fillBtn.title = "Select a customer first";
  }
}
function updateSearchClear() {
  if (!searchClear || !searchEl) return;
  searchClear.classList.toggle("visible", !!String(searchEl.value || "").trim());
}
function clearSelection() {
  selectedProfile = null;
  fillBtn.disabled = true;
  applyAgentVisibility();
  chrome.storage.session.remove("_cc_selected").catch(() => {
  });
  updateFillHint();
  renderProfiles((searchEl == null ? void 0 : searchEl.value) || "");
}
function clearSearch() {
  if (!searchEl) return;
  searchEl.value = "";
  focusIdx = -1;
  updateSearchClear();
  renderProfiles("");
  searchEl.focus();
}
async function openHub(path) {
  const data = await chrome.storage.local.get("backendUrl");
  const origin = hubOrigin(data.backendUrl);
  const suffix = !path || path === "/" ? HUB_APP_PATH : path.startsWith("/") ? path : "/" + path;
  const url = origin + suffix;
  const tabs = await chrome.tabs.query({});
  const existing = tabs.find((t) => {
    var _a2;
    return (_a2 = t.url) == null ? void 0 : _a2.startsWith(origin);
  });
  if (existing) {
    chrome.tabs.update(existing.id, { active: true, url });
    chrome.windows.update(existing.windowId, { focused: true });
  } else {
    chrome.tabs.create({ url });
  }
}
function setLocked(locked) {
  document.body.classList.toggle("is-locked", !!locked);
}
function showLoginEmpty(title, detail) {
  setLocked(true);
  profilesEl.innerHTML = `<div class="empty"><div class="empty-title">${title}</div><div>${detail}</div><button type="button" class="primary" id="open-login-btn">Open CyberControl Hub</button></div>`;
  const btn = document.getElementById("open-login-btn");
  if (btn) btn.onclick = () => openHub(HUB_APP_PATH);
}
function shortSha(s) {
  if (!s || s === "development") return s || "dev";
  return String(s).slice(0, 7);
}
function applyAgentVisibility() {
  if (!agentBtn) return;
  if (allowLegacyClientFill) {
    agentBtn.style.display = "";
    agentBtn.title = "AI Agent (legacy \u2014 owner opt-in)";
    agentBtn.disabled = !selectedProfile;
  } else {
    agentBtn.style.display = "none";
    agentBtn.disabled = true;
    agentBtn.title = "Legacy Agent disabled (Phase 0). Use Fill this form.";
    if (agentPanel) agentPanel.style.display = "none";
  }
}
async function refreshLegacyFillGate() {
  allowLegacyClientFill = false;
  applyAgentVisibility();
}
function renderVersionLine(extCommit, svcCommit) {
  const extShort = shortSha(extCommit || "development");
  let text = `v${VERSION} @ ${extShort}`;
  let title = `Extension ${VERSION}, build ${extCommit || "development"}`;
  if (_extBuildInfo == null ? void 0 : _extBuildInfo.built_at) title += `, ${_extBuildInfo.built_at}`;
  if (svcCommit) {
    const svcShort = shortSha(svcCommit);
    text += ` \xB7 svc ${svcShort}`;
    title += ` | extension-service ${svcCommit}`;
    const bothReal = extCommit && svcCommit && extCommit !== "development" && svcCommit !== "development";
    if (bothReal && String(extCommit).slice(0, 7) !== String(svcCommit).slice(0, 7)) {
      text += " \u26A0 mismatch";
      title += " \u2014 DEPLOY LOCK: extension zip commit should match extension-service BUILD_SHA. See deploy/docs/EXTENSION-DEPLOY-LOCK.md";
      versionEl.style.color = "hsl(0 65% 42%)";
    } else {
      versionEl.style.color = "";
    }
  }
  versionEl.textContent = text;
  versionEl.title = title;
}
async function loadDeployProvenance() {
  try {
    const response = await fetch(chrome.runtime.getURL("build-info.json"));
    _extBuildInfo = response.ok ? await response.json() : null;
  } catch (e) {
    _extBuildInfo = null;
  }
  const extCommit = (_extBuildInfo == null ? void 0 : _extBuildInfo.commit) || "development";
  renderVersionLine(extCommit, null);
  try {
    const { backendUrl } = await chrome.storage.local.get("backendUrl");
    if (!backendUrl) return;
    const healthUrl = String(backendUrl).replace(/\/?$/, "") + "/extension/health";
    const hr = await fetch(healthUrl);
    if (!hr.ok) return;
    const body = await hr.json();
    if (body == null ? void 0 : body.commit) renderVersionLine(extCommit, body.commit);
  } catch (e) {
  }
}
refreshLegacyFillGate();
loadDeployProvenance();
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.allowLegacyClientFill) refreshLegacyFillGate();
});
async function getActivePageTab() {
  const isPageUrl = (u) => !!u && !u.startsWith("chrome-extension://") && !u.startsWith("chrome://") && !u.startsWith("edge://") && !u.startsWith("about:") && !u.startsWith("devtools:");
  let tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  let tab = tabs.find((t) => isPageUrl(t.url)) || tabs[0];
  if (!isPageUrl(tab == null ? void 0 : tab.url)) {
    tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    tab = tabs.find((t) => isPageUrl(t.url)) || tabs[0];
  }
  if (!isPageUrl(tab == null ? void 0 : tab.url)) {
    const allTabs = await chrome.tabs.query({ lastFocusedWindow: true });
    tab = allTabs.find((t) => t.active && isPageUrl(t.url)) || allTabs.find((t) => isPageUrl(t.url)) || tab;
  }
  if (!isPageUrl(tab == null ? void 0 : tab.url)) {
    const any = await chrome.tabs.query({});
    tab = any.find((t) => t.active && isPageUrl(t.url)) || any.find((t) => isPageUrl(t.url)) || tab;
  }
  return tab || null;
}
async function ensureFormTabAccess(tab) {
  if (!(tab == null ? void 0 : tab.id)) throw new Error("No active tab");
  const url = String(tab.url || "");
  if (!url || /^(chrome|edge|about|chrome-extension|devtools):/i.test(url)) {
    throw new Error("Open a form page first");
  }
  if (url.startsWith("file:")) throw new Error("File pages cannot be filled");
  let origin = "";
  try {
    origin = new URL(url).origin;
  } catch (e) {
    throw new Error("Open a form page first");
  }
  if (!origin || origin === "null") throw new Error("Open a form page first");
  const origins = [origin + "/*"];
  const have = await chrome.permissions.contains({ origins });
  if (have) return;
  const granted = await chrome.permissions.request({ origins });
  if (!granted) throw new Error("Allow access to this form page to fill");
}
const CC = {
  warning: "hsl(35 92% 38%)",
  danger: "hsl(0 65% 45%)",
  success: "hsl(158 60% 28%)",
  info: "hsl(22 90% 42%)",
  muted: "hsl(30 10% 40%)"
};
function showStatus(msg, color) {
  statusEl.textContent = msg;
  statusEl.style.color = color || CC.warning;
  statusEl.style.display = "block";
  if (color !== CC.danger) {
    setTimeout(() => {
      statusEl.style.display = "none";
    }, 4e3);
  }
}
statusEl == null ? void 0 : statusEl.addEventListener("click", () => {
  statusEl.style.display = "none";
});
function clearStaleFillSummary(activeTabId, activeHost) {
  if (!_lastFillTabId && !_lastFillHost) return;
  const sameTab = activeTabId && activeTabId === _lastFillTabId;
  const sameHost = activeHost && _lastFillHost && activeHost === _lastFillHost;
  if (sameTab && sameHost) return;
  _lastFillTabId = null;
  _lastFillHost = null;
  window._lastFilledRecords = [];
  if (resultsEl) resultsEl.style.display = "none";
  if (typeof undoBtn !== "undefined" && undoBtn) undoBtn.style.display = "none";
  const detailEl = document.getElementById("results-detail");
  if (detailEl) {
    detailEl.innerHTML = "";
    detailEl.style.display = "none";
  }
  const filledEl = document.getElementById("results-filled");
  if (filledEl) {
    filledEl.innerHTML = "";
    filledEl.style.display = "none";
  }
}
async function syncActivePage() {
  try {
    const tab = await getActivePageTab();
    let host = null;
    try {
      if (tab == null ? void 0 : tab.url) host = new URL(tab.url).hostname.replace(/^www\./, "");
    } catch (e) {
    }
    clearStaleFillSummary((tab == null ? void 0 : tab.id) || null, host);
  } catch (e) {
  }
}
if ((_a = chrome.tabs) == null ? void 0 : _a.onActivated) {
  chrome.tabs.onActivated.addListener(() => {
    syncActivePage();
  });
}
if ((_b = chrome.tabs) == null ? void 0 : _b.onUpdated) {
  chrome.tabs.onUpdated.addListener((tabId, info) => {
    if (info.status === "complete" || info.url) {
      chrome.tabs.query({ active: true, currentWindow: true }).then(([active]) => {
        if ((active == null ? void 0 : active.id) === tabId) syncActivePage();
      }).catch(() => {
      });
    }
  });
}
function showProgress(text) {
  resultsEl.style.display = "none";
  progressEl.style.display = "block";
  progressText.textContent = text;
  progressInner.style.width = "30%";
}
function updateProgress(text, pct) {
  progressText.textContent = text;
  progressInner.style.width = pct + "%";
}
function hideProgress() {
  progressEl.style.display = "none";
}
function showResults(filled, skipped, failed, records) {
  hideProgress();
  const total = filled + skipped + failed || 1;
  document.getElementById("r-filled").textContent = filled;
  document.getElementById("r-skipped").textContent = skipped;
  document.getElementById("r-failed").textContent = failed;
  const bar = document.getElementById("results-bar");
  bar.innerHTML = `<div class="filled" style="width:${filled / total * 100}%"></div><div class="skipped" style="width:${skipped / total * 100}%"></div><div class="failed" style="width:${failed / total * 100}%"></div>`;
  const detailEl = document.getElementById("results-detail");
  const issues = (records || []).filter((r) => r.result && r.result !== "filled");
  if (issues.length) {
    detailEl.innerHTML = issues.slice(0, 8).map((r) => {
      var _a2;
      const color = r.result === "unmapped" ? "hsl(35 92% 38%)" : "hsl(0 65% 45%)";
      const label = r.label || ((_a2 = r.selector) == null ? void 0 : _a2.replace(/[#.\[\]]/g, "").slice(0, 20)) || "?";
      return `<span class="field-tag" style="border-color:${color};color:${color}">${label}</span>`;
    }).join("") + (issues.length > 8 ? `<span class="field-tag" style="color:hsl(30 10% 40%)">+${issues.length - 8} more</span>` : "");
    detailEl.style.display = "flex";
  } else {
    detailEl.style.display = "none";
  }
  const filledEl = document.getElementById("results-filled");
  if (filledEl) {
    const fr = window._lastFilledRecords || [];
    if (fr.length) {
      filledEl.innerHTML = `<div class="filled-toggle" id="filled-toggle">\u25B8 See what was filled (${fr.length})</div>
        <div id="filled-list" style="display:none"></div>`;
      const listEl = filledEl.querySelector("#filled-list");
      listEl.innerHTML = fr.map((r) => {
        const label = (r.label || r.selector || "").toString().replace(/[#.\[\]]/g, "").slice(0, 28);
        const val = (r.value != null ? String(r.value) : "").slice(0, 30);
        return `<div class="filled-row"><span class="fl-label">${label}</span><span class="fl-val">${val}</span><span class="fl-check">\u2713</span></div>`;
      }).join("");
      const toggle = filledEl.querySelector("#filled-toggle");
      toggle.onclick = () => {
        const open = listEl.style.display === "block";
        listEl.style.display = open ? "none" : "block";
        toggle.textContent = (open ? "\u25B8" : "\u25BE") + ` See what was filled (${fr.length})`;
      };
      filledEl.style.display = "block";
    } else {
      filledEl.style.display = "none";
    }
  }
  const cpLink = document.getElementById("complete-profile-link");
  if (skipped > 0 || failed > 0) {
    cpLink.style.display = "block";
    cpLink.onclick = async () => {
      const data = await chrome.storage.local.get("backendUrl");
      const phone = (selectedProfile == null ? void 0 : selectedProfile.phone) || (selectedProfile == null ? void 0 : selectedProfile.primary_contact_phone) || "";
      const url = hubOrigin(data.backendUrl) + "/app/customers/" + encodeURIComponent(phone);
      chrome.tabs.create({ url });
    };
  } else {
    cpLink.style.display = "none";
  }
  resultsEl.style.display = "block";
}
function getPhone(p) {
  return p.phone || p.primary_contact_phone || "";
}
let focusIdx = -1;
let filteredProfiles = [];
let recentIds = [];
async function loadRecents() {
  const data = await chrome.storage.local.get("_cc_recents");
  recentIds = data._cc_recents || [];
}
async function saveRecent(profileId) {
  recentIds = [profileId, ...recentIds.filter((id) => id !== profileId)].slice(0, 5);
  await chrome.storage.local.set({ _cc_recents: recentIds });
}
function badgeHtmlFor(profile) {
  const { percent } = getCompleteness(profile);
  const data = (profile == null ? void 0 : profile.data) || profile || {};
  const hasSignal = REQUIRED_FIELDS.some((key) => {
    const val = data[key];
    const v = val && typeof val === "object" ? val.value : val;
    return !!v;
  }) || percent > 0 && ((profile == null ? void 0 : profile.data) || (profile == null ? void 0 : profile.aadhaar_number) || (profile == null ? void 0 : profile.father_name));
  if (!hasSignal && percent === 0) return "";
  const cls = percent >= 85 ? "ok" : percent >= 50 ? "warn" : "low";
  return `<span class="profile-badge ${cls}" title="Profile ${percent}% ready for common govt fields">${percent}%</span>`;
}
function updateListMeta(query, visibleCount, totalFiltered) {
  if (listCountEl) {
    if (!allProfiles.length) {
      listCountEl.textContent = "";
    } else if (query) {
      listCountEl.textContent = totalFiltered > visibleCount ? `${visibleCount} of ${totalFiltered} matches` : `${totalFiltered} match${totalFiltered === 1 ? "" : "es"}`;
    } else {
      listCountEl.textContent = totalFiltered > visibleCount ? `Showing ${visibleCount} of ${allProfiles.length}` : `${allProfiles.length} customer${allProfiles.length === 1 ? "" : "s"}`;
    }
  }
  if (listHintEl) {
    if (selectedProfile) {
      listHintEl.textContent = "Enter to fill \xB7 Esc to clear";
    } else if (totalFiltered > 0) {
      listHintEl.textContent = "\u2191\u2193 to move \xB7 Enter to select";
    } else {
      listHintEl.textContent = "";
    }
  }
}
function renderProfiles(query) {
  const q = (query || "").toLowerCase().trim();
  let list = q ? allProfiles.filter((p) => (p.name || "").toLowerCase().includes(q) || getPhone(p).includes(q)) : allProfiles;
  if (!q && recentIds.length) {
    const recents = recentIds.map((id) => list.find((p) => p.id === id)).filter(Boolean);
    const rest = list.filter((p) => !recentIds.includes(p.id));
    list = [...recents, ...rest];
  }
  filteredProfiles = list;
  if (!filteredProfiles.length) {
    profilesEl.innerHTML = q ? `<div class="empty"><div class="empty-title">No match</div>No customer matches \u201C${escapeHtml(query)}\u201D. Try phone digits or another name.</div>` : `<div class="empty"><div class="empty-title">No customers yet</div>Add customers in CyberControl Hub for this cafe, then come back here.</div>`;
    focusIdx = -1;
    updateListMeta(q, 0, 0);
    return;
  }
  if (filteredProfiles.length === 1 && q) {
    selectedProfile = filteredProfiles[0];
    focusIdx = 0;
    fillBtn.disabled = false;
    applyAgentVisibility();
    updateFillHint();
  }
  const visibleList = filteredProfiles.slice(0, 20);
  const recentCount = !q ? recentIds.filter((id) => allProfiles.some((x) => x.id === id)).length : 0;
  updateListMeta(q, visibleList.length, filteredProfiles.length);
  profilesEl.innerHTML = visibleList.map((p, i) => {
    const initials = escapeHtml(initialsFor(p.name));
    const isSelected = (selectedProfile == null ? void 0 : selectedProfile.id) === p.id;
    const isFocused = i === focusIdx;
    const phone = getPhone(p);
    const name = escapeHtml(p.name || "Unknown");
    const phoneLabel = phone ? `\u{1F4F1} ${escapeHtml(phone)}` : "No phone on file";
    const badge = badgeHtmlFor(p);
    let label = "";
    if (!q && i === 0 && recentCount > 0) label = '<div class="section-label">Recent</div>';
    if (!q && i === recentCount && recentCount > 0) label = '<div class="section-label">All customers</div>';
    return `${label}<div class="profile-item${isSelected ? " selected" : ""}${isFocused ? " focused" : ""}" data-id="${escapeHtml(p.id)}" data-idx="${i}" role="option" aria-selected="${isSelected}">
      <div class="avatar">${initials}</div>
      <div class="profile-body">
        <div class="profile-name-row">
          <div class="profile-name">${name}</div>
          ${badge}
        </div>
        <div class="profile-phone">${phoneLabel}</div>
      </div>
      <div class="profile-check" aria-hidden="true">\u2713</div>
    </div>`;
  }).join("");
  profilesEl.querySelectorAll(".profile-item").forEach((el) => {
    el.addEventListener("click", () => {
      selectProfile(el.dataset.id);
    });
  });
  const focused = profilesEl.querySelector(".profile-item.focused") || profilesEl.querySelector(".profile-item.selected");
  if (focused && typeof focused.scrollIntoView === "function") {
    focused.scrollIntoView({ block: "nearest" });
  }
}
function selectProfile(id) {
  selectedProfile = allProfiles.find((p) => p.id === id) || null;
  fillBtn.disabled = !selectedProfile;
  applyAgentVisibility();
  if (selectedProfile) {
    chrome.storage.session.set({ _cc_selected: id });
    prefetchProfile(id);
  } else {
    chrome.storage.session.remove("_cc_selected").catch(() => {
    });
  }
  updateFillHint();
  renderProfiles(searchEl.value);
}
let _prefetchedProfile = null;
async function prefetchProfile(id) {
  try {
    const data = await chrome.storage.local.get(["backendUrl", "accessToken"]);
    const r = await fetch(data.backendUrl + "/profiles/" + id, {
      headers: { Authorization: "Bearer " + data.accessToken }
    });
    if (r.ok) _prefetchedProfile = await r.json();
  } catch (e) {
  }
}
searchEl.addEventListener("keydown", (e) => {
  var _a2;
  const max = Math.min(filteredProfiles.length, 20);
  if (e.key === "ArrowDown") {
    e.preventDefault();
    focusIdx = Math.min(focusIdx + 1, max - 1);
    renderProfiles(searchEl.value);
  } else if (e.key === "ArrowUp") {
    e.preventDefault();
    focusIdx = Math.max(focusIdx - 1, 0);
    renderProfiles(searchEl.value);
  } else if (e.key === "Enter") {
    e.preventDefault();
    if (selectedProfile && (focusIdx === -1 || ((_a2 = filteredProfiles[focusIdx]) == null ? void 0 : _a2.id) === selectedProfile.id)) {
      fillBtn.click();
    } else if (focusIdx >= 0 && filteredProfiles[focusIdx]) {
      selectProfile(filteredProfiles[focusIdx].id);
      focusIdx = filteredProfiles.findIndex((p) => p.id === (selectedProfile == null ? void 0 : selectedProfile.id));
    } else if (filteredProfiles.length === 1) {
      selectProfile(filteredProfiles[0].id);
    }
  } else if (e.key === "Escape") {
    e.preventDefault();
    if (String(searchEl.value || "").trim()) {
      clearSearch();
    } else if (selectedProfile) {
      clearSelection();
    }
  }
});
searchClear == null ? void 0 : searchClear.addEventListener("click", (e) => {
  e.preventDefault();
  clearSearch();
});
function applyWssPresence(wss, fallbackName) {
  if (!connDot || !connText) return;
  const state = wss && wss.state || "disconnected";
  connDot.classList.remove("green", "amber");
  if (state === "connected") {
    connDot.classList.add("green");
    connText.textContent = fallbackName || "Connected";
    connText.title = wss.sessionId ? "Live \xB7 session " + wss.sessionId : "Live connection";
  } else if (state === "connecting" || state === "reconnecting") {
    connDot.classList.add("amber");
    connText.textContent = state === "connecting" ? "Connecting\u2026" : "Reconnecting\u2026";
    connText.title = wss && wss.lastError || state;
  } else if (state === "suspended") {
    connText.textContent = "Server busy";
    connText.title = wss && wss.lastError || "server unavailable";
  } else if (fallbackName) {
    connDot.classList.add("amber");
    connText.textContent = fallbackName;
    connText.title = wss && wss.lastError || "Signed in \u2014 live link reconnecting";
  } else {
    connText.textContent = "Offline";
    connText.title = "Not connected to CyberControl";
  }
}
async function refreshWssPresence(fallbackName) {
  try {
    const st = await chrome.storage.local.get("ccWssState");
    applyWssPresence(st.ccWssState, fallbackName);
    chrome.runtime.sendMessage({ type: "ENSURE_WSS" }, () => {
      void chrome.runtime.lastError;
    });
  } catch (e) {
  }
}
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local" || !changes.ccWssState) return;
  const name = (connText.textContent || "").trim();
  const keepName = name && !/^(Checking|Connecting|Reconnecting|Connected|Offline|Server busy|Signed out|Session expired|Not connected)/i.test(
    name
  );
  applyWssPresence(changes.ccWssState.newValue, keepName ? name : null);
});
async function init() {
  document.getElementById("ver").textContent = "v" + VERSION;
  await initPopupTheme();
  updateFillHint();
  syncActivePage();
  await loadRecents();
  const data = await chrome.storage.local.get(["accessToken", "backendUrl", "user"]);
  if (!data.accessToken || !data.backendUrl) {
    connText.textContent = "Signed out";
    showLoginEmpty("Sign in required", "Open CyberControl Hub and sign in as the cafe account, then reopen this panel.");
    return;
  }
  let operatorName = null;
  try {
    const r = await fetch(data.backendUrl + "/auth/me", {
      headers: { "Authorization": "Bearer " + data.accessToken }
    });
    if (r.ok) {
      const user = await r.json();
      operatorName = (user.name || user.email || "Operator").split(" ")[0];
      connDot.classList.add("green");
      connText.textContent = operatorName;
      setLocked(false);
    } else {
      connText.textContent = "Session expired";
      showLoginEmpty("Session expired", "Sign in again in CyberControl Hub, then reopen this panel.");
      return;
    }
  } catch (e) {
    connText.textContent = "Offline";
    setLocked(false);
  }
  await refreshWssPresence(operatorName);
  await loadProfilesHttps(data);
  await refreshMcpPrivacy(data);
  setInterval(() => {
    if (document.visibilityState === "visible") void refreshMcpPrivacy();
  }, 5e3);
}
async function refreshMcpPrivacy(credentials) {
  const policyEl = document.getElementById("mcp-policy-state");
  const sessionsEl = document.getElementById("mcp-sessions");
  const requestsEl = document.getElementById("mcp-requests");
  if (!policyEl || !sessionsEl || !requestsEl) return;
  const creds = credentials || await chrome.storage.local.get(["accessToken", "backendUrl"]);
  if (!creds.accessToken || !creds.backendUrl) return;
  const base = String(creds.backendUrl).replace(/\/$/, "");
  const headers = { Authorization: "Bearer " + creds.accessToken };
  try {
    const [policyRes, sessionsRes, requestsRes] = await Promise.all([
      fetch(base + "/privacy/profile-policy", { headers }),
      fetch(base + "/privacy/mcp-sessions", { headers }),
      fetch(base + "/privacy/profile-read-requests", { headers })
    ]);
    if (!policyRes.ok || !sessionsRes.ok || !requestsRes.ok) throw new Error("privacy_controls_unavailable");
    const policy = await policyRes.json();
    const sessionsBody = await sessionsRes.json();
    const requestsBody = await requestsRes.json();
    const enabled = policy.allowMcpProfileRead === true;
    policyEl.innerHTML = enabled ? '<span style="color:hsl(var(--pt-success))">Workspace policy: enabled</span> \xB7 Each client session still needs operator approval.' : '<span style="color:hsl(var(--pt-danger))">Workspace policy: disabled</span> \xB7 Ask a workspace admin to enable it in Hub Settings.';
    const sessions = Array.isArray(sessionsBody.sessions) ? sessionsBody.sessions : [];
    sessionsEl.innerHTML = sessions.length ? sessions.map((session) => {
      const active = session.profileAccessEnabled === true;
      const disabled = !enabled && !active;
      return `<div style="border:1px solid hsl(var(--pt-border));border-radius:8px;padding:8px;display:flex;align-items:center;gap:8px">
        <div style="min-width:0;flex:1">
          <div style="font-size:11px;font-weight:650;color:hsl(var(--pt-ink))">${escapeHtml(session.clientName || "MCP client")}</div>
          <div class="pt-muted" style="font-size:10px">${active ? "Session access enabled" : "Session access disabled"}</div>
        </div>
        <button type="button" data-mcp-session="${escapeHtml(session.sessionId)}" data-enabled="${active ? "false" : "true"}"
          ${disabled ? "disabled" : ""} style="font-size:10px;padding:5px 8px;border-radius:7px;border:1px solid hsl(var(--pt-border));background:${active ? "hsl(var(--pt-secondary))" : "hsl(var(--pt-marigold))"};color:${active ? "hsl(var(--pt-ink))" : "#20170e"}">
          ${active ? "Disable" : "Enable"}
        </button>
      </div>`;
    }).join("") : '<div class="pt-muted" style="font-size:11px">No connected MCP client sessions yet.</div>';
    const requests = Array.isArray(requestsBody.requests) ? requestsBody.requests : [];
    requestsEl.innerHTML = requests.length ? '<div style="font-size:11px;font-weight:700;color:hsl(var(--pt-ink))">Pending customer-data approvals</div>' + requests.map((request) => {
      const fields = Array.isArray(request.fields) ? request.fields : [];
      const categories = Array.isArray(request.dataCategories) ? request.dataCategories : [];
      return `<div style="border:1px solid hsl(var(--pt-warning));border-radius:8px;padding:9px;display:grid;gap:6px">
        <div style="font-size:11px;font-weight:700;color:hsl(var(--pt-ink))">${escapeHtml(request.profileLabel || "Customer")}</div>
        <div class="pt-muted" style="font-size:10px">Client: ${escapeHtml(request.clientName || "MCP client")}</div>
        <div style="font-size:10px;color:hsl(var(--pt-ink-soft));overflow-wrap:anywhere">Fields: ${escapeHtml(fields.join(", "))}</div>
        <div class="pt-muted" style="font-size:10px">Categories: ${escapeHtml(categories.join(", "))}</div>
        <label style="display:flex;gap:6px;align-items:flex-start;font-size:10px;color:hsl(var(--pt-ink-soft))">
          <input type="checkbox" data-mcp-confirm="${escapeHtml(request.id)}" style="margin-top:1px">
          I have informed this customer and they agreed to share these fields with this MCP client for form filling.
        </label>
        <div style="display:flex;gap:6px">
          <button type="button" data-mcp-approve="${escapeHtml(request.id)}" disabled
            style="flex:1;font-size:10px;padding:6px;border-radius:7px;background:hsl(var(--pt-marigold));color:#20170e">Approve for 5 minutes</button>
          <button type="button" data-mcp-reject="${escapeHtml(request.id)}"
            style="font-size:10px;padding:6px;border-radius:7px;border:1px solid hsl(var(--pt-border));color:hsl(var(--pt-ink))">Reject</button>
        </div>
      </div>`;
    }).join("") : "";
    const privacyPanel = document.getElementById("mcp-privacy");
    if (privacyPanel && requests.length) privacyPanel.open = true;
  } catch (error) {
    policyEl.textContent = "Could not load MCP privacy controls. Profile reads remain blocked unless the server confirms permission.";
    sessionsEl.innerHTML = "";
    requestsEl.innerHTML = "";
    console.warn("[CC privacy] controls unavailable", error);
  }
}
async function updateMcpPrivacy(path, body) {
  const creds = await chrome.storage.local.get(["accessToken", "backendUrl"]);
  if (!creds.accessToken || !creds.backendUrl) throw new Error("Sign in required");
  const response = await fetch(String(creds.backendUrl).replace(/\/$/, "") + path, {
    method: "PATCH",
    headers: { Authorization: "Bearer " + creds.accessToken, "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(result.error || "Privacy setting update failed");
  return result;
}
const mcpSessionsEl = document.getElementById("mcp-sessions");
if (mcpSessionsEl) mcpSessionsEl.addEventListener("click", async (event) => {
  var _a2, _b2;
  const button = (_b2 = (_a2 = event.target) == null ? void 0 : _a2.closest) == null ? void 0 : _b2.call(_a2, "[data-mcp-session]");
  if (!button) return;
  button.disabled = true;
  try {
    await updateMcpPrivacy("/privacy/mcp-sessions/" + encodeURIComponent(button.dataset.mcpSession) + "/profile-access", {
      enabled: button.dataset.enabled === "true"
    });
    await refreshMcpPrivacy();
  } catch (error) {
    showStatus(error.message || "Could not update MCP session", CC.danger);
    button.disabled = false;
  }
});
const mcpRequestsEl = document.getElementById("mcp-requests");
if (mcpRequestsEl) {
  mcpRequestsEl.addEventListener("change", (event) => {
    var _a2, _b2;
    const checkbox = (_b2 = (_a2 = event.target) == null ? void 0 : _a2.closest) == null ? void 0 : _b2.call(_a2, "[data-mcp-confirm]");
    if (!checkbox) return;
    const approve = mcpRequestsEl.querySelector('[data-mcp-approve="' + CSS.escape(checkbox.dataset.mcpConfirm) + '"]');
    if (approve) approve.disabled = !checkbox.checked;
  });
  mcpRequestsEl.addEventListener("click", async (event) => {
    var _a2, _b2, _c, _d;
    const approve = (_b2 = (_a2 = event.target) == null ? void 0 : _a2.closest) == null ? void 0 : _b2.call(_a2, "[data-mcp-approve]");
    const reject = (_d = (_c = event.target) == null ? void 0 : _c.closest) == null ? void 0 : _d.call(_c, "[data-mcp-reject]");
    const button = approve || reject;
    if (!button) return;
    const requestId = button.dataset.mcpApprove || button.dataset.mcpReject;
    const confirm = mcpRequestsEl.querySelector('[data-mcp-confirm="' + CSS.escape(requestId) + '"]');
    if (approve && !(confirm == null ? void 0 : confirm.checked)) return;
    button.disabled = true;
    try {
      const creds = await chrome.storage.local.get(["accessToken", "backendUrl"]);
      const response = await fetch(String(creds.backendUrl).replace(/\/$/, "") + "/privacy/profile-read-requests/" + encodeURIComponent(requestId) + "/decision", {
        method: "POST",
        headers: { Authorization: "Bearer " + creds.accessToken, "Content-Type": "application/json" },
        body: JSON.stringify({ approve: !!approve, customerInformed: !!(approve && (confirm == null ? void 0 : confirm.checked)) })
      });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(result.error || "Approval decision failed");
      showStatus(approve ? "Customer profile read approved for 5 minutes. Ask the MCP agent to retry." : "Profile read request rejected.", approve ? CC.success : CC.warning);
      await refreshMcpPrivacy();
    } catch (error) {
      showStatus(error.message || "Could not decide profile request", CC.danger);
      button.disabled = false;
    }
  });
}
async function loadProfilesHttps(data) {
  const creds = data || await chrome.storage.local.get(["accessToken", "backendUrl"]);
  if (!creds.accessToken || !creds.backendUrl) {
    showLoginEmpty("Sign in required", "Open CyberControl Hub and sign in as the cafe account, then reopen this panel.");
    return;
  }
  profilesEl.innerHTML = '<div class="empty"><div class="empty-title">Loading customers\u2026</div>Getting your cafe list ready.</div>';
  if (listCountEl) listCountEl.textContent = "";
  if (listHintEl) listHintEl.textContent = "";
  let profiles = null;
  let transport = "wss";
  try {
    const wssResp = await new Promise((resolve) => {
      const timer = setTimeout(() => resolve({ ok: false, error: "wss_profiles_timeout" }), 12e3);
      chrome.runtime.sendMessage({ type: "WSS_PROFILES_LIST" }, (resp) => {
        clearTimeout(timer);
        if (chrome.runtime.lastError) resolve({ ok: false, error: chrome.runtime.lastError.message });
        else resolve(resp || { ok: false, error: "no_response" });
      });
    });
    if ((wssResp == null ? void 0 : wssResp.ok) && Array.isArray(wssResp.profiles)) {
      profiles = wssResp.profiles;
      transport = "wss";
    } else {
      throw new Error((wssResp == null ? void 0 : wssResp.error) || "wss_profiles_failed");
    }
  } catch (e) {
    console.warn("[CC] WSS profiles failed, HTTPS fallback:", e.message);
    transport = "https-fallback";
    profilesEl.innerHTML = '<div class="empty"><div class="empty-title">Still loading\u2026</div>Connection busy \u2014 trying another path.</div>';
    try {
      const r = await fetch(String(creds.backendUrl).replace(/\/$/, "") + "/profiles", {
        headers: { Authorization: "Bearer " + creds.accessToken }
      });
      const text = await r.text();
      let body;
      try {
        body = text ? JSON.parse(text) : [];
      } catch (e2) {
        throw new Error("Bad JSON from /profiles (HTTP " + r.status + ")");
      }
      if (!r.ok) throw new Error(body && body.error || "HTTP " + r.status);
      profiles = Array.isArray(body) ? body : body && body.profiles || [];
    } catch (e2) {
      console.error("[CC] loadProfiles", e2);
      profilesEl.innerHTML = `<div class="empty"><div class="empty-title">Couldn\u2019t load customers</div>Check your connection, then retry.<br><span class="pt-muted" style="font-size:11px">${escapeHtml(e2.message)}</span><br><button type="button" id="retry-profiles">Retry</button></div>`;
      const btn = document.getElementById("retry-profiles");
      if (btn) btn.onclick = () => loadProfilesHttps();
      return;
    }
  }
  allProfiles = profiles || [];
  const sess = await chrome.storage.session.get("_cc_selected");
  if (sess._cc_selected) {
    selectedProfile = allProfiles.find((p) => p.id === sess._cc_selected) || null;
    fillBtn.disabled = !selectedProfile;
    applyAgentVisibility();
  }
  updateFillHint();
  if (!allProfiles.length) {
    profilesEl.innerHTML = `<div class="empty"><div class="empty-title">No customers yet</div>Open Hub, add customers for this cafe, then tap Retry.<div style="display:flex;gap:8px;justify-content:center;flex-wrap:wrap"><button type="button" id="retry-profiles">Retry</button><button type="button" class="primary" id="open-hub-customers">Open Hub</button></div></div>`;
    const btn = document.getElementById("retry-profiles");
    if (btn) btn.onclick = () => loadProfilesHttps();
    const hubBtn = document.getElementById("open-hub-customers");
    if (hubBtn) hubBtn.onclick = () => openHub(HUB_APP_PATH);
    return;
  }
  renderProfiles("");
  searchEl.focus();
  console.log("[CC] profiles loaded via", transport, allProfiles.length);
}
searchEl.addEventListener("input", () => {
  focusIdx = -1;
  updateSearchClear();
  renderProfiles(searchEl.value);
});
const undoBtn = document.getElementById("undo-btn");
const REQUIRED_FIELDS = ["name", "father_name", "dob", "gender", "aadhaar_number", "address", "state", "pincode"];
function getCompleteness(profile) {
  const data = (profile == null ? void 0 : profile.data) || profile || {};
  let filled = 0;
  const missing = [];
  for (const key of REQUIRED_FIELDS) {
    const val = data[key];
    const v = val && typeof val === "object" ? val.value : val;
    if (v) filled++;
    else missing.push(key.replace(/_/g, " "));
  }
  return { percent: Math.round(filled / REQUIRED_FIELDS.length * 100), missing };
}
updateSearchClear();
updateFillHint();
fillBtn.addEventListener("click", async () => {
  var _a2;
  if (!selectedProfile) return;
  const full = (_prefetchedProfile == null ? void 0 : _prefetchedProfile.id) === selectedProfile.id ? _prefetchedProfile : selectedProfile;
  const { percent, missing } = getCompleteness(full);
  if (percent < 100 && missing.length > 0) {
    const warn = document.getElementById("completeness-warn");
    warn.innerHTML = `<span>\u26A0\uFE0F ${percent}% complete \u2014 will skip: ${missing.slice(0, 3).join(", ")}${missing.length > 3 ? "..." : ""}</span><button id="fill-anyway">Fill anyway</button>`;
    warn.style.display = "flex";
    await new Promise((resolve) => {
      document.getElementById("fill-anyway").onclick = () => {
        warn.style.display = "none";
        resolve();
      };
    });
  }
  fillBtn.disabled = true;
  fillBtn.innerHTML = "<span>Filling\u2026</span>";
  resultsEl.style.display = "none";
  undoBtn.style.display = "none";
  showProgress("Preparing\u2026");
  saveRecent(selectedProfile.id);
  try {
    const tab = await getActivePageTab();
    if (!(tab == null ? void 0 : tab.id)) {
      showStatus("No active tab", CC.danger);
      hideProgress();
      return;
    }
    if (!tab.url || tab.url.startsWith("chrome") || tab.url.startsWith("edge://")) {
      showStatus("Open a form page first", CC.danger);
      hideProgress();
      return;
    }
    await ensureFormTabAccess(tab);
    _lastFillTabId = tab.id;
    try {
      _lastFillHost = new URL(tab.url).hostname.replace(/^www\./, "");
    } catch (e) {
      _lastFillHost = null;
    }
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const snapshot = {};
        document.querySelectorAll("input, select, textarea").forEach((el, idx) => {
          const key = el.id || el.name || el.getAttribute("formcontrolname") || `anon_${idx}`;
          let selector = "";
          if (el.id) selector = `#${CSS.escape(el.id)}`;
          else if (el.name) selector = `[name="${CSS.escape(el.name)}"]`;
          else if (el.getAttribute("formcontrolname")) {
            selector = `[formcontrolname="${CSS.escape(el.getAttribute("formcontrolname"))}"]`;
          }
          snapshot[key] = { value: el.value, type: el.type, selector };
        });
        window.__ccUndoSnapshot = snapshot;
      }
    });
    const data = await chrome.storage.local.get(["backendUrl", "accessToken"]);
    let fullProfile = (_prefetchedProfile == null ? void 0 : _prefetchedProfile.id) === selectedProfile.id ? _prefetchedProfile : selectedProfile;
    if (fullProfile === selectedProfile) {
      try {
        const fr = await fetch(data.backendUrl + "/profiles/" + selectedProfile.id, {
          headers: { Authorization: "Bearer " + data.accessToken }
        });
        if (fr.ok) fullProfile = await fr.json();
      } catch (e) {
        console.warn("[CC] full profile fetch failed:", e.message);
      }
    }
    selectedProfile = fullProfile;
    if (!((_a2 = globalThis.CcFillOrchestrator) == null ? void 0 : _a2.runProductFill)) {
      showStatus("Fill orchestrator not loaded", CC.danger);
      hideProgress();
      return;
    }
    const fillOut = await globalThis.CcFillOrchestrator.runProductFill({
      tabId: tab.id,
      profile: selectedProfile,
      backendUrl: data.backendUrl,
      accessToken: data.accessToken,
      runtimeVersion: VERSION,
      executionPreference: "AUTO",
      onProgress: (text, pct) => updateProgress(text, pct)
    });
    const filled = fillOut.filled || 0;
    const failed = fillOut.failed || 0;
    const skipped = fillOut.skipped || 0;
    const records = fillOut.records || [];
    window._lastFilledRecords = records.filter((r) => r.result === "filled");
    showResults(filled, skipped, failed, records.filter((r) => r.result !== "filled"));
    undoBtn.style.display = filled > 0 ? "block" : "none";
    const statusColor = !fillOut.ok || failed ? CC.danger : fillOut.observationError ? CC.danger : CC.success;
    const errApi = globalThis.CcRuntimeErrors;
    let statusMsg = fillOut.operatorMessage || ((errApi == null ? void 0 : errApi.operatorMessageFor) ? errApi.operatorMessageFor(fillOut.error, null) : fillOut.error || "Fill finished");
    if (errApi == null ? void 0 : errApi.sanitizeOperatorDetail) {
      const sanitized = errApi.sanitizeOperatorDetail(statusMsg);
      if (sanitized) statusMsg = fillOut.operatorMessage || sanitized;
    }
    showStatus(statusMsg, statusColor);
  } catch (e) {
    const raw = e && e.message ? String(e.message) : "";
    if (/Allow access|Open a form|File pages|No active tab/.test(raw)) {
      showStatus(raw, CC.danger);
    } else {
      const errApi = globalThis.CcRuntimeErrors;
      const msg = (errApi == null ? void 0 : errApi.operatorMessageFor) ? errApi.operatorMessageFor("gateway_error", null) : "Something went wrong while filling.";
      showStatus(msg, CC.danger);
    }
  } finally {
    fillBtn.disabled = !selectedProfile;
    fillBtn.innerHTML = FILL_BTN_LABEL;
    hideProgress();
  }
});
undoBtn.addEventListener("click", async () => {
  if (!_lastFillTabId) return;
  try {
    await chrome.scripting.executeScript({
      target: { tabId: _lastFillTabId },
      func: () => {
        const snapshot = window.__ccUndoSnapshot || {};
        for (const [key, info] of Object.entries(snapshot)) {
          const el = document.querySelector(info.selector);
          if (el) {
            el.value = info.value;
            el.dispatchEvent(new Event("input", { bubbles: true }));
            el.dispatchEvent(new Event("change", { bubbles: true }));
          }
        }
      }
    });
    undoBtn.style.display = "none";
    resultsEl.style.display = "none";
    showStatus("\u21A9 Fill undone", CC.success);
  } catch (e) {
    showStatus("Undo failed: " + e.message, CC.danger);
  }
});
document.getElementById("open-btn").addEventListener("click", () => {
  openHub(HUB_APP_PATH);
});
let _pendingPlan = null;
function cafeFillOnlyMessage() {
  showStatus("Use Fill this form. Remote action lists are not executed.", CC.warning);
}
if (agentBtn) {
  agentBtn.addEventListener("click", () => cafeFillOnlyMessage());
}
if (agentExecuteBtn) {
  agentExecuteBtn.addEventListener("click", () => cafeFillOnlyMessage());
}
if (agentCancelBtn) {
  agentCancelBtn.addEventListener("click", () => {
    if (agentPanel) agentPanel.style.display = "none";
    _pendingPlan = null;
  });
}
init();
